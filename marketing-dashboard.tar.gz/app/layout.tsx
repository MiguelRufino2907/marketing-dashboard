import type { Metadata } from "next";
import "./globals.css";
import { AuthProvider } from "@/lib/auth-context";

export const metadata: Metadata = {
  title: "AdsPulse — Marketing Analytics",
  description: "Dashboard de campanhas de tráfego pago — Meta, Google e TikTok Ads",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="pt-BR" className="h-full">
      <body className="min-h-full antialiased bg-[#0a0a0f] text-[#e8e8f0]">
        <AuthProvider>{children}</AuthProvider>
      </body>
    </html>
  );
}
