"use client";

import { useState, useRef, KeyboardEvent } from "react";
import AppShell from "@/components/layout/AppShell";
import { mockClients } from "@/lib/mock-data";
import {
  Check, ChevronRight, FileText, Mail, MessageCircle, Eye, X,
  Link2, Calendar, Clock, ToggleLeft, ToggleRight, Send,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useRouter } from "next/navigation";

const steps = ["Configuração", "Métricas", "Entrega", "Preview"];
const allMetrics = [
  "Investimento", "Impressões", "Alcance", "Cliques", "CTR",
  "CPM", "CPC", "Conversões", "CPA", "ROAS", "Frequência", "Receita",
];

/* ── Email Chips ─────────────────────────────────────────────────── */
function RecipientChips({
  value, onChange,
}: { value: string[]; onChange: (v: string[]) => void }) {
  const [input, setInput] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);

  const add = (raw: string) => {
    const trimmed = raw.trim().replace(/,$/, "");
    if (trimmed && !value.includes(trimmed)) onChange([...value, trimmed]);
    setInput("");
  };

  const onKey = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter" || e.key === ",") { e.preventDefault(); add(input); }
    if (e.key === "Backspace" && !input && value.length > 0)
      onChange(value.slice(0, -1));
  };

  const remove = (item: string) => onChange(value.filter((v) => v !== item));

  return (
    <div
      className="min-h-[44px] flex flex-wrap gap-1.5 items-center bg-[#111118] border border-[#1e1e2e] rounded-xl px-3 py-2 focus-within:border-[#6366f1] cursor-text"
      onClick={() => inputRef.current?.focus()}
    >
      {value.map((chip) => (
        <span key={chip} className="flex items-center gap-1 bg-[#6366f1]/15 text-[#a5b4fc] text-xs px-2 py-1 rounded-lg border border-[#6366f1]/30">
          {chip}
          <button onClick={(e) => { e.stopPropagation(); remove(chip); }} className="hover:text-white transition-colors ml-0.5">
            <X size={10} />
          </button>
        </span>
      ))}
      <input
        ref={inputRef}
        value={input}
        onChange={(e) => setInput(e.target.value)}
        onKeyDown={onKey}
        onBlur={() => { if (input) add(input); }}
        placeholder={value.length === 0 ? "email@exemplo.com · pressione Enter" : ""}
        className="flex-1 min-w-[160px] bg-transparent text-sm text-[#e8e8f0] outline-none placeholder:text-[#555568]"
      />
    </div>
  );
}

/* ── Toggle Switch ───────────────────────────────────────────────── */
function Toggle({ checked, onChange }: { checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <button onClick={() => onChange(!checked)} className="flex items-center gap-2 group">
      {checked
        ? <ToggleRight size={28} className="text-[#6366f1]" />
        : <ToggleLeft size={28} className="text-[#555568] group-hover:text-[#8888a0] transition-colors" />
      }
    </button>
  );
}

/* ── Main Component ──────────────────────────────────────────────── */
export default function NewReportPage() {
  const router = useRouter();
  const [step, setStep] = useState(0);
  const [config, setConfig] = useState({
    name: "",
    clientId: "",
    startDate: "",
    endDate: "",
    platforms: [] as string[],
    metrics: ["Investimento", "Cliques", "Conversões", "ROAS", "CPA"] as string[],
    notes: "",
    format: "email" as "email" | "whatsapp" | "both" | "pdf" | "link",
    recipients: [] as string[],
    message: "",
    // Agendamento
    scheduled: false,
    frequency: "weekly" as "weekly" | "biweekly" | "monthly",
    scheduleDay: "segunda" as string,
    scheduleTime: "09:00",
  });
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const set = <K extends keyof typeof config>(key: K, val: typeof config[K]) =>
    setConfig((c) => ({ ...c, [key]: val }));

  const togglePlatform = (p: string) =>
    set("platforms", config.platforms.includes(p)
      ? config.platforms.filter((x) => x !== p)
      : [...config.platforms, p]);

  const toggleMetric = (m: string) =>
    set("metrics", config.metrics.includes(m)
      ? config.metrics.filter((x) => x !== m)
      : [...config.metrics, m]);

  const validate = () => {
    const e: Record<string, string> = {};
    if (step === 0) {
      if (!config.name.trim()) e.name = "Nome é obrigatório";
      if (!config.clientId) e.clientId = "Selecione um cliente";
      if (!config.startDate) e.startDate = "Data inicial obrigatória";
      if (!config.endDate) e.endDate = "Data final obrigatória";
      if (config.platforms.length === 0) e.platforms = "Selecione ao menos uma plataforma";
    }
    if (step === 2 && config.recipients.length === 0 && config.format !== "pdf")
      e.recipients = "Adicione ao menos um destinatário";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const next = () => { if (validate()) setStep((s) => s + 1); };

  const handleSend = async () => {
    setSending(true);
    await new Promise((r) => setTimeout(r, 2200));
    setSending(false);
    setSent(true);
    setTimeout(() => router.push("/reports"), 2200);
  };

  /* ── Sent state ── */
  if (sent) {
    return (
      <AppShell title="Novo Relatório">
        <div className="flex flex-col items-center justify-center py-24">
          <div className="w-16 h-16 rounded-full bg-green-500/15 flex items-center justify-center mb-4 animate-pulse">
            <Check size={28} className="text-green-400" />
          </div>
          <h2 className="text-[#e8e8f0] font-display font-bold text-xl mb-2">
            {config.scheduled ? "Agendamento criado!" : "Relatório enviado!"}
          </h2>
          <p className="text-[#8888a0] text-sm">Redirecionando para a lista de relatórios...</p>
        </div>
      </AppShell>
    );
  }

  const inputCls = (field?: string) => cn(
    "w-full bg-[#111118] border rounded-xl px-4 py-2.5 text-sm text-[#e8e8f0] focus:outline-none placeholder:text-[#555568] transition-colors",
    field && errors[field] ? "border-red-500/60 focus:border-red-500" : "border-[#1e1e2e] focus:border-[#6366f1]"
  );

  return (
    <AppShell title="Novo Relatório">
      {/* Step indicator */}
      <div className="flex items-center gap-2 mb-8 flex-wrap">
        {steps.map((s, i) => (
          <div key={s} className="flex items-center gap-2">
            <button
              className={cn(
                "flex items-center gap-2 px-3 py-1.5 rounded-full text-sm font-medium transition-all",
                i === step ? "bg-[#6366f1] text-white" : i < step ? "bg-green-500/15 text-green-400 cursor-pointer" : "bg-[#16161e] text-[#555568]"
              )}
              onClick={() => i < step && setStep(i)}
            >
              {i < step ? <Check size={12} /> : <span className="w-4 h-4 rounded-full flex items-center justify-center text-[10px]">{i + 1}</span>}
              {s}
            </button>
            {i < steps.length - 1 && <ChevronRight size={13} className="text-[#555568] flex-shrink-0" />}
          </div>
        ))}
      </div>

      <div className="max-w-2xl space-y-4">

        {/* ── STEP 0: Configuração ── */}
        {step === 0 && (
          <div className="bg-[#16161e] border border-[#1e1e2e] rounded-xl p-6 space-y-5">
            <h3 className="font-display font-semibold text-[#e8e8f0]">Configuração Básica</h3>

            <div>
              <label className="text-xs text-[#8888a0] mb-1.5 block">Nome do Relatório *</label>
              <input value={config.name} onChange={(e) => set("name", e.target.value)}
                placeholder="ex: Relatório Semanal — Fashion Brasil"
                className={inputCls("name")} />
              {errors.name && <p className="text-red-400 text-xs mt-1">{errors.name}</p>}
            </div>

            <div>
              <label className="text-xs text-[#8888a0] mb-1.5 block">Cliente *</label>
              <select value={config.clientId} onChange={(e) => set("clientId", e.target.value)}
                className={inputCls("clientId")}>
                <option value="">Selecionar cliente...</option>
                {mockClients.map((cl) => <option key={cl.id} value={cl.id}>{cl.name}</option>)}
              </select>
              {errors.clientId && <p className="text-red-400 text-xs mt-1">{errors.clientId}</p>}
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs text-[#8888a0] mb-1.5 block">Data Início *</label>
                <input type="date" value={config.startDate} onChange={(e) => set("startDate", e.target.value)}
                  className={inputCls("startDate")} />
                {errors.startDate && <p className="text-red-400 text-xs mt-1">{errors.startDate}</p>}
              </div>
              <div>
                <label className="text-xs text-[#8888a0] mb-1.5 block">Data Fim *</label>
                <input type="date" value={config.endDate} onChange={(e) => set("endDate", e.target.value)}
                  className={inputCls("endDate")} />
                {errors.endDate && <p className="text-red-400 text-xs mt-1">{errors.endDate}</p>}
              </div>
            </div>

            <div>
              <label className="text-xs text-[#8888a0] mb-2 block">Plataformas *</label>
              <div className="flex flex-wrap gap-2">
                {[
                  { id: "meta", label: "Meta Ads", color: "#1877F2" },
                  { id: "google", label: "Google Ads", color: "#4285F4" },
                  { id: "tiktok", label: "TikTok Ads", color: "#FF0050" },
                ].map((p) => {
                  const on = config.platforms.includes(p.id);
                  return (
                    <button key={p.id} onClick={() => togglePlatform(p.id)}
                      className={cn("flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium border transition-all",
                        on ? "border-current" : "border-[#1e1e2e] text-[#555568] hover:text-[#8888a0]")}
                      style={on ? { color: p.color, borderColor: `${p.color}60`, background: `${p.color}15` } : {}}>
                      {on && <Check size={11} />}{p.label}
                    </button>
                  );
                })}
              </div>
              {errors.platforms && <p className="text-red-400 text-xs mt-1">{errors.platforms}</p>}
            </div>
          </div>
        )}

        {/* ── STEP 1: Métricas ── */}
        {step === 1 && (
          <div className="bg-[#16161e] border border-[#1e1e2e] rounded-xl p-6 space-y-5">
            <h3 className="font-display font-semibold text-[#e8e8f0]">Métricas e Comentários</h3>

            <div>
              <label className="text-xs text-[#8888a0] mb-2 block">
                Métricas a incluir <span className="text-[#6366f1]">({config.metrics.length} selecionadas)</span>
              </label>
              <div className="flex flex-wrap gap-2">
                {allMetrics.map((m) => {
                  const on = config.metrics.includes(m);
                  return (
                    <button key={m} onClick={() => toggleMetric(m)}
                      className={cn("px-3 py-1.5 rounded-lg text-xs font-medium border transition-all",
                        on ? "bg-[#6366f1]/15 text-[#a5b4fc] border-[#6366f1]/40" : "bg-[#111118] text-[#555568] border-[#1e1e2e] hover:text-[#8888a0]")}>
                      {on && <Check size={9} className="inline mr-1" />}{m}
                    </button>
                  );
                })}
              </div>
            </div>

            <div>
              <label className="text-xs text-[#8888a0] mb-1.5 block">Observações e Análise</label>
              <textarea value={config.notes} onChange={(e) => set("notes", e.target.value)}
                rows={4}
                placeholder="Adicione comentários, análises ou próximos passos para o cliente..."
                className="w-full bg-[#111118] border border-[#1e1e2e] rounded-xl px-4 py-3 text-sm text-[#e8e8f0] focus:outline-none focus:border-[#6366f1] placeholder:text-[#555568] resize-none" />
            </div>
          </div>
        )}

        {/* ── STEP 2: Entrega ── */}
        {step === 2 && (
          <div className="bg-[#16161e] border border-[#1e1e2e] rounded-xl p-6 space-y-5">
            <h3 className="font-display font-semibold text-[#e8e8f0]">Formato e Entrega</h3>

            {/* Formato */}
            <div>
              <label className="text-xs text-[#8888a0] mb-2 block">Canal de envio</label>
              <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
                {[
                  { id: "pdf", icon: <FileText size={15} />, label: "Somente PDF" },
                  { id: "email", icon: <Mail size={15} />, label: "E-mail" },
                  { id: "whatsapp", icon: <MessageCircle size={15} />, label: "WhatsApp" },
                  { id: "both", icon: <Send size={15} />, label: "E-mail + WhatsApp" },
                  { id: "link", icon: <Link2 size={15} />, label: "Link compartilhável" },
                ].map((opt) => {
                  const on = config.format === opt.id;
                  return (
                    <button key={opt.id} onClick={() => set("format", opt.id as typeof config.format)}
                      className={cn("flex items-center gap-2 px-4 py-3 rounded-xl text-sm font-medium border transition-all",
                        on ? "bg-[#6366f1]/15 text-[#a5b4fc] border-[#6366f1]/40" : "bg-[#111118] text-[#555568] border-[#1e1e2e] hover:text-[#8888a0]")}>
                      {opt.icon}{opt.label}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Destinatários com chips */}
            {config.format !== "pdf" && config.format !== "link" && (
              <div>
                <label className="text-xs text-[#8888a0] mb-1.5 block">
                  Destinatários <span className="text-[#555568]">(Enter ou vírgula para adicionar)</span>
                </label>
                <RecipientChips value={config.recipients} onChange={(v) => set("recipients", v)} />
                {errors.recipients && <p className="text-red-400 text-xs mt-1">{errors.recipients}</p>}
              </div>
            )}

            {/* Mensagem */}
            <div>
              <label className="text-xs text-[#8888a0] mb-1.5 block">Mensagem personalizada</label>
              <textarea value={config.message} onChange={(e) => set("message", e.target.value)}
                rows={3}
                placeholder="Olá! Segue o relatório de performance do período. Qualquer dúvida, estamos à disposição."
                className="w-full bg-[#111118] border border-[#1e1e2e] rounded-xl px-4 py-3 text-sm text-[#e8e8f0] focus:outline-none focus:border-[#6366f1] placeholder:text-[#555568] resize-none" />
            </div>

            {/* Agendamento */}
            <div className="pt-2 border-t border-[#1e1e2e]">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <p className="text-[#e8e8f0] text-sm font-medium">Envio Recorrente</p>
                  <p className="text-[#555568] text-xs mt-0.5">Agendar envio automático periódico</p>
                </div>
                <Toggle checked={config.scheduled} onChange={(v) => set("scheduled", v)} />
              </div>

              {config.scheduled && (
                <div className="mt-4 p-4 bg-[#111118] border border-[#6366f1]/20 rounded-xl space-y-4">
                  <div className="flex items-center gap-2 text-[#6366f1] text-xs font-semibold mb-1">
                    <Calendar size={13} /> Configuração de Recorrência
                  </div>

                  <div className="grid grid-cols-3 gap-3">
                    <div>
                      <label className="text-xs text-[#8888a0] mb-1.5 block">Frequência</label>
                      <select value={config.frequency} onChange={(e) => set("frequency", e.target.value as typeof config.frequency)}
                        className="w-full bg-[#16161e] border border-[#1e1e2e] rounded-xl px-3 py-2 text-xs text-[#e8e8f0] focus:outline-none focus:border-[#6366f1]">
                        <option value="weekly">Semanal</option>
                        <option value="biweekly">Quinzenal</option>
                        <option value="monthly">Mensal</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-xs text-[#8888a0] mb-1.5 block">
                        {config.frequency === "monthly" ? "Dia do mês" : "Dia da semana"}
                      </label>
                      {config.frequency === "monthly" ? (
                        <select value={config.scheduleDay} onChange={(e) => set("scheduleDay", e.target.value)}
                          className="w-full bg-[#16161e] border border-[#1e1e2e] rounded-xl px-3 py-2 text-xs text-[#e8e8f0] focus:outline-none focus:border-[#6366f1]">
                          {Array.from({ length: 28 }, (_, i) => i + 1).map((d) => (
                            <option key={d} value={String(d)}>Dia {d}</option>
                          ))}
                        </select>
                      ) : (
                        <select value={config.scheduleDay} onChange={(e) => set("scheduleDay", e.target.value)}
                          className="w-full bg-[#16161e] border border-[#1e1e2e] rounded-xl px-3 py-2 text-xs text-[#e8e8f0] focus:outline-none focus:border-[#6366f1]">
                          {["segunda", "terça", "quarta", "quinta", "sexta"].map((d) => (
                            <option key={d} value={d}>{d.charAt(0).toUpperCase() + d.slice(1)}-feira</option>
                          ))}
                        </select>
                      )}
                    </div>

                    <div>
                      <label className="text-xs text-[#8888a0] mb-1.5 flex items-center gap-1"><Clock size={10} /> Horário</label>
                      <input type="time" value={config.scheduleTime} onChange={(e) => set("scheduleTime", e.target.value)}
                        className="w-full bg-[#16161e] border border-[#1e1e2e] rounded-xl px-3 py-2 text-xs text-[#e8e8f0] focus:outline-none focus:border-[#6366f1]" />
                    </div>
                  </div>

                  <p className="text-[#555568] text-xs">
                    Fuso horário: <span className="text-[#8888a0]">America/Sao_Paulo (BRT −3)</span>
                  </p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* ── STEP 3: Preview ── */}
        {step === 3 && (
          <div className="bg-[#16161e] border border-[#1e1e2e] rounded-xl p-6 space-y-4">
            <h3 className="font-display font-semibold text-[#e8e8f0] flex items-center gap-2">
              <Eye size={15} className="text-[#6366f1]" /> Preview do Relatório
            </h3>

            {/* Mock preview card */}
            <div className="border border-[#1e1e2e] rounded-xl overflow-hidden">
              <div className="px-6 py-4 border-b border-[#1e1e2e]"
                style={{ background: "linear-gradient(135deg, #6366f120 0%, #111318 60%)" }}>
                <p className="text-[#555568] text-xs mb-1">
                  {config.startDate || "01/03/2026"} → {config.endDate || "31/03/2026"}
                </p>
                <h4 className="font-display font-bold text-[#e8e8f0] text-lg">
                  {config.name || "Relatório de Performance"}
                </h4>
                <p className="text-[#8888a0] text-sm">
                  {mockClients.find((c) => c.id === config.clientId)?.name || "— cliente —"}
                </p>
                <div className="flex gap-2 mt-2">
                  {config.platforms.map((p) => {
                    const colors: Record<string, string> = { meta: "#1877F2", google: "#4285F4", tiktok: "#FF0050" };
                    const labels: Record<string, string> = { meta: "Meta", google: "Google", tiktok: "TikTok" };
                    return (
                      <span key={p} className="text-xs px-2 py-0.5 rounded-full font-medium"
                        style={{ background: `${colors[p]}20`, color: colors[p] }}>
                        {labels[p]}
                      </span>
                    );
                  })}
                </div>
              </div>
              <div className="p-5 space-y-4">
                {config.notes && (
                  <div>
                    <p className="text-[#555568] text-[10px] font-semibold uppercase tracking-widest mb-1">Análise</p>
                    <p className="text-[#8888a0] text-sm">{config.notes}</p>
                  </div>
                )}
                <div className="grid grid-cols-3 gap-2">
                  {config.metrics.slice(0, 6).map((m) => (
                    <div key={m} className="bg-[#111118] rounded-xl p-3">
                      <p className="text-[#555568] text-[10px] mb-1">{m}</p>
                      <p className="metric-value text-[#e8e8f0] font-semibold text-sm">—</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Resumo de envio */}
            <div className="bg-[#111118] border border-[#1e1e2e] rounded-xl p-4 space-y-2.5 text-sm">
              <p className="text-[#555568] text-xs font-semibold uppercase tracking-widest mb-3">Resumo de Envio</p>
              {[
                ["Canal", config.format === "both" ? "E-mail + WhatsApp" : config.format === "link" ? "Link compartilhável" : config.format.charAt(0).toUpperCase() + config.format.slice(1)],
                ["Destinatários", config.recipients.length > 0 ? config.recipients.join(", ") : "—"],
                ["Envio", config.scheduled ? `Recorrente · ${config.frequency === "weekly" ? "Semanal" : config.frequency === "biweekly" ? "Quinzenal" : "Mensal"} · ${config.scheduleDay} às ${config.scheduleTime}` : "Imediato"],
                ["Métricas", `${config.metrics.length} métricas selecionadas`],
              ].map(([label, val]) => (
                <div key={label} className="flex justify-between gap-4">
                  <span className="text-[#555568] flex-shrink-0">{label}</span>
                  <span className="text-[#e8e8f0] text-right truncate">{val}</span>
                </div>
              ))}
            </div>

            <button onClick={handleSend} disabled={sending}
              className="w-full bg-[#6366f1] hover:bg-[#5558e8] text-white font-semibold rounded-xl py-3 text-sm transition-colors disabled:opacity-60 flex items-center justify-center gap-2">
              {sending && <div className="w-4 h-4 rounded-full border-2 border-white/30 border-t-white animate-spin" />}
              {sending
                ? "Processando..."
                : config.scheduled
                  ? "Criar Agendamento"
                  : "Gerar e Enviar Relatório"}
            </button>
          </div>
        )}

        {/* Navegação */}
        <div className="flex justify-between">
          <button onClick={() => setStep((s) => Math.max(0, s - 1))} disabled={step === 0}
            className="px-5 py-2.5 bg-[#16161e] border border-[#1e1e2e] rounded-xl text-sm text-[#8888a0] hover:text-[#e8e8f0] transition-colors disabled:opacity-40">
            Voltar
          </button>
          {step < 3 && (
            <button onClick={next}
              className="px-5 py-2.5 bg-[#6366f1] hover:bg-[#5558e8] rounded-xl text-white text-sm font-medium transition-colors flex items-center gap-2">
              Próximo <ChevronRight size={13} />
            </button>
          )}
        </div>
      </div>
    </AppShell>
  );
}
