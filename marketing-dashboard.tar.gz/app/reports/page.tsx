"use client";

import { useState, useEffect } from "react";
import AppShell from "@/components/layout/AppShell";
import StatusBadge from "@/components/shared/StatusBadge";
import { FileText, Plus, Eye, Send, Download, Calendar } from "lucide-react";
import Link from "next/link";
import { getReports } from "@/lib/data/reports";

type ReportItem = {
  id: string;
  name: string;
  clientName?: string;
  period_start?: string;
  period_end?: string;
  dateRange?: { start: string; end: string };
  platforms: string[];
  generatedAt?: string;
  created_at?: string;
  deliveryChannel?: string;
  sent_via?: string[];
  status: string;
  pdf_url?: string | null;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  clients?: any;
};

export default function ReportsPage() {
  const [reports, setReports] = useState<ReportItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getReports()
      .then((data) => setReports(data as ReportItem[]))
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  const getClientName = (r: ReportItem) =>
    r.clients?.name ?? r.clientName ?? "—";

  const getPeriod = (r: ReportItem) => {
    if (r.period_start && r.period_end) return `${r.period_start} → ${r.period_end}`;
    if (r.dateRange) return `${r.dateRange.start} → ${r.dateRange.end}`;
    return "—";
  };

  const getDate = (r: ReportItem) => r.created_at ?? r.generatedAt ?? "—";

  const getChannel = (r: ReportItem) => {
    if (r.sent_via && r.sent_via.length > 0) return r.sent_via.join(" + ");
    if (r.deliveryChannel === "both") return "E-mail + WhatsApp";
    return r.deliveryChannel ?? "Manual";
  };

  return (
    <AppShell title="Relatórios">
      <div className="flex items-center justify-between mb-6">
        <div>
          <p className="text-[#8888a0] text-sm">
            {loading ? "Carregando..." : `${reports.length} relatório${reports.length !== 1 ? "s" : ""} gerado${reports.length !== 1 ? "s" : ""}`}
          </p>
        </div>
        <div className="flex gap-2">
          <Link
            href="/reports/schedule"
            className="flex items-center gap-2 px-4 py-2 bg-[#16161e] border border-[#1e1e2e] rounded-xl text-sm text-[#8888a0] hover:text-[#e8e8f0] transition-colors"
          >
            <Calendar size={14} /> Agendamentos
          </Link>
          <Link
            href="/reports/new"
            className="flex items-center gap-2 px-4 py-2 bg-[#6366f1] hover:bg-[#5558e8] rounded-xl text-white text-sm font-medium transition-colors"
          >
            <Plus size={14} /> Novo Relatório
          </Link>
        </div>
      </div>

      <div className="bg-[#16161e] border border-[#1e1e2e] rounded-xl overflow-hidden">
        <table className="w-full">
          <thead className="bg-[#111118]">
            <tr>
              <th className="py-3 px-4 text-xs font-medium text-[#555568] text-left">Nome</th>
              <th className="py-3 px-4 text-xs font-medium text-[#555568] text-left">Cliente</th>
              <th className="py-3 px-4 text-xs font-medium text-[#555568] text-left">Período</th>
              <th className="py-3 px-4 text-xs font-medium text-[#555568] text-left">Plataformas</th>
              <th className="py-3 px-4 text-xs font-medium text-[#555568] text-left">Gerado em</th>
              <th className="py-3 px-4 text-xs font-medium text-[#555568] text-left">Canal</th>
              <th className="py-3 px-4 text-xs font-medium text-[#555568] text-left">Status</th>
              <th className="py-3 px-4 text-xs font-medium text-[#555568] text-left">Ações</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#1e1e2e]">
            {loading ? (
              Array.from({ length: 4 }).map((_, i) => (
                <tr key={i}>
                  {Array.from({ length: 8 }).map((_, j) => (
                    <td key={j} className="py-3 px-4">
                      <div className="h-4 bg-[#1e1e2e] rounded animate-pulse w-20" />
                    </td>
                  ))}
                </tr>
              ))
            ) : reports.length === 0 ? (
              <tr>
                <td colSpan={8} className="py-12 text-center text-[#555568] text-sm">
                  Nenhum relatório encontrado.{" "}
                  <Link href="/reports/new" className="text-[#6366f1] hover:underline">
                    Criar o primeiro
                  </Link>
                </td>
              </tr>
            ) : (
              reports.map((r) => (
                <tr key={r.id} className="hover:bg-[#1e1e2e]/50 transition-colors">
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-lg bg-[#6366f1]/15 flex items-center justify-center">
                        <FileText size={13} className="text-[#6366f1]" />
                      </div>
                      <span className="text-sm text-[#e8e8f0] font-medium">{r.name}</span>
                    </div>
                  </td>
                  <td className="py-3 px-4 text-sm text-[#8888a0]">{getClientName(r)}</td>
                  <td className="py-3 px-4 text-xs text-[#8888a0] font-mono">
                    {getPeriod(r)}
                  </td>
                  <td className="py-3 px-4">
                    <div className="flex gap-1">
                      {(r.platforms ?? []).map((p) => {
                        const colors: Record<string, string> = {
                          meta: "#1877F2",
                          google: "#4285F4",
                          tiktok: "#FF0050",
                        };
                        return (
                          <span
                            key={p}
                            className="w-2 h-2 rounded-full flex-shrink-0"
                            style={{ background: colors[p] ?? "#6366f1" }}
                            title={p}
                          />
                        );
                      })}
                    </div>
                  </td>
                  <td className="py-3 px-4 text-xs text-[#555568] font-mono">
                    {getDate(r).slice(0, 10)}
                  </td>
                  <td className="py-3 px-4">
                    <span className="text-xs text-[#8888a0] capitalize">
                      {getChannel(r)}
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    <StatusBadge status={r.status as any} />
                  </td>
                  <td className="py-3 px-4">
                    <div className="flex gap-1">
                      <Link
                        href={`/reports/${r.id}`}
                        className="p-1.5 rounded-lg hover:bg-[#1e1e2e] text-[#555568] hover:text-[#e8e8f0] transition-colors"
                        title="Visualizar"
                      >
                        <Eye size={13} />
                      </Link>
                      <button
                        className="p-1.5 rounded-lg hover:bg-[#1e1e2e] text-[#555568] hover:text-[#e8e8f0] transition-colors"
                        title="Reenviar"
                      >
                        <Send size={13} />
                      </button>
                      {r.pdf_url ? (
                        <a
                          href={r.pdf_url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="p-1.5 rounded-lg hover:bg-[#1e1e2e] text-[#555568] hover:text-[#e8e8f0] transition-colors"
                          title="Download PDF"
                        >
                          <Download size={13} />
                        </a>
                      ) : (
                        <button
                          className="p-1.5 rounded-lg hover:bg-[#1e1e2e] text-[#555568] hover:text-[#e8e8f0] transition-colors opacity-40"
                          title="PDF não disponível"
                          disabled
                        >
                          <Download size={13} />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </AppShell>
  );
}
