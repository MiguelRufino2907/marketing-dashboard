"use client";

import { useState } from "react";
import AppShell from "@/components/layout/AppShell";
import { mockSchedules } from "@/lib/mock-data";
import { Plus, Edit2, Pause, Play, Trash2, Calendar, Clock } from "lucide-react";
import { cn } from "@/lib/utils";

export default function SchedulePage() {
  const [schedules, setSchedules] = useState(mockSchedules);

  const toggleActive = (id: string) =>
    setSchedules((s) => s.map((sch) => sch.id === id ? { ...sch, isActive: !sch.isActive } : sch));

  const remove = (id: string) =>
    setSchedules((s) => s.filter((sch) => sch.id !== id));

  const freqLabel: Record<string, string> = {
    daily: "Diário", weekly: "Semanal", biweekly: "Quinzenal", monthly: "Mensal",
  };

  return (
    <AppShell title="Agendamentos">
      <div className="flex items-center justify-between mb-6">
        <p className="text-[#8888a0] text-sm">{schedules.filter((s) => s.isActive).length} agendamentos ativos</p>
        <button className="flex items-center gap-2 px-4 py-2 bg-[#6366f1] hover:bg-[#5558e8] rounded-xl text-white text-sm font-medium transition-colors">
          <Plus size={14} /> Novo Agendamento
        </button>
      </div>

      <div className="space-y-3">
        {schedules.map((sch) => (
          <div
            key={sch.id}
            className={cn(
              "bg-[#16161e] border rounded-xl p-5 card-hover transition-all",
              sch.isActive ? "border-[#1e1e2e]" : "border-[#1e1e2e] opacity-60"
            )}
          >
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className={cn(
                  "w-10 h-10 rounded-xl flex items-center justify-center",
                  sch.isActive ? "bg-[#6366f1]/15" : "bg-[#1e1e2e]"
                )}>
                  <Calendar size={16} className={sch.isActive ? "text-[#6366f1]" : "text-[#555568]"} />
                </div>
                <div>
                  <h3 className="text-[#e8e8f0] font-semibold text-sm">{sch.name}</h3>
                  <p className="text-[#8888a0] text-xs mt-0.5">{sch.clientName}</p>
                </div>
              </div>
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => toggleActive(sch.id)}
                  className="p-2 rounded-lg hover:bg-[#1e1e2e] text-[#555568] hover:text-[#e8e8f0] transition-colors"
                  title={sch.isActive ? "Pausar" : "Ativar"}
                >
                  {sch.isActive ? <Pause size={13} /> : <Play size={13} />}
                </button>
                <button className="p-2 rounded-lg hover:bg-[#1e1e2e] text-[#555568] hover:text-[#e8e8f0] transition-colors">
                  <Edit2 size={13} />
                </button>
                <button
                  onClick={() => remove(sch.id)}
                  className="p-2 rounded-lg hover:bg-red-500/15 text-[#555568] hover:text-red-400 transition-colors"
                >
                  <Trash2 size={13} />
                </button>
              </div>
            </div>

            <div className="mt-4 flex flex-wrap gap-3 text-xs">
              <div className="flex items-center gap-1.5 text-[#8888a0]">
                <Clock size={11} />
                {freqLabel[sch.frequency]} às {sch.time}
              </div>
              <span className="text-[#555568]">•</span>
              <div className="text-[#8888a0]">
                Canal: <span className="text-[#e8e8f0] capitalize">{sch.channel === "both" ? "E-mail + WhatsApp" : sch.channel}</span>
              </div>
              <span className="text-[#555568]">•</span>
              <div className="text-[#8888a0]">
                Destinatários: <span className="text-[#e8e8f0]">{sch.recipients.join(", ")}</span>
              </div>
            </div>

            <div className="mt-3 pt-3 border-t border-[#1e1e2e] flex items-center justify-between text-xs">
              <div className="text-[#555568]">
                Último envio: <span className="text-[#8888a0]">{sch.lastRun ?? "Nunca"}</span>
              </div>
              <div className="text-[#555568]">
                Próximo envio:{" "}
                <span className={sch.isActive ? "text-[#6366f1] font-medium" : "text-[#555568]"}>
                  {sch.nextRun}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </AppShell>
  );
}
