"use client";

import { useState } from "react";
import AppShell from "@/components/layout/AppShell";
import {
  Save, Globe, DollarSign, Mail, MessageCircle, Building2, Check,
  Bell, Palette, Link2, RefreshCw, AlertCircle, CheckCircle2,
  AlertTriangle, TrendingDown, TrendingUp, Image as ImageIcon,
} from "lucide-react";
import { mockAccounts } from "@/lib/mock-data";
import { cn } from "@/lib/utils";

/* ── Tabs ─────────────────────────────────────────────────────────── */
type Tab = "agency" | "accounts" | "alerts" | "branding";

const TABS: { id: Tab; label: string }[] = [
  { id: "agency",   label: "Agência"        },
  { id: "accounts", label: "Contas Conectadas" },
  { id: "alerts",   label: "Alertas"        },
  { id: "branding", label: "Branding de Relatório" },
];

/* ── Platform config ───────────────────────────────────────────────── */
const PLATFORM_CFG = {
  meta:   { label: "Meta Ads",   color: "#1877F2" },
  google: { label: "Google Ads", color: "#4285F4" },
  tiktok: { label: "TikTok Ads", color: "#FF0050" },
};

/* ── Toggle ─────────────────────────────────────────────────────────── */
function Toggle({ checked, onChange }: { checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      onClick={() => onChange(!checked)}
      className={cn(
        "relative w-10 h-5 rounded-full transition-colors flex-shrink-0",
        checked ? "bg-[#6366f1]" : "bg-[#1e1e2e]"
      )}
    >
      <span
        className={cn(
          "absolute top-0.5 left-0.5 w-4 h-4 rounded-full bg-white transition-transform",
          checked && "translate-x-5"
        )}
      />
    </button>
  );
}

/* ── Number Input ─────────────────────────────────────────────────── */
function NumberInput({
  value, onChange, prefix, suffix, step = 0.1,
}: {
  value: number; onChange: (v: number) => void;
  prefix?: string; suffix?: string; step?: number;
}) {
  return (
    <div className="flex items-center gap-1 bg-[#111118] border border-[#1e1e2e] rounded-xl px-3 py-2 w-32">
      {prefix && <span className="text-[#555568] text-xs">{prefix}</span>}
      <input
        type="number"
        value={value}
        step={step}
        onChange={(e) => onChange(Number(e.target.value))}
        className="w-full bg-transparent text-sm text-[#e8e8f0] text-right focus:outline-none [appearance:textfield] [&::-webkit-inner-spin-button]:appearance-none"
      />
      {suffix && <span className="text-[#555568] text-xs">{suffix}</span>}
    </div>
  );
}

/* ── Alert Row ───────────────────────────────────────────────────── */
function AlertRow({
  icon, color, label, description, enabled, onToggle, children,
}: {
  icon: React.ReactNode; color: string; label: string; description: string;
  enabled: boolean; onToggle: (v: boolean) => void; children?: React.ReactNode;
}) {
  return (
    <div className={cn("bg-[#111118] rounded-xl p-4 border transition-colors", enabled ? "border-[#1e1e2e]" : "border-[#111118]")}>
      <div className="flex items-start justify-between gap-4">
        <div className="flex items-start gap-3">
          <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5"
            style={{ background: color + "20", color }}>
            {icon}
          </div>
          <div>
            <p className="text-[#e8e8f0] text-sm font-medium">{label}</p>
            <p className="text-[#555568] text-xs mt-0.5">{description}</p>
            {enabled && children && <div className="mt-3">{children}</div>}
          </div>
        </div>
        <Toggle checked={enabled} onChange={onToggle} />
      </div>
    </div>
  );
}

/* ── Color Swatch ─────────────────────────────────────────────────── */
const PRESET_COLORS = [
  "#6366f1", "#1877F2", "#4285F4", "#22c55e",
  "#f59e0b", "#ec4899", "#06b6d4", "#8b5cf6",
  "#FF0050", "#0ea5e9", "#84cc16", "#f97316",
];

function ColorSwatch({ value, onChange }: { value: string; onChange: (c: string) => void }) {
  return (
    <div className="flex flex-wrap gap-2">
      {PRESET_COLORS.map((c) => (
        <button
          key={c}
          onClick={() => onChange(c)}
          className={cn(
            "w-7 h-7 rounded-lg border-2 transition-all",
            value === c ? "border-white scale-110" : "border-transparent"
          )}
          style={{ background: c }}
          title={c}
        />
      ))}
      <label className="w-7 h-7 rounded-lg border-2 border-dashed border-[#1e1e2e] flex items-center justify-center cursor-pointer hover:border-[#6366f1]/60 transition-colors" title="Cor personalizada">
        <span className="text-[#555568] text-lg leading-none">+</span>
        <input type="color" value={value} onChange={(e) => onChange(e.target.value)} className="sr-only" />
      </label>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════════ */

export default function SettingsPage() {
  const [tab, setTab] = useState<Tab>("agency");
  const [saved, setSaved] = useState(false);

  /* Agency */
  const [agency, setAgency] = useState({
    name: "Agência AdsPulse",
    senderEmail: "noreply@adspulse.com.br",
    emailSignature: "Equipe AdsPulse\nMarketing Analytics",
    whatsappToken: "",
    timezone: "America/Sao_Paulo",
    currency: "BRL",
  });

  /* Alerts */
  const [alerts, setAlerts] = useState({
    roasLow:    { enabled: true,  threshold: 2.0 },
    cpaHigh:    { enabled: true,  threshold: 80  },
    cpcHigh:    { enabled: false, threshold: 5.0 },
    budgetPace: { enabled: true,  threshold: 90  },
    zeroConv:   { enabled: false, threshold: 3   },
  });

  /* Branding */
  const [branding, setBranding] = useState({
    accentColor: "#6366f1",
    secondaryColor: "#22c55e",
    companyName: "Agência AdsPulse",
    tagline: "Resultados que transformam negócios",
    defaultMessage: "Olá! Segue o relatório de performance da sua campanha.\n\nQualquer dúvida, estamos à disposição.",
    showLogo: true,
    showFooter: true,
  });

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  const inputClass = "w-full bg-[#111118] border border-[#1e1e2e] rounded-xl px-4 py-2.5 text-sm text-[#e8e8f0] focus:outline-none focus:border-[#6366f1]";

  return (
    <AppShell title="Configurações">
      {/* ── Tab bar ── */}
      <div className="flex gap-1 mb-6 bg-[#111118] rounded-xl p-1 w-fit">
        {TABS.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={cn(
              "px-4 py-2 rounded-lg text-sm font-medium transition-all",
              tab === t.id
                ? "bg-[#6366f1] text-white"
                : "text-[#8888a0] hover:text-[#e8e8f0]"
            )}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* ══ AGÊNCIA ══════════════════════════════════════════════════ */}
      {tab === "agency" && (
        <div className="max-w-2xl space-y-5">
          <div className="bg-[#16161e] border border-[#1e1e2e] rounded-xl p-6">
            <h3 className="font-semibold text-[#e8e8f0] flex items-center gap-2 mb-5">
              <Building2 size={16} className="text-[#6366f1]" /> Dados da Agência
            </h3>
            <div>
              <label className="text-xs text-[#8888a0] mb-1.5 block">Nome da Agência / Empresa</label>
              <input value={agency.name} onChange={(e) => setAgency((s) => ({ ...s, name: e.target.value }))} className={inputClass} />
            </div>
          </div>

          <div className="bg-[#16161e] border border-[#1e1e2e] rounded-xl p-6">
            <h3 className="font-semibold text-[#e8e8f0] flex items-center gap-2 mb-5">
              <Mail size={16} className="text-[#6366f1]" /> Configurações de E-mail
            </h3>
            <div className="space-y-4">
              <div>
                <label className="text-xs text-[#8888a0] mb-1.5 block">E-mail remetente padrão</label>
                <input value={agency.senderEmail} onChange={(e) => setAgency((s) => ({ ...s, senderEmail: e.target.value }))} className={inputClass} />
              </div>
              <div>
                <label className="text-xs text-[#8888a0] mb-1.5 block">Assinatura de e-mail</label>
                <textarea
                  value={agency.emailSignature}
                  onChange={(e) => setAgency((s) => ({ ...s, emailSignature: e.target.value }))}
                  rows={3}
                  className={cn(inputClass, "resize-none")}
                />
              </div>
            </div>
          </div>

          <div className="bg-[#16161e] border border-[#1e1e2e] rounded-xl p-6">
            <h3 className="font-semibold text-[#e8e8f0] flex items-center gap-2 mb-5">
              <MessageCircle size={16} className="text-[#22c55e]" /> WhatsApp API
            </h3>
            <div>
              <label className="text-xs text-[#8888a0] mb-1.5 block">Token da API (Evolution API / Z-API)</label>
              <input
                type="password"
                value={agency.whatsappToken}
                onChange={(e) => setAgency((s) => ({ ...s, whatsappToken: e.target.value }))}
                placeholder="••••••••••••••••••••••••••••••••"
                className={cn(inputClass, "placeholder:text-[#555568]")}
              />
              <p className="text-[#555568] text-xs mt-1.5">Compatível com Evolution API, Z-API e Uazapi</p>
            </div>
          </div>

          <div className="bg-[#16161e] border border-[#1e1e2e] rounded-xl p-6">
            <h3 className="font-semibold text-[#e8e8f0] flex items-center gap-2 mb-5">
              <Globe size={16} className="text-[#6366f1]" /> Regional
            </h3>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-xs text-[#8888a0] mb-1.5 block">Fuso Horário</label>
                <select value={agency.timezone} onChange={(e) => setAgency((s) => ({ ...s, timezone: e.target.value }))} className={inputClass}>
                  <option value="America/Sao_Paulo">America/Sao_Paulo (UTC-3)</option>
                  <option value="America/Recife">America/Recife (UTC-3)</option>
                  <option value="America/Manaus">America/Manaus (UTC-4)</option>
                  <option value="UTC">UTC (UTC+0)</option>
                </select>
              </div>
              <div>
                <label className="text-xs text-[#8888a0] mb-1.5 block flex items-center gap-1">
                  <DollarSign size={11} /> Moeda Padrão
                </label>
                <select value={agency.currency} onChange={(e) => setAgency((s) => ({ ...s, currency: e.target.value }))} className={inputClass}>
                  <option value="BRL">BRL — Real Brasileiro</option>
                  <option value="USD">USD — Dólar Americano</option>
                  <option value="EUR">EUR — Euro</option>
                </select>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ══ CONTAS CONECTADAS ════════════════════════════════════════ */}
      {tab === "accounts" && (
        <div className="max-w-3xl space-y-6">
          <div className="flex items-center justify-between">
            <p className="text-[#8888a0] text-sm">{mockAccounts.length} contas configuradas</p>
            <button className="flex items-center gap-2 px-4 py-2 bg-[#6366f1] hover:bg-[#5558e8] rounded-xl text-white text-sm font-medium transition-colors">
              <Link2 size={14} /> Conectar Conta
            </button>
          </div>

          {(["meta", "google", "tiktok"] as const).map((platform) => {
            const accounts = mockAccounts.filter((a) => a.platform === platform);
            const cfg = PLATFORM_CFG[platform];
            return (
              <div key={platform}>
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-2 h-2 rounded-full" style={{ background: cfg.color }} />
                  <h3 className="text-[#e8e8f0] font-semibold text-sm">{cfg.label}</h3>
                  <span className="text-[#555568] text-xs">({accounts.length} conta{accounts.length !== 1 ? "s" : ""})</span>
                </div>

                {accounts.length === 0 ? (
                  <div className="bg-[#16161e] border border-dashed border-[#1e1e2e] rounded-xl p-6 flex items-center justify-center gap-3">
                    <p className="text-[#555568] text-sm">Nenhuma conta conectada</p>
                    <button
                      className="text-xs px-3 py-1.5 rounded-lg transition-colors"
                      style={{ background: cfg.color + "20", color: cfg.color }}
                    >
                      + Conectar {cfg.label}
                    </button>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {accounts.map((acc) => (
                      <div key={acc.id} className="bg-[#16161e] border border-[#1e1e2e] rounded-xl p-4 card-hover">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div
                              className="w-10 h-10 rounded-xl flex items-center justify-center text-sm font-bold"
                              style={{ background: cfg.color + "20", color: cfg.color }}
                            >
                              {cfg.label.charAt(0)}
                            </div>
                            <div>
                              <p className="text-[#e8e8f0] font-medium text-sm">{acc.accountName}</p>
                              <p className="text-[#555568] text-xs font-mono">{acc.accountId}</p>
                            </div>
                          </div>

                          <div className="flex items-center gap-4">
                            <div className="text-right hidden sm:block">
                              <p className="text-[#555568] text-xs">Gasto 30d</p>
                              <p className="metric-value text-[#e8e8f0] font-semibold text-sm">
                                {new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(acc.spend30d)}
                              </p>
                            </div>

                            {acc.status === "active" ? (
                              <div className="flex items-center gap-1 text-xs text-green-400">
                                <CheckCircle2 size={13} /> Sincronizado
                              </div>
                            ) : (
                              <div className="flex items-center gap-1 text-xs text-orange-400">
                                <AlertCircle size={13} /> Reconectar
                              </div>
                            )}

                            <div className="flex gap-1">
                              <button className="p-2 rounded-lg hover:bg-[#1e1e2e] text-[#555568] hover:text-[#e8e8f0] transition-colors" title="Sincronizar">
                                <RefreshCw size={13} />
                              </button>
                            </div>
                          </div>
                        </div>

                        <div className="mt-3 pt-3 border-t border-[#1e1e2e] flex items-center justify-between">
                          <span className="text-xs text-[#555568]">
                            Última sincronização: <span className="text-[#8888a0]">{acc.lastSync}</span>
                          </span>
                          <div className="flex items-center gap-1">
                            <div
                              className="w-1.5 h-1.5 rounded-full animate-pulse"
                              style={{ background: acc.status === "active" ? "#22c55e" : "#f59e0b" }}
                            />
                            <span className="text-[10px]" style={{ color: acc.status === "active" ? "#22c55e" : "#f59e0b" }}>
                              {acc.status === "active" ? "Online" : "Pendente"}
                            </span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* ══ ALERTAS ══════════════════════════════════════════════════ */}
      {tab === "alerts" && (
        <div className="max-w-2xl">
          <div className="bg-[#16161e] border border-[#1e1e2e] rounded-xl p-6">
            <div className="flex items-center gap-2 mb-1">
              <Bell size={16} className="text-[#f59e0b]" />
              <h3 className="font-semibold text-[#e8e8f0]">Alertas Automáticos</h3>
            </div>
            <p className="text-[#555568] text-xs mb-6">
              Receba notificações por e-mail quando métricas saírem dos limites configurados.
            </p>

            <div className="space-y-3">
              {/* ROAS baixo */}
              <AlertRow
                icon={<TrendingDown size={15} />}
                color="#ef4444"
                label="ROAS abaixo do limite"
                description="Alerta quando o ROAS de qualquer campanha cair abaixo do valor configurado"
                enabled={alerts.roasLow.enabled}
                onToggle={(v) => setAlerts((a) => ({ ...a, roasLow: { ...a.roasLow, enabled: v } }))}
              >
                <div className="flex items-center gap-2">
                  <span className="text-xs text-[#8888a0]">Alertar se ROAS &lt;</span>
                  <NumberInput
                    value={alerts.roasLow.threshold}
                    onChange={(v) => setAlerts((a) => ({ ...a, roasLow: { ...a.roasLow, threshold: v } }))}
                    suffix="x"
                    step={0.1}
                  />
                </div>
              </AlertRow>

              {/* CPA alto */}
              <AlertRow
                icon={<AlertTriangle size={15} />}
                color="#f59e0b"
                label="CPA acima do limite"
                description="Alerta quando o custo por aquisição ultrapassar o valor definido"
                enabled={alerts.cpaHigh.enabled}
                onToggle={(v) => setAlerts((a) => ({ ...a, cpaHigh: { ...a.cpaHigh, enabled: v } }))}
              >
                <div className="flex items-center gap-2">
                  <span className="text-xs text-[#8888a0]">Alertar se CPA &gt;</span>
                  <NumberInput
                    value={alerts.cpaHigh.threshold}
                    onChange={(v) => setAlerts((a) => ({ ...a, cpaHigh: { ...a.cpaHigh, threshold: v } }))}
                    prefix="R$"
                    step={1}
                  />
                </div>
              </AlertRow>

              {/* CPC alto */}
              <AlertRow
                icon={<TrendingUp size={15} />}
                color="#f97316"
                label="CPC acima do limite"
                description="Alerta quando o custo por clique médio ultrapassar o valor configurado"
                enabled={alerts.cpcHigh.enabled}
                onToggle={(v) => setAlerts((a) => ({ ...a, cpcHigh: { ...a.cpcHigh, enabled: v } }))}
              >
                <div className="flex items-center gap-2">
                  <span className="text-xs text-[#8888a0]">Alertar se CPC &gt;</span>
                  <NumberInput
                    value={alerts.cpcHigh.threshold}
                    onChange={(v) => setAlerts((a) => ({ ...a, cpcHigh: { ...a.cpcHigh, threshold: v } }))}
                    prefix="R$"
                    step={0.5}
                  />
                </div>
              </AlertRow>

              {/* Budget pace */}
              <AlertRow
                icon={<DollarSign size={15} />}
                color="#6366f1"
                label="Budget quase esgotado"
                description="Alerta quando o orçamento mensal atingir o percentual configurado"
                enabled={alerts.budgetPace.enabled}
                onToggle={(v) => setAlerts((a) => ({ ...a, budgetPace: { ...a.budgetPace, enabled: v } }))}
              >
                <div className="flex items-center gap-2">
                  <span className="text-xs text-[#8888a0]">Alertar a partir de</span>
                  <NumberInput
                    value={alerts.budgetPace.threshold}
                    onChange={(v) => setAlerts((a) => ({ ...a, budgetPace: { ...a.budgetPace, threshold: v } }))}
                    suffix="%"
                    step={5}
                  />
                  <span className="text-xs text-[#8888a0]">do budget</span>
                </div>
              </AlertRow>

              {/* Zero conversions */}
              <AlertRow
                icon={<AlertCircle size={15} />}
                color="#ec4899"
                label="Campanha sem conversões"
                description="Alerta quando uma campanha ativa não registrar conversões por X dias"
                enabled={alerts.zeroConv.enabled}
                onToggle={(v) => setAlerts((a) => ({ ...a, zeroConv: { ...a.zeroConv, enabled: v } }))}
              >
                <div className="flex items-center gap-2">
                  <span className="text-xs text-[#8888a0]">Após</span>
                  <NumberInput
                    value={alerts.zeroConv.threshold}
                    onChange={(v) => setAlerts((a) => ({ ...a, zeroConv: { ...a.zeroConv, threshold: v } }))}
                    suffix="dias"
                    step={1}
                  />
                  <span className="text-xs text-[#8888a0]">sem conversão</span>
                </div>
              </AlertRow>
            </div>
          </div>
        </div>
      )}

      {/* ══ BRANDING ═════════════════════════════════════════════════ */}
      {tab === "branding" && (
        <div className="max-w-2xl space-y-5">
          {/* Logo */}
          <div className="bg-[#16161e] border border-[#1e1e2e] rounded-xl p-6">
            <h3 className="font-semibold text-[#e8e8f0] flex items-center gap-2 mb-5">
              <ImageIcon size={16} className="text-[#6366f1]" /> Logotipo
            </h3>
            <div className="flex items-center gap-5">
              <div className="w-20 h-20 rounded-xl bg-[#111118] border border-dashed border-[#1e1e2e] flex flex-col items-center justify-center gap-1">
                <ImageIcon size={22} className="text-[#555568]" />
                <span className="text-[#555568] text-[10px]">Logo</span>
              </div>
              <div className="flex-1">
                <p className="text-[#8888a0] text-xs mb-3">Formatos: PNG, SVG. Recomendado: 400×120px, fundo transparente.</p>
                <button className="px-4 py-2 bg-[#111118] border border-[#1e1e2e] hover:border-[#6366f1]/40 rounded-xl text-sm text-[#8888a0] hover:text-[#e8e8f0] transition-colors">
                  Fazer upload do logo
                </button>
              </div>
            </div>
          </div>

          {/* Colors */}
          <div className="bg-[#16161e] border border-[#1e1e2e] rounded-xl p-6">
            <h3 className="font-semibold text-[#e8e8f0] flex items-center gap-2 mb-5">
              <Palette size={16} className="text-[#6366f1]" /> Cores do Relatório
            </h3>
            <div className="space-y-5">
              <div>
                <label className="text-xs text-[#8888a0] mb-3 block">Cor de destaque (cabeçalho, gráficos)</label>
                <ColorSwatch value={branding.accentColor} onChange={(c) => setBranding((b) => ({ ...b, accentColor: c }))} />
                <div className="mt-3 flex items-center gap-2">
                  <div className="w-5 h-5 rounded-md border border-[#1e1e2e]" style={{ background: branding.accentColor }} />
                  <span className="text-xs font-mono text-[#8888a0]">{branding.accentColor}</span>
                </div>
              </div>
              <div className="border-t border-[#1e1e2e] pt-5">
                <label className="text-xs text-[#8888a0] mb-3 block">Cor secundária (KPIs positivos)</label>
                <ColorSwatch value={branding.secondaryColor} onChange={(c) => setBranding((b) => ({ ...b, secondaryColor: c }))} />
                <div className="mt-3 flex items-center gap-2">
                  <div className="w-5 h-5 rounded-md border border-[#1e1e2e]" style={{ background: branding.secondaryColor }} />
                  <span className="text-xs font-mono text-[#8888a0]">{branding.secondaryColor}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Text */}
          <div className="bg-[#16161e] border border-[#1e1e2e] rounded-xl p-6">
            <h3 className="font-semibold text-[#e8e8f0] flex items-center gap-2 mb-5">
              <Mail size={16} className="text-[#6366f1]" /> Textos do Relatório
            </h3>
            <div className="space-y-4">
              <div>
                <label className="text-xs text-[#8888a0] mb-1.5 block">Nome no cabeçalho</label>
                <input
                  value={branding.companyName}
                  onChange={(e) => setBranding((b) => ({ ...b, companyName: e.target.value }))}
                  className={inputClass}
                />
              </div>
              <div>
                <label className="text-xs text-[#8888a0] mb-1.5 block">Tagline / Slogan</label>
                <input
                  value={branding.tagline}
                  onChange={(e) => setBranding((b) => ({ ...b, tagline: e.target.value }))}
                  className={inputClass}
                />
              </div>
              <div>
                <label className="text-xs text-[#8888a0] mb-1.5 block">Mensagem padrão de envio</label>
                <textarea
                  value={branding.defaultMessage}
                  onChange={(e) => setBranding((b) => ({ ...b, defaultMessage: e.target.value }))}
                  rows={4}
                  className={cn(inputClass, "resize-none")}
                />
                <p className="text-[#555568] text-xs mt-1.5">Pré-preenchida ao criar um novo relatório.</p>
              </div>
            </div>
          </div>

          {/* Toggles */}
          <div className="bg-[#16161e] border border-[#1e1e2e] rounded-xl p-6">
            <h3 className="font-semibold text-[#e8e8f0] mb-5">Elementos do Relatório</h3>
            <div className="space-y-4">
              {[
                { key: "showLogo" as const, label: "Exibir logotipo no cabeçalho", desc: "Mostra o logo da agência no topo do relatório" },
                { key: "showFooter" as const, label: "Exibir rodapé com assinatura", desc: "Inclui nome, e-mail e slogan no rodapé" },
              ].map(({ key, label, desc }) => (
                <div key={key} className="flex items-start justify-between gap-4">
                  <div>
                    <p className="text-[#e8e8f0] text-sm">{label}</p>
                    <p className="text-[#555568] text-xs mt-0.5">{desc}</p>
                  </div>
                  <Toggle
                    checked={branding[key]}
                    onChange={(v) => setBranding((b) => ({ ...b, [key]: v }))}
                  />
                </div>
              ))}
            </div>
          </div>

          {/* Preview pill */}
          <div className="bg-[#111118] rounded-xl p-4 border border-[#1e1e2e]">
            <p className="text-[#555568] text-xs mb-3">Prévia do cabeçalho</p>
            <div
              className="rounded-xl p-4 flex items-center justify-between"
              style={{ background: `linear-gradient(135deg, ${branding.accentColor}30, ${branding.secondaryColor}20)`, border: `1px solid ${branding.accentColor}40` }}
            >
              <div>
                <p className="font-semibold text-sm text-white">{branding.companyName || "Agência"}</p>
                <p className="text-xs mt-0.5" style={{ color: branding.accentColor + "cc" }}>{branding.tagline || "Tagline"}</p>
              </div>
              <div className="w-10 h-10 rounded-lg flex items-center justify-center font-bold text-lg"
                style={{ background: branding.accentColor + "25", color: branding.accentColor }}>
                {(branding.companyName || "A").charAt(0)}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ── Save button (hidden on accounts tab) ── */}
      {tab !== "accounts" && (
        <div className="mt-6">
          <button
            onClick={handleSave}
            className="flex items-center gap-2 px-6 py-3 bg-[#6366f1] hover:bg-[#5558e8] rounded-xl text-white font-semibold text-sm transition-colors"
          >
            {saved ? <><Check size={15} /> Salvo!</> : <><Save size={15} /> Salvar Configurações</>}
          </button>
        </div>
      )}
    </AppShell>
  );
}
