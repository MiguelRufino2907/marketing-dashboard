"use client";
import { useEffect } from "react";
import { useRouter } from "next/navigation";
export default function ManagementPage() {
  const router = useRouter();
  useEffect(() => { router.replace("/management/accounts"); }, [router]);
  return null;
}
