"use client";

import AppShell from "@/components/layout/AppShell";
import { mockUsers } from "@/lib/mock-data";
import { Plus, Edit2, Trash2, Shield, BarChart2, Eye } from "lucide-react";
import { cn } from "@/lib/utils";

const roleConfig = {
  admin:   { label: "Admin",    color: "#6366f1", bg: "rgba(99,102,241,0.12)" },
  analyst: { label: "Analista", color: "#f59e0b", bg: "rgba(245,158,11,0.12)" },
  client:  { label: "Cliente",  color: "#22c55e", bg: "rgba(34,197,94,0.12)" },
};

const permissions = [
  { action: "Ver dashboard",     admin: true,  analyst: true,  client: true },
  { action: "Criar relatório",   admin: true,  analyst: true,  client: false },
  { action: "Enviar relatório",  admin: true,  analyst: true,  client: false },
  { action: "Agendar relatório", admin: true,  analyst: true,  client: false },
  { action: "Gerenciar contas",  admin: true,  analyst: false, client: false },
  { action: "Gerenciar usuários",admin: true,  analyst: false, client: false },
  { action: "Configurações",     admin: true,  analyst: false, client: false },
];

export default function UsersPage() {
  return (
    <AppShell title="Usuários e Permissões">
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* User list */}
        <div className="xl:col-span-2">
          <div className="flex items-center justify-between mb-4">
            <p className="text-[#8888a0] text-sm">{mockUsers.length} usuários cadastrados</p>
            <button className="flex items-center gap-2 px-4 py-2 bg-[#6366f1] hover:bg-[#5558e8] rounded-xl text-white text-sm font-medium transition-colors">
              <Plus size={14} /> Convidar
            </button>
          </div>

          <div className="space-y-2">
            {mockUsers.map((user) => {
              const rc = roleConfig[user.role];
              return (
                <div key={user.id} className={cn(
                  "bg-[#16161e] border border-[#1e1e2e] rounded-xl p-4 flex items-center justify-between card-hover",
                  !user.isActive && "opacity-60"
                )}>
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-sm"
                      style={{ background: rc.color + "40" }}>
                      {user.name.charAt(0)}
                    </div>
                    <div>
                      <p className="text-[#e8e8f0] font-medium text-sm">{user.name}</p>
                      <p className="text-[#555568] text-xs">{user.email}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-xs px-2.5 py-1 rounded-full font-medium" style={{ background: rc.bg, color: rc.color }}>
                      {rc.label}
                    </span>
                    <div className="text-right hidden md:block">
                      <p className="text-[#555568] text-[10px]">Último acesso</p>
                      <p className="text-[#8888a0] text-xs">{user.lastLogin}</p>
                    </div>
                    <span className={cn(
                      "w-2 h-2 rounded-full",
                      user.isActive ? "bg-green-400" : "bg-[#555568]"
                    )} />
                    <button className="p-1.5 rounded-lg hover:bg-[#1e1e2e] text-[#555568] hover:text-[#e8e8f0] transition-colors"><Edit2 size={13}/></button>
                    <button className="p-1.5 rounded-lg hover:bg-red-500/15 text-[#555568] hover:text-red-400 transition-colors"><Trash2 size={13}/></button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Permissions matrix */}
        <div>
          <h3 className="text-[#e8e8f0] font-semibold mb-4 flex items-center gap-2">
            <Shield size={15} className="text-[#6366f1]" /> Matriz de Permissões
          </h3>
          <div className="bg-[#16161e] border border-[#1e1e2e] rounded-xl overflow-hidden">
            <table className="w-full text-xs">
              <thead className="bg-[#111118]">
                <tr>
                  <th className="py-3 px-3 text-[#555568] text-left font-medium">Ação</th>
                  <th className="py-3 px-2 text-center" style={{ color: roleConfig.admin.color }}>Admin</th>
                  <th className="py-3 px-2 text-center" style={{ color: roleConfig.analyst.color }}>Analista</th>
                  <th className="py-3 px-2 text-center" style={{ color: roleConfig.client.color }}>Cliente</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1e1e2e]">
                {permissions.map((p) => (
                  <tr key={p.action} className="hover:bg-[#1e1e2e]/50">
                    <td className="py-2.5 px-3 text-[#8888a0]">{p.action}</td>
                    {["admin", "analyst", "client"].map((role) => (
                      <td key={role} className="py-2.5 px-2 text-center">
                        {p[role as keyof typeof p] ? (
                          <span className="text-green-400">✓</span>
                        ) : (
                          <span className="text-[#1e1e2e]">✗</span>
                        )}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </AppShell>
  );
}
