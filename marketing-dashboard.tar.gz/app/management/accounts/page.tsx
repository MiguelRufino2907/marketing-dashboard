"use client";

import AppShell from "@/components/layout/AppShell";
import { mockAccounts } from "@/lib/mock-data";
import StatusBadge from "@/components/shared/StatusBadge";
import { formatCurrency } from "@/lib/utils";
import { RefreshCw, Trash2, Link2, AlertCircle, CheckCircle2 } from "lucide-react";
import { cn } from "@/lib/utils";

const platformConfig = {
  meta:   { label: "Meta Ads",   color: "#1877F2", bg: "#1877F2" },
  google: { label: "Google Ads", color: "#4285F4", bg: "#4285F4" },
  tiktok: { label: "TikTok Ads", color: "#FF0050", bg: "#FF0050" },
};

export default function AccountsPage() {
  return (
    <AppShell title="Contas de Anúncios">
      <div className="flex items-center justify-between mb-6">
        <p className="text-[#8888a0] text-sm">{mockAccounts.length} contas configuradas</p>
        <button className="flex items-center gap-2 px-4 py-2 bg-[#6366f1] hover:bg-[#5558e8] rounded-xl text-white text-sm font-medium transition-colors">
          <Link2 size={14} /> Conectar Conta
        </button>
      </div>

      {/* Platform sections */}
      {(["meta", "google", "tiktok"] as const).map((platform) => {
        const accounts = mockAccounts.filter((a) => a.platform === platform);
        const cfg = platformConfig[platform];
        return (
          <div key={platform} className="mb-6">
            <div className="flex items-center gap-2 mb-3">
              <div className="w-2 h-2 rounded-full" style={{ background: cfg.color }} />
              <h3 className="text-[#e8e8f0] font-semibold text-sm">{cfg.label}</h3>
              <span className="text-[#555568] text-xs">({accounts.length} conta{accounts.length !== 1 ? "s" : ""})</span>
            </div>

            {accounts.length === 0 ? (
              <div className="bg-[#16161e] border border-dashed border-[#1e1e2e] rounded-xl p-6 flex items-center justify-center gap-3">
                <p className="text-[#555568] text-sm">Nenhuma conta conectada</p>
                <button
                  className="text-xs px-3 py-1.5 rounded-lg transition-colors"
                  style={{ background: cfg.color + "20", color: cfg.color }}
                >
                  + Conectar {cfg.label}
                </button>
              </div>
            ) : (
              <div className="space-y-2">
                {accounts.map((acc) => (
                  <div
                    key={acc.id}
                    className="bg-[#16161e] border border-[#1e1e2e] rounded-xl p-4 card-hover"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div
                          className="w-10 h-10 rounded-xl flex items-center justify-center text-white text-sm font-bold"
                          style={{ background: cfg.color + "20", color: cfg.color }}
                        >
                          {cfg.label.charAt(0)}
                        </div>
                        <div>
                          <p className="text-[#e8e8f0] font-medium text-sm">{acc.accountName}</p>
                          <p className="text-[#555568] text-xs font-mono">{acc.accountId}</p>
                        </div>
                      </div>

                      <div className="flex items-center gap-4">
                        <div className="text-right">
                          <p className="text-[#555568] text-xs">Gasto 30d</p>
                          <p className="metric-value text-[#e8e8f0] font-semibold text-sm">{formatCurrency(acc.spend30d)}</p>
                        </div>
                        <StatusBadge status={acc.status} />
                        <div className="flex gap-1">
                          {acc.status === "active" ? (
                            <div className="flex items-center gap-1 text-xs text-green-400">
                              <CheckCircle2 size={13} />
                              Sincronizado
                            </div>
                          ) : (
                            <div className="flex items-center gap-1 text-xs text-orange-400">
                              <AlertCircle size={13} />
                              Reconectar
                            </div>
                          )}
                          <button className="p-2 rounded-lg hover:bg-[#1e1e2e] text-[#555568] hover:text-[#e8e8f0] transition-colors" title="Sincronizar">
                            <RefreshCw size={13} />
                          </button>
                          <button className="p-2 rounded-lg hover:bg-red-500/15 text-[#555568] hover:text-red-400 transition-colors" title="Remover">
                            <Trash2 size={13} />
                          </button>
                        </div>
                      </div>
                    </div>
                    <div className="mt-3 pt-3 border-t border-[#1e1e2e] text-xs text-[#555568]">
                      Última sincronização: <span className="text-[#8888a0]">{acc.lastSync}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        );
      })}
    </AppShell>
  );
}
