"use client";

import { useState, useEffect } from "react";
import AppShell from "@/components/layout/AppShell";
import { formatCurrency } from "@/lib/utils";
import { Plus, Edit2, MoreHorizontal, BarChart2, Wifi } from "lucide-react";
import { cn } from "@/lib/utils";
import { getClients } from "@/lib/data/clients";

type ClientItem = {
  id: string;
  name: string;
  logo_url?: string | null;
  primary_color?: string;
  contact_email?: string | null;
  contact_phone?: string | null;
  monthly_budget?: number | null;
  is_active?: boolean;
  created_at?: string;
  // Mock compat
  contactEmail?: string;
  contactPhone?: string;
  isActive?: boolean;
  createdAt?: string;
  totalSpend?: number;
  campaigns?: number;
  ad_accounts?: { platform: string; status: string }[];
};

export default function ClientsPage() {
  const [clients, setClients] = useState<ClientItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getClients()
      .then((data) => setClients(data as ClientItem[]))
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  const isActive = (c: ClientItem) => c.is_active ?? c.isActive ?? true;
  const email    = (c: ClientItem) => c.contact_email ?? c.contactEmail ?? "—";
  const phone    = (c: ClientItem) => c.contact_phone ?? c.contactPhone;
  const since    = (c: ClientItem) => (c.created_at ?? c.createdAt ?? "").slice(0, 10);
  const budget   = (c: ClientItem) => c.monthly_budget ?? c.totalSpend ?? 0;
  const color    = (c: ClientItem) => c.primary_color ?? "#6366f1";

  const activeCount = clients.filter(isActive).length;

  return (
    <AppShell title="Clientes">
      <div className="flex items-center justify-between mb-6">
        <p className="text-[#8888a0] text-sm">
          {loading ? "Carregando..." : `${activeCount} cliente${activeCount !== 1 ? "s" : ""} ativo${activeCount !== 1 ? "s" : ""}`}
        </p>
        <button className="flex items-center gap-2 px-4 py-2 bg-[#6366f1] hover:bg-[#5558e8] rounded-xl text-white text-sm font-medium transition-colors">
          <Plus size={14} /> Novo Cliente
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {loading
          ? Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="bg-[#16161e] border border-[#1e1e2e] rounded-xl p-5 animate-pulse">
                <div className="h-11 w-11 bg-[#1e1e2e] rounded-xl mb-4" />
                <div className="h-4 bg-[#1e1e2e] rounded w-3/4 mb-2" />
                <div className="h-3 bg-[#1e1e2e] rounded w-1/2" />
              </div>
            ))
          : clients.map((client) => (
              <div
                key={client.id}
                className={cn(
                  "bg-[#16161e] border border-[#1e1e2e] rounded-xl p-5 card-hover",
                  !isActive(client) && "opacity-60"
                )}
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    {client.logo_url ? (
                      <img
                        src={client.logo_url}
                        alt={client.name}
                        className="w-11 h-11 rounded-xl object-cover"
                      />
                    ) : (
                      <div
                        className="w-11 h-11 rounded-xl flex items-center justify-center font-display font-bold text-lg text-white"
                        style={{ background: `${color(client)}25`, color: color(client) }}
                      >
                        {client.name.charAt(0)}
                      </div>
                    )}
                    <div>
                      <h3 className="text-[#e8e8f0] font-semibold text-sm">{client.name}</h3>
                      <span
                        className={cn(
                          "text-[10px] px-2 py-0.5 rounded-full font-medium",
                          isActive(client)
                            ? "bg-green-500/15 text-green-400"
                            : "bg-slate-500/15 text-slate-400"
                        )}
                      >
                        {isActive(client) ? "Ativo" : "Inativo"}
                      </span>
                    </div>
                  </div>
                  <button className="p-1.5 rounded-lg hover:bg-[#1e1e2e] text-[#555568] hover:text-[#e8e8f0] transition-colors">
                    <MoreHorizontal size={14} />
                  </button>
                </div>

                <div className="space-y-2 mb-4">
                  <div className="flex justify-between text-xs">
                    <span className="text-[#555568]">E-mail</span>
                    <span className="text-[#8888a0] truncate max-w-[140px]">{email(client)}</span>
                  </div>
                  {phone(client) && (
                    <div className="flex justify-between text-xs">
                      <span className="text-[#555568]">WhatsApp</span>
                      <span className="text-[#8888a0]">{phone(client)}</span>
                    </div>
                  )}
                  <div className="flex justify-between text-xs">
                    <span className="text-[#555568]">Cliente desde</span>
                    <span className="text-[#8888a0]">{since(client)}</span>
                  </div>
                  {/* Contas vinculadas */}
                  {client.ad_accounts && client.ad_accounts.length > 0 && (
                    <div className="flex justify-between text-xs">
                      <span className="text-[#555568]">Plataformas</span>
                      <div className="flex gap-1 items-center">
                        {client.ad_accounts.map((acc) => {
                          const colors: Record<string, string> = {
                            meta: "#1877F2",
                            google: "#4285F4",
                            tiktok: "#FF0050",
                          };
                          return (
                            <span
                              key={`${acc.platform}-${acc.status}`}
                              className="w-2 h-2 rounded-full"
                              style={{ background: colors[acc.platform] ?? "#6366f1" }}
                              title={`${acc.platform} (${acc.status})`}
                            />
                          );
                        })}
                      </div>
                    </div>
                  )}
                </div>

                <div className="border-t border-[#1e1e2e] pt-4 grid grid-cols-2 gap-3">
                  <div className="bg-[#111118] rounded-xl p-3">
                    <div className="flex items-center gap-1.5 text-[#555568] text-xs mb-1">
                      <BarChart2 size={10} /> Budget Mensal
                    </div>
                    <p className="metric-value text-[#e8e8f0] font-semibold text-sm">
                      {budget(client) ? formatCurrency(budget(client)) : "—"}
                    </p>
                  </div>
                  <div className="bg-[#111118] rounded-xl p-3">
                    <div className="flex items-center gap-1.5 text-[#555568] text-xs mb-1">
                      <Wifi size={10} /> Contas
                    </div>
                    <p className="metric-value text-[#e8e8f0] font-semibold text-sm">
                      {client.ad_accounts?.length ?? (client.campaigns ?? 0)}
                    </p>
                  </div>
                </div>

                <button className="mt-3 w-full flex items-center justify-center gap-1.5 py-2 bg-[#111118] hover:bg-[#1e1e2e] rounded-xl text-xs text-[#8888a0] hover:text-[#e8e8f0] transition-colors">
                  <Edit2 size={11} /> Editar cliente
                </button>
              </div>
            ))}

        {/* Add new client card */}
        <button className="bg-[#16161e] border border-dashed border-[#1e1e2e] rounded-xl p-5 flex flex-col items-center justify-center gap-3 hover:border-[#6366f1]/40 hover:bg-[#6366f1]/5 transition-all group min-h-[200px]">
          <div className="w-11 h-11 rounded-xl bg-[#1e1e2e] group-hover:bg-[#6366f1]/15 flex items-center justify-center transition-colors">
            <Plus size={20} className="text-[#555568] group-hover:text-[#6366f1] transition-colors" />
          </div>
          <span className="text-[#555568] group-hover:text-[#8888a0] text-sm transition-colors">
            Adicionar cliente
          </span>
        </button>
      </div>
    </AppShell>
  );
}
