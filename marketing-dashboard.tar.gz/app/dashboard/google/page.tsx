"use client";

import { useState, useMemo, useCallback } from "react";
import AppShell from "@/components/layout/AppShell";
import MetricCard from "@/components/dashboard/MetricCard";
import CampaignTable from "@/components/dashboard/CampaignTable";
import {
  mockCampaigns, mockDailyMetrics, mockGoogleKeywords, mockDevicePerformance,
  type GoogleKeyword,
} from "@/lib/mock-data";
import { formatCurrency, formatNumber, formatPercent, formatROAS, cn } from "@/lib/utils";
import {
  DollarSign, Eye, MousePointer, TrendingUp, ShoppingCart, ChevronDown,
  ChevronUp, Search, Monitor, Smartphone, Tablet,
} from "lucide-react";
import {
  LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, Legend, Cell,
} from "recharts";

type Period = "7d" | "14d" | "30d";
type CampaignType = "all" | "search" | "display" | "pmax";
const PERIOD_DAYS: Record<Period, number> = { "7d": 7, "14d": 14, "30d": 30 };

const MATCH_TYPE_LABEL: Record<GoogleKeyword["matchType"], string> = {
  exact: "Exata",
  phrase: "Frase",
  broad: "Ampla",
};
const MATCH_TYPE_COLOR: Record<GoogleKeyword["matchType"], string> = {
  exact: "#22c55e",
  phrase: "#f59e0b",
  broad: "#8888a0",
};

function QualityBadge({ score }: { score: number }) {
  const color = score >= 8 ? "#22c55e" : score >= 5 ? "#f59e0b" : "#ef4444";
  return (
    <div className="flex items-center gap-1">
      <div className="flex gap-0.5">
        {Array.from({ length: 10 }).map((_, i) => (
          <div key={i} className="w-1.5 h-3 rounded-sm transition-all"
            style={{ background: i < score ? color : "#1e1e2e" }} />
        ))}
      </div>
      <span className="metric-value text-xs font-bold ml-1" style={{ color }}>{score}</span>
    </div>
  );
}

function PeriodSelector({ value, onChange }: { value: Period; onChange: (v: Period) => void }) {
  return (
    <div className="flex bg-[#111118] border border-[#1e1e2e] rounded-xl p-1 gap-0.5">
      {(["7d", "14d", "30d"] as Period[]).map((p) => (
        <button key={p} onClick={() => onChange(p)}
          className={cn("px-3 py-1.5 rounded-lg text-xs font-medium transition-all",
            value === p ? "bg-[#4285F4] text-white" : "text-[#555568] hover:text-[#8888a0]")}>
          {p}
        </button>
      ))}
    </div>
  );
}

const DEVICE_ICON: Record<string, React.ReactNode> = {
  Mobile: <Smartphone size={13} />,
  Desktop: <Monitor size={13} />,
  Tablet: <Tablet size={13} />,
};
const DEVICE_COLOR: Record<string, string> = {
  Mobile: "#4285F4",
  Desktop: "#FBBC05",
  Tablet: "#34A853",
};

export default function GoogleDashboardPage() {
  const [period, setPeriod] = useState<Period>("30d");
  const [campaignType, setCampaignType] = useState<CampaignType>("all");
  const [sortKw, setSortKw] = useState<keyof GoogleKeyword>("spend");
  const [sortKwDir, setSortKwDir] = useState<"asc" | "desc">("desc");
  const [loadingFilter, setLoadingFilter] = useState(false);

  const handlePeriodChange = useCallback((p: Period) => {
    setLoadingFilter(true);
    setPeriod(p);
    setTimeout(() => setLoadingFilter(false), 300);
  }, []);

  const googleCampaigns = useMemo(() => {
    const all = mockCampaigns.filter((c) => c.platform === "google");
    if (campaignType === "all") return all;
    if (campaignType === "search") return all.filter((c) => c.campaignName.toLowerCase().includes("search"));
    if (campaignType === "display") return all.filter((c) => c.campaignName.toLowerCase().includes("display"));
    if (campaignType === "pmax") return all.filter((c) => c.campaignName.toLowerCase().includes("performance"));
    return all;
  }, [campaignType]);

  const kpis = useMemo(() => {
    const totalSpend = googleCampaigns.reduce((s, c) => s + c.spend, 0);
    const totalImpressions = googleCampaigns.reduce((s, c) => s + c.impressions, 0);
    const totalClicks = googleCampaigns.reduce((s, c) => s + c.clicks, 0);
    const totalConversions = googleCampaigns.reduce((s, c) => s + c.conversions, 0);
    const avgROAS = googleCampaigns.length > 0 ? googleCampaigns.reduce((s, c) => s + c.roas, 0) / googleCampaigns.length : 0;
    return {
      totalSpend, totalImpressions, totalClicks, totalConversions, avgROAS,
      avgCPA: totalConversions > 0 ? totalSpend / totalConversions : 0,
      ctr: totalImpressions > 0 ? (totalClicks / totalImpressions) * 100 : 0,
      cpc: totalClicks > 0 ? totalSpend / totalClicks : 0,
    };
  }, [googleCampaigns]);

  const days = PERIOD_DAYS[period];
  const chartData = useMemo(
    () => mockDailyMetrics.slice(-days).map((d) => ({
      date: d.date,
      impressoes: Math.round(d.google / 0.061), // estima impressões a partir do spend
      conversoes: Math.round(d.google / 28),     // estima conversões
    })),
    [days]
  );

  const sortedKeywords = useMemo(() => {
    return [...mockGoogleKeywords].sort((a, b) => {
      const va = a[sortKw] as number | string;
      const vb = b[sortKw] as number | string;
      if (typeof va === "number" && typeof vb === "number")
        return sortKwDir === "asc" ? va - vb : vb - va;
      return sortKwDir === "asc"
        ? String(va).localeCompare(String(vb))
        : String(vb).localeCompare(String(va));
    });
  }, [sortKw, sortKwDir]);

  const handleKwSort = (field: keyof GoogleKeyword) => {
    if (sortKw === field) setSortKwDir((d) => (d === "asc" ? "desc" : "asc"));
    else { setSortKw(field); setSortKwDir("desc"); }
  };

  const KwTH = ({ label, field }: { label: string; field?: keyof GoogleKeyword }) => (
    <th className={cn("py-3 px-3 text-xs font-medium text-[#555568] text-left whitespace-nowrap",
      field && "cursor-pointer hover:text-[#8888a0]")}
      onClick={() => field && handleKwSort(field)}>
      <span className="inline-flex items-center gap-1">
        {label}
        {field && (sortKw === field
          ? (sortKwDir === "asc" ? <ChevronUp size={11} className="text-[#4285F4]" /> : <ChevronDown size={11} className="text-[#4285F4]" />)
          : <ChevronUp size={11} className="text-[#555568]" />)}
      </span>
    </th>
  );

  return (
    <AppShell title="Google Ads Dashboard">
      {/* Header */}
      <div className="flex flex-wrap items-center gap-3 mb-6 p-4 rounded-xl bg-[#4285F4]/10 border border-[#4285F4]/20">
        <div className="w-10 h-10 rounded-xl bg-[#4285F4] flex items-center justify-center text-white font-bold text-sm select-none">G</div>
        <div>
          <h2 className="text-[#e8e8f0] font-semibold">Google Ads — Search, Display & YouTube</h2>
          <p className="text-[#8888a0] text-xs">
            <span className="pulse-dot inline-block w-1.5 h-1.5 rounded-full bg-green-400 mr-1.5" />
            {googleCampaigns.filter((c) => c.status === "active").length} ativas • 987-654-3210
          </p>
        </div>
        <div className="ml-auto flex flex-wrap items-center gap-2">
          {/* Tipo de campanha */}
          <div className="relative">
            <select value={campaignType} onChange={(e) => setCampaignType(e.target.value as CampaignType)}
              className="appearance-none bg-[#111118] border border-[#1e1e2e] text-[#e8e8f0] text-xs rounded-xl pl-3 pr-7 py-2 focus:outline-none focus:border-[#4285F4]">
              <option value="all">Todos os tipos</option>
              <option value="search">Search</option>
              <option value="display">Display</option>
              <option value="pmax">Performance Max</option>
            </select>
            <ChevronDown size={11} className="absolute right-2 top-1/2 -translate-y-1/2 text-[#555568] pointer-events-none" />
          </div>
          <PeriodSelector value={period} onChange={handlePeriodChange} />
          <div className="text-right">
            <p className="text-[#555568] text-[10px]">Invest. {period}</p>
            <p className="metric-value text-[#4285F4] font-bold text-sm">{formatCurrency(kpis.totalSpend)}</p>
          </div>
        </div>
      </div>

      {/* KPIs */}
      {loadingFilter ? (
        <div className="grid grid-cols-4 lg:grid-cols-8 gap-3 mb-6">
          {Array.from({ length: 8 }).map((_, i) => <div key={i} className="bg-[#16161e] border border-[#1e1e2e] rounded-xl h-24 animate-pulse" />)}
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-3 mb-6">
          {[
            { title: "Investimento", value: formatCurrency(kpis.totalSpend), delta: 11.3, icon: <DollarSign size={13}/>, color: "#4285F4" },
            { title: "Impressões", value: formatNumber(kpis.totalImpressions), delta: 6.4, icon: <Eye size={13}/>, color: "#FBBC05" },
            { title: "Cliques", value: formatNumber(kpis.totalClicks), delta: 13.7, icon: <MousePointer size={13}/>, color: "#34A853" },
            { title: "CTR", value: formatPercent(kpis.ctr), delta: 2.1, icon: <TrendingUp size={13}/>, color: "#4285F4" },
            { title: "CPC Médio", value: formatCurrency(kpis.cpc), delta: -4.2, icon: <DollarSign size={13}/>, color: "#FBBC05" },
            { title: "Conversões", value: String(kpis.totalConversions), delta: 19.2, icon: <ShoppingCart size={13}/>, color: "#34A853" },
            { title: "CPA", value: formatCurrency(kpis.avgCPA), delta: -8.9, icon: <DollarSign size={13}/>, color: "#EA4335" },
            { title: "ROAS", value: formatROAS(kpis.avgROAS), delta: 7.8, icon: <TrendingUp size={13}/>, color: "#4285F4" },
          ].map((k) => <MetricCard key={k.title} title={k.title} value={k.value} delta={k.delta} icon={k.icon} accentColor={k.color} />)}
        </div>
      )}

      {/* Charts row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-6">
        {/* Impressões vs Conversões */}
        <div className="lg:col-span-2 bg-[#16161e] border border-[#1e1e2e] rounded-xl p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-[#e8e8f0] font-semibold">Impressões × Conversões — {period}</h3>
              <p className="text-[#555568] text-xs mt-0.5">Tendência diária</p>
            </div>
            <div className="flex gap-3 text-xs text-[#8888a0]">
              <span className="flex items-center gap-1.5"><span className="w-3 h-0.5 inline-block rounded bg-[#4285F4]" />Impressões</span>
              <span className="flex items-center gap-1.5"><span className="w-3 h-0.5 inline-block rounded bg-[#34A853]" />Conversões</span>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e1e2e" vertical={false} />
              <XAxis dataKey="date" tick={{ fill: "#555568", fontSize: 11 }} axisLine={false} tickLine={false} interval={Math.floor(days / 6)} />
              <YAxis yAxisId="left" tick={{ fill: "#555568", fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={(v) => formatNumber(v)} />
              <YAxis yAxisId="right" orientation="right" tick={{ fill: "#555568", fontSize: 11 }} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={{ background: "#16161e", border: "1px solid #1e1e2e", borderRadius: 12 }} labelStyle={{ color: "#8888a0" }} itemStyle={{ color: "#e8e8f0" }} />
              <Line yAxisId="left" type="monotone" dataKey="impressoes" name="Impressões" stroke="#4285F4" strokeWidth={2} dot={false} />
              <Line yAxisId="right" type="monotone" dataKey="conversoes" name="Conversões" stroke="#34A853" strokeWidth={2} dot={false} strokeDasharray="5 3" />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Performance por dispositivo */}
        <div className="bg-[#16161e] border border-[#1e1e2e] rounded-xl p-5">
          <h3 className="text-[#e8e8f0] font-semibold mb-1">Por Dispositivo</h3>
          <p className="text-[#555568] text-xs mb-4">Cliques e conversões</p>
          <ResponsiveContainer width="100%" height={180}>
            <BarChart data={mockDevicePerformance} layout="vertical" margin={{ top: 0, right: 8, bottom: 0, left: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e1e2e" horizontal={false} />
              <XAxis type="number" tick={{ fill: "#555568", fontSize: 10 }} axisLine={false} tickLine={false} tickFormatter={(v) => formatNumber(v)} />
              <YAxis type="category" dataKey="device" tick={{ fill: "#8888a0", fontSize: 11 }} axisLine={false} tickLine={false}
                tickFormatter={(v) => v}
                width={56}
              />
              <Tooltip contentStyle={{ background: "#16161e", border: "1px solid #1e1e2e", borderRadius: 12 }} labelStyle={{ color: "#8888a0" }} itemStyle={{ color: "#e8e8f0" }} />
              <Bar dataKey="clicks" name="Cliques" radius={[0, 4, 4, 0]}>
                {mockDevicePerformance.map((d) => (
                  <Cell key={d.device} fill={DEVICE_COLOR[d.device] ?? "#6366f1"} fillOpacity={0.85} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
          <div className="mt-4 space-y-2">
            {mockDevicePerformance.map((d) => (
              <div key={d.device} className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <span style={{ color: DEVICE_COLOR[d.device] }}>{DEVICE_ICON[d.device]}</span>
                  <span className="text-[#8888a0]">{d.device}</span>
                </div>
                <div className="flex gap-4">
                  <span className="metric-value text-[#e8e8f0]">{d.conversions} conv.</span>
                  <span className="metric-value text-[#555568]">CPA {formatCurrency(d.cpa)}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Campaigns */}
      <div className="mb-6">
        <CampaignTable platform="google" />
      </div>

      {/* Keywords Table */}
      <div className="bg-[#16161e] border border-[#1e1e2e] rounded-xl overflow-hidden">
        <div className="flex items-center justify-between p-4 border-b border-[#1e1e2e]">
          <div>
            <h3 className="text-[#e8e8f0] font-semibold">Palavras-chave Top</h3>
            <p className="text-[#555568] text-xs mt-0.5">Ordenadas por clique · {mockGoogleKeywords.length} keywords</p>
          </div>
          <div className="flex items-center gap-1.5 text-xs text-[#555568]">
            <Search size={12} />
            <span>Qualidade avaliada pelo Google</span>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-[#111118]">
              <tr>
                <KwTH label="Keyword" />
                <KwTH label="Match" field="matchType" />
                <KwTH label="Campanha" />
                <KwTH label="Impressões" field="impressions" />
                <KwTH label="Cliques" field="clicks" />
                <KwTH label="CTR" field="ctr" />
                <KwTH label="CPC" field="cpc" />
                <KwTH label="Conversões" field="conversions" />
                <KwTH label="CPA" field="cpa" />
                <KwTH label="Gasto" field="spend" />
                <KwTH label="Q. Score" field="qualityScore" />
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1e1e2e]">
              {sortedKeywords.map((kw) => (
                <tr key={kw.id} className="hover:bg-[#1e1e2e]/50 transition-colors">
                  <td className="py-3 px-3 font-mono text-sm text-[#e8e8f0]">{kw.keyword}</td>
                  <td className="py-3 px-3">
                    <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full border"
                      style={{ color: MATCH_TYPE_COLOR[kw.matchType], borderColor: `${MATCH_TYPE_COLOR[kw.matchType]}40`, background: `${MATCH_TYPE_COLOR[kw.matchType]}15` }}>
                      {MATCH_TYPE_LABEL[kw.matchType]}
                    </span>
                  </td>
                  <td className="py-3 px-3 text-xs text-[#8888a0] max-w-[160px] truncate">{kw.campaignName}</td>
                  <td className="py-3 px-3 text-right metric-value text-sm text-[#8888a0]">{formatNumber(kw.impressions)}</td>
                  <td className="py-3 px-3 text-right metric-value text-sm text-[#e8e8f0]">{formatNumber(kw.clicks)}</td>
                  <td className="py-3 px-3 text-right metric-value text-sm text-[#8888a0]">{formatPercent(kw.ctr)}</td>
                  <td className="py-3 px-3 text-right metric-value text-sm text-[#8888a0]">{formatCurrency(kw.cpc)}</td>
                  <td className="py-3 px-3 text-right metric-value text-sm text-[#e8e8f0] font-semibold">{kw.conversions}</td>
                  <td className="py-3 px-3 text-right metric-value text-sm text-[#8888a0]">{formatCurrency(kw.cpa)}</td>
                  <td className="py-3 px-3 text-right metric-value text-sm text-[#e8e8f0]">{formatCurrency(kw.spend)}</td>
                  <td className="py-3 px-3"><QualityBadge score={kw.qualityScore} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </AppShell>
  );
}
