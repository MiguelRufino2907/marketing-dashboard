"use client";

import { useState, useEffect, useCallback, useMemo } from "react";
import AppShell from "@/components/layout/AppShell";
import MetricCard from "@/components/dashboard/MetricCard";
import PerformanceChart from "@/components/dashboard/PerformanceChart";
import { BudgetPieChart } from "@/components/dashboard/ComparisonChart";
import CampaignTable from "@/components/dashboard/CampaignTable";
import { formatCurrency, formatNumber, formatROAS } from "@/lib/utils";
import { subDays, format } from "date-fns";
import {
  DollarSign, TrendingUp, Users, ShoppingCart, BarChart2,
} from "lucide-react";
import { getClientKPIs, getDailyMetrics, getPlatformBreakdown } from "@/lib/data/metrics";
import { useRealtimeMetrics } from "@/hooks/useRealtimeMetrics";
import type { KPISummary, DailyPoint } from "@/lib/data/metrics";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend,
} from "recharts";

const DEFAULT_FROM = format(subDays(new Date(), 29), "yyyy-MM-dd");
const DEFAULT_TO = format(new Date(), "yyyy-MM-dd");

const PLATFORM_COLORS: Record<string, string> = {
  Meta: "#1877F2",
  Google: "#4285F4",
  TikTok: "#FF0050",
};

function InvestResultChart({ data, loading }: {
  data: { platform: string; spend: number; revenue: number; color: string }[];
  loading: boolean;
}) {
  return (
    <div className="bg-[#16161e] border border-[#1e1e2e] rounded-xl p-5">
      <h3 className="text-[#e8e8f0] font-semibold text-base mb-1">Investimento × Receita</h3>
      <p className="text-[#8888a0] text-xs mb-4">Comparativo por plataforma</p>
      {loading ? (
        <div className="h-[200px] flex items-center justify-center">
          <div className="w-6 h-6 rounded-full border-2 border-[#1e1e2e] border-t-[#6366f1] animate-spin" />
        </div>
      ) : (
        <ResponsiveContainer width="100%" height={200}>
          <BarChart data={data} margin={{ top: 4, right: 4, bottom: 0, left: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#1e1e2e" vertical={false} />
            <XAxis dataKey="platform" tick={{ fill: "#555568", fontSize: 11 }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fill: "#555568", fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={(v) => `R$${(v / 1000).toFixed(0)}k`} />
            <Tooltip
              contentStyle={{ background: "#16161e", border: "1px solid #1e1e2e", borderRadius: 12 }}
              labelStyle={{ color: "#8888a0" }}
              itemStyle={{ color: "#e8e8f0" }}
              // eslint-disable-next-line @typescript-eslint/no-explicit-any
              formatter={(v: any) => formatCurrency(Number(v))}
            />
            <Legend
              iconType="square"
              iconSize={8}
              formatter={(v) => <span style={{ color: "#8888a0", fontSize: 11 }}>{v}</span>}
            />
            <Bar dataKey="spend" name="Investimento" fill="#6366f1" fillOpacity={0.85} radius={[4, 4, 0, 0]} />
            <Bar dataKey="revenue" name="Receita" fill="#22c55e" fillOpacity={0.85} radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      )}
    </div>
  );
}

export default function DashboardPage() {
  const [kpis, setKpis] = useState<KPISummary | null>(null);
  const [dailyData, setDailyData] = useState<DailyPoint[]>([]);
  const [platformData, setPlatformData] = useState<{ platform: string; spend: number; pct: number; color: string }[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchAll = useCallback(async () => {
    try {
      const filter = { dateFrom: DEFAULT_FROM, dateTo: DEFAULT_TO };
      const [kpiData, daily, platforms] = await Promise.all([
        getClientKPIs(filter),
        getDailyMetrics(filter),
        getPlatformBreakdown(filter),
      ]);
      setKpis(kpiData);
      setDailyData(daily);
      setPlatformData(platforms);
    } catch {
      // fallback silencioso — mock data já é retornado pelas funções
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchAll(); }, [fetchAll]);
  useRealtimeMetrics({ clientId: "all", onNewData: fetchAll });

  const sparkFrom = (key: keyof DailyPoint) =>
    dailyData.slice(-14).map((d) => Number(d[key]) || 0);

  // 4 hero KPIs
  const heroKpis = useMemo(() => kpis ? [
    {
      title: "Investimento Total",
      value: formatCurrency(kpis.spend),
      delta: 12.4,
      icon: <DollarSign size={18} />,
      spark: sparkFrom("spend"),
      color: "#6366f1",
    },
    {
      title: "Receita Atribuída",
      value: formatCurrency(kpis.revenue),
      delta: 18.7,
      icon: <TrendingUp size={18} />,
      spark: sparkFrom("spend").map((v) => v * 4.2),
      color: "#22c55e",
    },
    {
      title: "ROAS Médio",
      value: formatROAS(kpis.roas),
      delta: 9.4,
      icon: <BarChart2 size={18} />,
      spark: [3.2, 3.5, 3.8, 3.6, 3.9, 4.1, 3.8, 4.0, 4.2, 4.0, 4.3, 4.1, 4.2, 4.2],
      color: "#f59e0b",
    },
    {
      title: "Leads Gerados",
      value: formatNumber(kpis.conversions),
      delta: 22.3,
      icon: <Users size={18} />,
      spark: sparkFrom("conversions"),
      color: "#06b6d4",
    },
  // eslint-disable-next-line react-hooks/exhaustive-deps
  ] : [], [kpis, dailyData]);

  // KPIs secundários
  const secondaryKpis = useMemo(() => kpis ? [
    { title: "Impressões", value: formatNumber(kpis.impressions), delta: 8.2, icon: <DollarSign size={15} />, spark: sparkFrom("impressions"), color: "#8b5cf6" },
    { title: "Cliques", value: formatNumber(kpis.clicks), delta: 5.7, icon: <ShoppingCart size={15} />, spark: sparkFrom("clicks"), color: "#06b6d4" },
    { title: "CTR Médio", value: `${kpis.ctr.toFixed(2)}%`, delta: 3.1, icon: <BarChart2 size={15} />, spark: [], color: "#10b981" },
    { title: "CPC Médio", value: formatCurrency(kpis.cpc), delta: -1.8, icon: <DollarSign size={15} />, spark: [], color: "#ec4899" },
    { title: "CPA Médio", value: formatCurrency(kpis.cpa), delta: -6.2, icon: <DollarSign size={15} />, spark: [], color: "#f97316" },
    { title: "CPM Médio", value: formatCurrency(kpis.cpm), delta: -2.3, icon: <DollarSign size={15} />, spark: [], color: "#f59e0b" },
  // eslint-disable-next-line react-hooks/exhaustive-deps
  ] : [], [kpis, dailyData]);

  // Dados para o gráfico Investimento × Receita
  const investRevenueData = useMemo(() => {
    if (!platformData.length) return [];
    // Para cada plataforma, estimamos receita com base em ROAS fixo por plataforma
    const roasByPlatform: Record<string, number> = { Meta: 5.1, Google: 4.8, TikTok: 2.2 };
    return platformData.map((p) => ({
      platform: p.platform,
      spend: Math.round(p.spend),
      revenue: Math.round(p.spend * (roasByPlatform[p.platform] ?? 3)),
      color: PLATFORM_COLORS[p.platform] ?? "#6366f1",
    }));
  }, [platformData]);

  return (
    <AppShell title="Dashboard Consolidado">
      {/* ── Plataformas Strip ── */}
      <div className="flex gap-3 mb-6">
        {(platformData.length ? platformData : [
          { platform: "Meta", spend: 0, pct: 0, color: "#1877F2" },
          { platform: "Google", spend: 0, pct: 0, color: "#4285F4" },
          { platform: "TikTok", spend: 0, pct: 0, color: "#FF0050" },
        ]).map((p) => (
          <div key={p.platform} className="flex-1 bg-[#16161e] border border-[#1e1e2e] rounded-xl px-4 py-3 flex items-center gap-3 card-hover">
            <div className="w-3 h-3 rounded-full flex-shrink-0" style={{ background: p.color, boxShadow: `0 0 8px ${p.color}60` }} />
            <div className="min-w-0">
              <p className="text-[#555568] text-xs">{p.platform}</p>
              <p className="metric-value text-[#e8e8f0] font-semibold text-sm">
                {loading ? "—" : formatCurrency(p.spend)}
              </p>
            </div>
            <div className="ml-auto text-right">
              <p className="text-[#555568] text-xs">Share</p>
              <p className="metric-value text-[#22c55e] font-semibold text-sm">
                {loading ? "—" : `${p.pct.toFixed(1)}%`}
              </p>
            </div>
          </div>
        ))}
      </div>

      {/* ── 4 Hero KPIs ── */}
      {loading ? (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="bg-[#16161e] border border-[#1e1e2e] rounded-xl h-32 animate-pulse" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          {heroKpis.map((kpi) => (
            <MetricCard
              key={kpi.title}
              title={kpi.title}
              value={kpi.value}
              delta={kpi.delta}
              icon={kpi.icon}
              sparkData={kpi.spark}
              accentColor={kpi.color}
              className="!p-6"
            />
          ))}
        </div>
      )}

      {/* ── Secundários ── */}
      {loading ? (
        <div className="grid grid-cols-3 lg:grid-cols-6 gap-3 mb-6">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="bg-[#16161e] border border-[#1e1e2e] rounded-xl h-24 animate-pulse" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-3 lg:grid-cols-6 gap-3 mb-6">
          {secondaryKpis.map((kpi) => (
            <MetricCard
              key={kpi.title}
              title={kpi.title}
              value={kpi.value}
              delta={kpi.delta}
              icon={kpi.icon}
              sparkData={kpi.spark}
              accentColor={kpi.color}
            />
          ))}
        </div>
      )}

      {/* ── Charts ── */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-6">
        <div className="lg:col-span-2">
          <PerformanceChart data={dailyData} loading={loading} />
        </div>
        <div className="space-y-4">
          <InvestResultChart data={investRevenueData} loading={loading} />
          <BudgetPieChart data={platformData} loading={loading} />
        </div>
      </div>

      {/* ── Campaign Table ── */}
      <CampaignTable />
    </AppShell>
  );
}
