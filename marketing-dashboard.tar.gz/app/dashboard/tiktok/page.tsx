"use client";

import { useState, useMemo, useCallback } from "react";
import AppShell from "@/components/layout/AppShell";
import MetricCard from "@/components/dashboard/MetricCard";
import CampaignTable from "@/components/dashboard/CampaignTable";
import {
  mockCampaigns, mockDailyMetrics, mockTikTokCreatives,
  type TikTokCreative,
} from "@/lib/mock-data";
import { formatCurrency, formatNumber, formatPercent, formatROAS, cn } from "@/lib/utils";
import {
  DollarSign, Eye, MousePointer, TrendingUp, ShoppingCart,
  ChevronDown, Play, Flame, TrendingDown,
} from "lucide-react";
import {
  AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, Cell,
} from "recharts";

type Period = "7d" | "14d" | "30d";
type Objective = "all" | "awareness" | "traffic" | "conversion";
const PERIOD_DAYS: Record<Period, number> = { "7d": 7, "14d": 14, "30d": 30 };

function PeriodSelector({ value, onChange }: { value: Period; onChange: (v: Period) => void }) {
  return (
    <div className="flex bg-[#111118] border border-[#1e1e2e] rounded-xl p-1 gap-0.5">
      {(["7d", "14d", "30d"] as Period[]).map((p) => (
        <button key={p} onClick={() => onChange(p)}
          className={cn("px-3 py-1.5 rounded-lg text-xs font-medium transition-all",
            value === p ? "bg-[#FF0050] text-white" : "text-[#555568] hover:text-[#8888a0]")}>
          {p}
        </button>
      ))}
    </div>
  );
}

function CompletionBar({ label, value, max, color }: { label: string; value: number; max: number; color: string }) {
  const pct = max > 0 ? (value / max) * 100 : 0;
  return (
    <div>
      <div className="flex items-center justify-between mb-1">
        <span className="text-xs text-[#8888a0]">{label}</span>
        <span className="metric-value text-xs font-semibold text-[#e8e8f0]">{formatNumber(value)}</span>
      </div>
      <div className="h-1.5 bg-[#1e1e2e] rounded-full overflow-hidden">
        <div className="h-full rounded-full transition-all duration-500" style={{ width: `${pct}%`, background: color }} />
      </div>
    </div>
  );
}

function TikTokCreativeCard({ c }: { c: TikTokCreative }) {
  const completionPct = c.completionRate;
  return (
    <div className={cn(
      "bg-[#111118] border rounded-xl p-4 card-hover transition-all",
      c.isTrending ? "border-[#FF0050]/40" : "border-[#1e1e2e]"
    )}>
      {/* Thumbnail + trend badge */}
      <div className="relative mb-3">
        <div className="w-full h-20 rounded-lg flex items-center justify-center"
          style={{ background: `${c.thumbnailColor}18`, border: `1px solid ${c.thumbnailColor}30` }}>
          <Play size={24} style={{ color: c.thumbnailColor }} fill={c.thumbnailColor} fillOpacity={0.6} />
          <span className="absolute bottom-2 right-2 text-[10px] metric-value text-[#8888a0] bg-[#0A0B0F]/80 px-1.5 py-0.5 rounded">
            {c.duration}s
          </span>
        </div>
        {c.isTrending && (
          <div className="absolute -top-2 -right-2 flex items-center gap-1 bg-[#FF0050] text-white text-[10px] font-bold px-2 py-0.5 rounded-full">
            <Flame size={9} /> Trending
          </div>
        )}
      </div>

      {/* Info */}
      <p className="text-[#e8e8f0] text-xs font-semibold truncate mb-0.5">{c.name}</p>
      <p className="text-[#555568] text-[10px] truncate mb-3">{c.campaignName}</p>

      {/* View funnel */}
      <div className="space-y-1.5 mb-3">
        <CompletionBar label="Visualizações" value={c.views} max={c.views} color="#FF0050" />
        <CompletionBar label="3s Views" value={c.views3s} max={c.views} color="#FF0050CC" />
        <CompletionBar label="6s Views" value={c.views6s} max={c.views} color="#FF005088" />
      </div>

      {/* Bottom metrics */}
      <div className="grid grid-cols-3 gap-2 pt-2 border-t border-[#1e1e2e]">
        <div>
          <p className="text-[#555568] text-[9px]">Conclusão</p>
          <p className="metric-value text-xs font-bold" style={{ color: completionPct > 40 ? "#22c55e" : completionPct > 25 ? "#f59e0b" : "#ef4444" }}>
            {completionPct.toFixed(1)}%
          </p>
        </div>
        <div>
          <p className="text-[#555568] text-[9px]">CTR</p>
          <p className="metric-value text-[#e8e8f0] text-xs font-bold">{formatPercent(c.ctr)}</p>
        </div>
        <div>
          <p className="text-[#555568] text-[9px]">CPC</p>
          <p className="metric-value text-[#e8e8f0] text-xs font-bold">{formatCurrency(c.cpc)}</p>
        </div>
      </div>
    </div>
  );
}

export default function TikTokDashboardPage() {
  const [period, setPeriod] = useState<Period>("30d");
  const [objective, setObjective] = useState<Objective>("all");
  const [loadingFilter, setLoadingFilter] = useState(false);

  const handlePeriodChange = useCallback((p: Period) => {
    setLoadingFilter(true);
    setPeriod(p);
    setTimeout(() => setLoadingFilter(false), 300);
  }, []);

  const tiktokCampaigns = useMemo(() => {
    const all = mockCampaigns.filter((c) => c.platform === "tiktok");
    if (objective === "awareness") return all.filter((c) => c.campaignName.toLowerCase().includes("awareness") || c.campaignName.toLowerCase().includes("ugc") || c.campaignName.toLowerCase().includes("topview"));
    if (objective === "traffic") return all.filter((c) => c.campaignName.toLowerCase().includes("tráfego") || c.campaignName.toLowerCase().includes("traffic"));
    if (objective === "conversion") return all.filter((c) => c.campaignName.toLowerCase().includes("conversão") || c.campaignName.toLowerCase().includes("spark"));
    return all;
  }, [objective]);

  const kpis = useMemo(() => {
    const totalSpend = tiktokCampaigns.reduce((s, c) => s + c.spend, 0);
    const totalImpressions = tiktokCampaigns.reduce((s, c) => s + c.impressions, 0);
    const totalClicks = tiktokCampaigns.reduce((s, c) => s + c.clicks, 0);
    const totalConversions = tiktokCampaigns.reduce((s, c) => s + c.conversions, 0);
    const totalViews = mockTikTokCreatives.reduce((s, c) => s + c.views, 0);
    const avgCompletion = mockTikTokCreatives.reduce((s, c) => s + c.completionRate, 0) / mockTikTokCreatives.length;
    const avgROAS = tiktokCampaigns.length > 0 ? tiktokCampaigns.reduce((s, c) => s + c.roas, 0) / tiktokCampaigns.length : 0;
    return {
      totalSpend, totalImpressions, totalClicks, totalConversions, avgROAS, totalViews, avgCompletion,
      avgCPA: totalConversions > 0 ? totalSpend / totalConversions : 0,
      ctr: totalImpressions > 0 ? (totalClicks / totalImpressions) * 100 : 0,
      cpv: totalViews > 0 ? totalSpend / totalViews : 0,
    };
  }, [tiktokCampaigns]);

  const days = PERIOD_DAYS[period];
  const chartData = useMemo(
    () => mockDailyMetrics.slice(-days).map((d) => ({
      date: d.date,
      views: Math.round(d.tiktok / 0.0045),
      engajamentos: Math.round(d.tiktok / 0.018),
    })),
    [days]
  );

  // Dados do comparativo 3s/6s/conclusão
  const viewFunnelData = useMemo(() => {
    const totals = mockTikTokCreatives.reduce(
      (acc, c) => ({
        views: acc.views + c.views,
        views3s: acc.views3s + c.views3s,
        views6s: acc.views6s + c.views6s,
        completions: acc.completions + Math.round(c.views * c.completionRate / 100),
      }),
      { views: 0, views3s: 0, views6s: 0, completions: 0 }
    );
    return [
      { name: "Views", value: totals.views, fill: "#FF0050" },
      { name: "3s Views", value: totals.views3s, fill: "#FF005099" },
      { name: "6s Views", value: totals.views6s, fill: "#FF005055" },
      { name: "Conclusão", value: totals.completions, fill: "#00F2EA" },
    ];
  }, []);

  const trendingCreatives = useMemo(
    () => [...mockTikTokCreatives].filter((c) => c.isTrending),
    []
  );
  const allCreatives = useMemo(
    () => [...mockTikTokCreatives].sort((a, b) => b.completionRate - a.completionRate),
    []
  );

  return (
    <AppShell title="TikTok Ads Dashboard">
      {/* Header */}
      <div className="flex flex-wrap items-center gap-3 mb-6 p-4 rounded-xl bg-[#FF0050]/10 border border-[#FF0050]/20">
        <div className="w-10 h-10 rounded-xl bg-[#FF0050] flex items-center justify-center text-white font-bold text-sm select-none">T</div>
        <div>
          <h2 className="text-[#e8e8f0] font-semibold">TikTok Ads — In-Feed, TopView & Spark</h2>
          <p className="text-[#8888a0] text-xs">
            <span className="pulse-dot inline-block w-1.5 h-1.5 rounded-full bg-green-400 mr-1.5" />
            {tiktokCampaigns.filter((c) => c.status === "active").length} ativas • 7123456789012345678
          </p>
        </div>
        <div className="ml-auto flex flex-wrap items-center gap-2">
          <div className="relative">
            <select value={objective} onChange={(e) => setObjective(e.target.value as Objective)}
              className="appearance-none bg-[#111118] border border-[#1e1e2e] text-[#e8e8f0] text-xs rounded-xl pl-3 pr-7 py-2 focus:outline-none focus:border-[#FF0050]">
              <option value="all">Todos os objetivos</option>
              <option value="awareness">Awareness</option>
              <option value="traffic">Tráfego</option>
              <option value="conversion">Conversão</option>
            </select>
            <ChevronDown size={11} className="absolute right-2 top-1/2 -translate-y-1/2 text-[#555568] pointer-events-none" />
          </div>
          <PeriodSelector value={period} onChange={handlePeriodChange} />
          <div className="text-right">
            <p className="text-[#555568] text-[10px]">Invest. {period}</p>
            <p className="metric-value text-[#FF0050] font-bold text-sm">{formatCurrency(kpis.totalSpend)}</p>
          </div>
        </div>
      </div>

      {/* KPIs */}
      {loadingFilter ? (
        <div className="grid grid-cols-3 lg:grid-cols-6 gap-3 mb-6">
          {Array.from({ length: 6 }).map((_, i) => <div key={i} className="bg-[#16161e] border border-[#1e1e2e] rounded-xl h-24 animate-pulse" />)}
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 mb-6">
          {[
            { title: "Reproduções", value: formatNumber(kpis.totalViews), delta: 28.4, icon: <Play size={13}/>, color: "#FF0050" },
            { title: "CPV", value: `R$ ${kpis.cpv.toFixed(4)}`, delta: -6.1, icon: <DollarSign size={13}/>, color: "#00F2EA" },
            { title: "Taxa Conclusão", value: formatPercent(kpis.avgCompletion), delta: 4.2, icon: <TrendingUp size={13}/>, color: "#FF0050" },
            { title: "Engajamento", value: formatNumber(kpis.totalClicks), delta: 17.4, icon: <Eye size={13}/>, color: "#00F2EA" },
            { title: "CPC", value: formatCurrency(kpis.ctr > 0 ? kpis.totalSpend / kpis.totalClicks : 0), delta: -3.8, icon: <MousePointer size={13}/>, color: "#FF0050" },
            { title: "CPA", value: formatCurrency(kpis.avgCPA), delta: -6.1, icon: <ShoppingCart size={13}/>, color: "#00F2EA" },
          ].map((k) => <MetricCard key={k.title} title={k.title} value={k.value} delta={k.delta} icon={k.icon} accentColor={k.color} />)}
        </div>
      )}

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-6">
        {/* Views x Engajamentos */}
        <div className="lg:col-span-2 bg-[#16161e] border border-[#1e1e2e] rounded-xl p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-[#e8e8f0] font-semibold">Views × Engajamentos — {period}</h3>
              <p className="text-[#555568] text-xs mt-0.5">Evolução diária</p>
            </div>
            <div className="flex gap-3 text-xs text-[#8888a0]">
              <span className="flex items-center gap-1.5"><span className="w-3 h-0.5 inline-block rounded bg-[#FF0050]" />Views</span>
              <span className="flex items-center gap-1.5"><span className="w-3 h-0.5 inline-block rounded bg-[#00F2EA]" />Engaj.</span>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <AreaChart data={chartData}>
              <defs>
                <linearGradient id="gTTV" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#FF0050" stopOpacity={0.2} /><stop offset="95%" stopColor="#FF0050" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="gTTE" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#00F2EA" stopOpacity={0.2} /><stop offset="95%" stopColor="#00F2EA" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e1e2e" vertical={false} />
              <XAxis dataKey="date" tick={{ fill: "#555568", fontSize: 11 }} axisLine={false} tickLine={false} interval={Math.floor(days / 6)} />
              <YAxis tick={{ fill: "#555568", fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={(v) => formatNumber(v)} />
              <Tooltip contentStyle={{ background: "#16161e", border: "1px solid #1e1e2e", borderRadius: 12 }} labelStyle={{ color: "#8888a0" }} itemStyle={{ color: "#e8e8f0" }} />
              <Area type="monotone" dataKey="views" name="Views" stroke="#FF0050" strokeWidth={2} fill="url(#gTTV)" dot={false} />
              <Area type="monotone" dataKey="engajamentos" name="Engajamentos" stroke="#00F2EA" strokeWidth={2} fill="url(#gTTE)" dot={false} />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Funil 3s/6s/Conclusão */}
        <div className="bg-[#16161e] border border-[#1e1e2e] rounded-xl p-5">
          <h3 className="text-[#e8e8f0] font-semibold mb-1">Funil de Visualização</h3>
          <p className="text-[#555568] text-xs mb-4">3s · 6s · Conclusão total</p>
          <ResponsiveContainer width="100%" height={170}>
            <BarChart data={viewFunnelData} layout="vertical" margin={{ top: 0, right: 8, bottom: 0, left: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e1e2e" horizontal={false} />
              <XAxis type="number" tick={{ fill: "#555568", fontSize: 10 }} axisLine={false} tickLine={false} tickFormatter={(v) => formatNumber(v)} />
              <YAxis type="category" dataKey="name" tick={{ fill: "#8888a0", fontSize: 11 }} axisLine={false} tickLine={false} width={64} />
              <Tooltip contentStyle={{ background: "#16161e", border: "1px solid #1e1e2e", borderRadius: 12 }} labelStyle={{ color: "#8888a0" }} // eslint-disable-next-line @typescript-eslint/no-explicit-any
              formatter={(v: any) => formatNumber(Number(v))} />
              <Bar dataKey="value" name="Visualizações" radius={[0, 4, 4, 0]}>
                {viewFunnelData.map((d) => <Cell key={d.name} fill={d.fill} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
          <div className="mt-3 pt-3 border-t border-[#1e1e2e] space-y-1">
            {viewFunnelData.map((d, i) => {
              const pct = viewFunnelData[0].value > 0 ? (d.value / viewFunnelData[0].value) * 100 : 0;
              return (
                <div key={d.name} className="flex items-center justify-between text-xs">
                  <span className="text-[#8888a0]">{d.name}</span>
                  <div className="flex items-center gap-2">
                    <span className="metric-value text-[#e8e8f0]">{formatNumber(d.value)}</span>
                    {i > 0 && (
                      <span className="text-[#555568]">({pct.toFixed(0)}%)</span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Campaigns Table */}
      <div className="mb-6">
        <CampaignTable platform="tiktok" />
      </div>

      {/* Criativos */}
      <div className="bg-[#16161e] border border-[#1e1e2e] rounded-xl overflow-hidden">
        <div className="flex items-center justify-between p-4 border-b border-[#1e1e2e]">
          <div>
            <h3 className="text-[#e8e8f0] font-semibold">Criativos de Vídeo</h3>
            <p className="text-[#555568] text-xs mt-0.5">
              <span className="text-[#FF0050] font-semibold">{trendingCreatives.length} trending</span>
              {" "}· ordenados por taxa de conclusão
            </p>
          </div>
          <div className="flex items-center gap-2">
            {trendingCreatives.length > 0 && (
              <div className="flex items-center gap-1 bg-[#FF0050]/15 text-[#FF0050] text-xs font-semibold px-2 py-1 rounded-full border border-[#FF0050]/30">
                <Flame size={11} /> {trendingCreatives.length} em alta
              </div>
            )}
          </div>
        </div>
        <div className="p-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {allCreatives.map((c) => <TikTokCreativeCard key={c.id} c={c} />)}
        </div>
      </div>
    </AppShell>
  );
}
