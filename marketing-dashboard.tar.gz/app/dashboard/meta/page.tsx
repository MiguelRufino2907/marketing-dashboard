"use client";

import { useState, useMemo, useCallback } from "react";
import AppShell from "@/components/layout/AppShell";
import MetricCard from "@/components/dashboard/MetricCard";
import CampaignTable from "@/components/dashboard/CampaignTable";
import StatusBadge from "@/components/shared/StatusBadge";
import {
  mockCampaigns, mockDailyMetrics, mockMetaCreatives, mockMetaAdSets,
  type MetaCreative, type MetaAdSet,
} from "@/lib/mock-data";
import { formatCurrency, formatNumber, formatPercent, formatROAS, cn } from "@/lib/utils";
import {
  DollarSign, Eye, MousePointer, TrendingUp, Users, ShoppingCart,
  ChevronDown, Image, Film, LayoutGrid, Layers, Megaphone,
} from "lucide-react";
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
} from "recharts";

type Period = "7d" | "14d" | "30d";
type Level = "campaign" | "adset" | "ad";
const PERIOD_DAYS: Record<Period, number> = { "7d": 7, "14d": 14, "30d": 30 };

const CREATIVE_TYPE_ICON: Record<MetaCreative["type"], React.ReactNode> = {
  image: <Image size={12} />,
  video: <Film size={12} />,
  carousel: <LayoutGrid size={12} />,
};
const CREATIVE_STATUS_COLOR: Record<MetaCreative["status"], string> = {
  active: "#22c55e", paused: "#f59e0b", review: "#6366f1",
};

function PeriodSelector({ value, onChange }: { value: Period; onChange: (v: Period) => void }) {
  return (
    <div className="flex bg-[#111118] border border-[#1e1e2e] rounded-xl p-1 gap-0.5">
      {(["7d", "14d", "30d"] as Period[]).map((p) => (
        <button key={p} onClick={() => onChange(p)}
          className={cn("px-3 py-1.5 rounded-lg text-xs font-medium transition-all",
            value === p ? "bg-[#1877F2] text-white" : "text-[#555568] hover:text-[#8888a0]")}>
          {p}
        </button>
      ))}
    </div>
  );
}

function LevelToggle({ value, onChange }: { value: Level; onChange: (v: Level) => void }) {
  const levels = [
    { value: "campaign" as Level, label: "Campanha", icon: <Megaphone size={12} /> },
    { value: "adset" as Level, label: "Conjunto", icon: <Layers size={12} /> },
    { value: "ad" as Level, label: "Anúncio", icon: <Film size={12} /> },
  ];
  return (
    <div className="flex bg-[#111118] border border-[#1e1e2e] rounded-xl p-1 gap-0.5">
      {levels.map((l) => (
        <button key={l.value} onClick={() => onChange(l.value)}
          className={cn("flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all",
            value === l.value ? "bg-[#1877F2]/15 text-[#1877F2] border border-[#1877F2]/30" : "text-[#555568] hover:text-[#8888a0]")}>
          {l.icon}{l.label}
        </button>
      ))}
    </div>
  );
}

function CreativeCard({ c }: { c: MetaCreative }) {
  return (
    <div className="bg-[#111118] border border-[#1e1e2e] rounded-xl p-4 card-hover flex gap-3">
      <div className="w-14 h-14 rounded-xl flex-shrink-0 flex items-center justify-center"
        style={{ background: `${c.thumbnailColor}20`, border: `1px solid ${c.thumbnailColor}30` }}>
        <span style={{ color: c.thumbnailColor }}>{CREATIVE_TYPE_ICON[c.type]}</span>
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-start justify-between gap-1 mb-0.5">
          <p className="text-[#e8e8f0] text-xs font-semibold truncate">{c.name}</p>
          <div className="flex items-center gap-1 flex-shrink-0">
            <span className="w-1.5 h-1.5 rounded-full" style={{ background: CREATIVE_STATUS_COLOR[c.status] }} />
            <span className="text-[10px] capitalize" style={{ color: CREATIVE_STATUS_COLOR[c.status] }}>{c.status}</span>
          </div>
        </div>
        <p className="text-[#555568] text-[10px] truncate mb-2">{c.campaignName}</p>
        <div className="grid grid-cols-3 gap-1">
          <div><p className="text-[#555568] text-[9px]">CTR</p><p className="metric-value text-[#e8e8f0] text-xs font-bold">{formatPercent(c.ctr)}</p></div>
          <div><p className="text-[#555568] text-[9px]">Conv.</p><p className="metric-value text-[#e8e8f0] text-xs font-bold">{c.conversions}</p></div>
          <div><p className="text-[#555568] text-[9px]">Gasto</p><p className="metric-value text-[#e8e8f0] text-xs font-bold">{formatCurrency(c.spend)}</p></div>
        </div>
      </div>
    </div>
  );
}

export default function MetaDashboardPage() {
  const [period, setPeriod] = useState<Period>("30d");
  const [level, setLevel] = useState<Level>("campaign");
  const [campaign, setCampaign] = useState("all");
  const [loadingFilter, setLoadingFilter] = useState(false);

  const handlePeriodChange = useCallback((p: Period) => {
    setLoadingFilter(true);
    setPeriod(p);
    setTimeout(() => setLoadingFilter(false), 300);
  }, []);

  const metaCampaigns = useMemo(() => mockCampaigns.filter((c) => c.platform === "meta"), []);

  const filteredCampaigns = useMemo(
    () => campaign === "all" ? metaCampaigns : metaCampaigns.filter((c) => c.campaignId === campaign),
    [metaCampaigns, campaign]
  );

  const kpis = useMemo(() => {
    const totalSpend = filteredCampaigns.reduce((s, c) => s + c.spend, 0);
    const totalImpressions = filteredCampaigns.reduce((s, c) => s + c.impressions, 0);
    const totalReach = filteredCampaigns.reduce((s, c) => s + c.reach, 0);
    const totalClicks = filteredCampaigns.reduce((s, c) => s + c.clicks, 0);
    const totalConversions = filteredCampaigns.reduce((s, c) => s + c.conversions, 0);
    const avgROAS = filteredCampaigns.length > 0 ? filteredCampaigns.reduce((s, c) => s + c.roas, 0) / filteredCampaigns.length : 0;
    return {
      totalSpend, totalImpressions, totalReach, totalClicks, totalConversions, avgROAS,
      avgCPA: totalConversions > 0 ? totalSpend / totalConversions : 0,
      ctr: totalImpressions > 0 ? (totalClicks / totalImpressions) * 100 : 0,
      cpm: totalImpressions > 0 ? (totalSpend / totalImpressions) * 1000 : 0,
      cpc: totalClicks > 0 ? totalSpend / totalClicks : 0,
    };
  }, [filteredCampaigns]);

  const days = PERIOD_DAYS[period];
  const chartData = useMemo(
    () => mockDailyMetrics.slice(-days).map((d) => ({
      date: d.date,
      alcance: Math.round(d.meta * 0.82),
      cliques: Math.round(d.meta * 0.012),
    })),
    [days]
  );

  return (
    <AppShell title="Meta Ads Dashboard">
      {/* Header */}
      <div className="flex flex-wrap items-center gap-3 mb-6 p-4 rounded-xl bg-[#1877F2]/10 border border-[#1877F2]/20">
        <div className="w-10 h-10 rounded-xl bg-[#1877F2] flex items-center justify-center text-white font-bold text-sm select-none">f</div>
        <div>
          <h2 className="text-[#e8e8f0] font-semibold">Meta Ads — Facebook & Instagram</h2>
          <p className="text-[#8888a0] text-xs">
            <span className="pulse-dot inline-block w-1.5 h-1.5 rounded-full bg-green-400 mr-1.5" />
            {metaCampaigns.filter((c) => c.status === "active").length} ativas • act_1234567890
          </p>
        </div>
        <div className="ml-auto flex flex-wrap items-center gap-2">
          <div className="relative">
            <select value={campaign} onChange={(e) => setCampaign(e.target.value)}
              className="appearance-none bg-[#111118] border border-[#1e1e2e] text-[#e8e8f0] text-xs rounded-xl pl-3 pr-7 py-2 focus:outline-none focus:border-[#1877F2]">
              <option value="all">Todas as campanhas</option>
              {metaCampaigns.map((c) => <option key={c.campaignId} value={c.campaignId}>{c.campaignName}</option>)}
            </select>
            <ChevronDown size={11} className="absolute right-2 top-1/2 -translate-y-1/2 text-[#555568] pointer-events-none" />
          </div>
          <PeriodSelector value={period} onChange={handlePeriodChange} />
          <div className="text-right">
            <p className="text-[#555568] text-[10px]">Invest. {period}</p>
            <p className="metric-value text-[#1877F2] font-bold text-sm">{formatCurrency(kpis.totalSpend)}</p>
          </div>
        </div>
      </div>

      {/* KPIs */}
      {loadingFilter ? (
        <div className="grid grid-cols-4 lg:grid-cols-7 gap-3 mb-6">
          {Array.from({ length: 7 }).map((_, i) => <div key={i} className="bg-[#16161e] border border-[#1e1e2e] rounded-xl h-24 animate-pulse" />)}
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3 mb-6">
          {[
            { title: "Investimento", value: formatCurrency(kpis.totalSpend), delta: 14.2, icon: <DollarSign size={14}/>, color: "#1877F2" },
            { title: "Alcance", value: formatNumber(kpis.totalReach), delta: 11.3, icon: <Users size={14}/>, color: "#0d6efd" },
            { title: "Impressões", value: formatNumber(kpis.totalImpressions), delta: 9.1, icon: <Eye size={14}/>, color: "#6610f2" },
            { title: "Cliques", value: formatNumber(kpis.totalClicks), delta: 18.3, icon: <MousePointer size={14}/>, color: "#1877F2" },
            { title: "Conversões", value: String(kpis.totalConversions), delta: 24.7, icon: <ShoppingCart size={14}/>, color: "#22c55e" },
            { title: "ROAS", value: formatROAS(kpis.avgROAS), delta: 8.6, icon: <TrendingUp size={14}/>, color: "#f59e0b" },
            { title: "CPA Médio", value: formatCurrency(kpis.avgCPA), delta: -11.2, icon: <DollarSign size={14}/>, color: "#f97316" },
          ].map((k) => <MetricCard key={k.title} title={k.title} value={k.value} delta={k.delta} icon={k.icon} accentColor={k.color} />)}
        </div>
      )}

      {/* Chart: Alcance vs Cliques */}
      <div className="bg-[#16161e] border border-[#1e1e2e] rounded-xl p-5 mb-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-[#e8e8f0] font-semibold">Alcance × Cliques — {period}</h3>
            <p className="text-[#555568] text-xs mt-0.5">Evolução diária</p>
          </div>
          <div className="flex gap-3 text-xs text-[#8888a0]">
            <span className="flex items-center gap-1.5"><span className="w-3 h-0.5 inline-block rounded bg-[#1877F2]" />Alcance</span>
            <span className="flex items-center gap-1.5"><span className="w-3 h-0.5 inline-block rounded bg-[#00F2EA]" />Cliques</span>
          </div>
        </div>
        <ResponsiveContainer width="100%" height={220}>
          <AreaChart data={chartData}>
            <defs>
              <linearGradient id="gMR" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#1877F2" stopOpacity={0.2} /><stop offset="95%" stopColor="#1877F2" stopOpacity={0} />
              </linearGradient>
              <linearGradient id="gMC" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#00F2EA" stopOpacity={0.2} /><stop offset="95%" stopColor="#00F2EA" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#1e1e2e" vertical={false} />
            <XAxis dataKey="date" tick={{ fill: "#555568", fontSize: 11 }} axisLine={false} tickLine={false} interval={Math.floor(days / 6)} />
            <YAxis tick={{ fill: "#555568", fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={(v) => formatNumber(v)} />
            <Tooltip contentStyle={{ background: "#16161e", border: "1px solid #1e1e2e", borderRadius: 12 }} labelStyle={{ color: "#8888a0" }} itemStyle={{ color: "#e8e8f0" }} />
            <Area type="monotone" dataKey="alcance" name="Alcance" stroke="#1877F2" strokeWidth={2} fill="url(#gMR)" dot={false} />
            <Area type="monotone" dataKey="cliques" name="Cliques" stroke="#00F2EA" strokeWidth={2} fill="url(#gMC)" dot={false} />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      {/* Level toggle + table */}
      <div className="bg-[#16161e] border border-[#1e1e2e] rounded-xl overflow-hidden mb-6">
        <div className="flex items-center justify-between p-4 border-b border-[#1e1e2e]">
          <h3 className="text-[#e8e8f0] font-semibold">Desempenho Detalhado</h3>
          <LevelToggle value={level} onChange={setLevel} />
        </div>

        {level === "campaign" && <CampaignTable platform="meta" />}

        {level === "adset" && (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-[#111118]">
                <tr>
                  {["Conjunto de Anúncios", "Público", "Status", "Orçamento/dia", "Investido", "Impressões", "CTR", "Conversões", "ROAS"].map((h) => (
                    <th key={h} className="py-3 px-4 text-xs font-medium text-[#555568] text-left whitespace-nowrap">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1e1e2e]">
                {mockMetaAdSets.map((as: MetaAdSet) => (
                  <tr key={as.id} className="hover:bg-[#1e1e2e]/50 transition-colors">
                    <td className="py-3 px-4 text-sm text-[#e8e8f0] font-medium">{as.name}</td>
                    <td className="py-3 px-4 text-xs text-[#8888a0] max-w-[180px] truncate">{as.audience}</td>
                    <td className="py-3 px-4"><StatusBadge status={as.status} /></td>
                    <td className="py-3 px-4 text-right metric-value text-sm text-[#8888a0]">{formatCurrency(as.budget)}</td>
                    <td className="py-3 px-4 text-right metric-value text-sm text-[#e8e8f0]">{formatCurrency(as.spend)}</td>
                    <td className="py-3 px-4 text-right metric-value text-sm text-[#8888a0]">{formatNumber(as.impressions)}</td>
                    <td className="py-3 px-4 text-right metric-value text-sm text-[#8888a0]">{formatPercent(as.ctr)}</td>
                    <td className="py-3 px-4 text-right metric-value text-sm text-[#e8e8f0] font-medium">{as.conversions}</td>
                    <td className="py-3 px-4 text-right">
                      <span className={cn("metric-value text-sm font-semibold",
                        as.roas >= 4 ? "text-green-400" : as.roas >= 2 ? "text-yellow-400" : "text-red-400")}>
                        {formatROAS(as.roas)}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {level === "ad" && (
          <div className="p-4 grid grid-cols-1 lg:grid-cols-2 gap-3">
            {mockMetaCreatives.map((c: MetaCreative) => <CreativeCard key={c.id} c={c} />)}
          </div>
        )}
      </div>

      {/* Top Criativos */}
      <div className="bg-[#16161e] border border-[#1e1e2e] rounded-xl overflow-hidden">
        <div className="flex items-center justify-between p-4 border-b border-[#1e1e2e]">
          <div>
            <h3 className="text-[#e8e8f0] font-semibold">Top Criativos</h3>
            <p className="text-[#555568] text-xs mt-0.5">Ordenados por CTR</p>
          </div>
          <span className="text-xs text-[#555568] bg-[#1e1e2e] px-2 py-1 rounded-full">{mockMetaCreatives.length} criativos</span>
        </div>
        <div className="p-4 grid grid-cols-1 lg:grid-cols-3 gap-3">
          {[...mockMetaCreatives].sort((a, b) => b.ctr - a.ctr).slice(0, 3).map((c) => (
            <CreativeCard key={c.id} c={c} />
          ))}
        </div>
      </div>
    </AppShell>
  );
}
