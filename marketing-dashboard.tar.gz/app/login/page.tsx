"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/lib/auth-context";
import { Eye, EyeOff, Zap, AlertCircle } from "lucide-react";

export default function LoginPage() {
  const { login } = useAuth();
  const router = useRouter();
  const [email, setEmail] = useState("admin@agencia.com");
  const [password, setPassword] = useState("admin123");
  const [showPw, setShowPw] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    const ok = await login(email, password);
    setLoading(false);
    if (ok) router.push("/dashboard");
    else setError("E-mail ou senha incorretos.");
  };

  return (
    <div className="min-h-screen bg-[#0a0a0f] flex items-center justify-center p-4">
      {/* Background glow */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-[#6366f1] opacity-[0.06] rounded-full blur-3xl" />
      </div>

      <div className="w-full max-w-sm relative">
        {/* Logo */}
        <div className="flex items-center justify-center gap-3 mb-10">
          <div className="w-10 h-10 rounded-xl bg-[#6366f1] flex items-center justify-center shadow-lg shadow-[#6366f1]/30">
            <Zap size={20} fill="white" className="text-white" />
          </div>
          <div>
            <h1 className="font-display font-bold text-xl text-[#e8e8f0]">AdsPulse</h1>
            <p className="text-[#555568] text-xs">Marketing Analytics</p>
          </div>
        </div>

        {/* Card */}
        <div className="bg-[#16161e] border border-[#1e1e2e] rounded-2xl p-8">
          <h2 className="font-display font-bold text-[#e8e8f0] text-xl mb-1">
            Bem-vindo de volta
          </h2>
          <p className="text-[#555568] text-sm mb-7">
            Entre com suas credenciais para acessar o painel
          </p>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="text-xs font-medium text-[#8888a0] mb-1.5 block">
                E-mail
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="w-full bg-[#111118] border border-[#1e1e2e] text-[#e8e8f0] rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-[#6366f1] placeholder:text-[#555568] transition-colors"
                placeholder="seu@email.com"
              />
            </div>
            <div>
              <label className="text-xs font-medium text-[#8888a0] mb-1.5 block">
                Senha
              </label>
              <div className="relative">
                <input
                  type={showPw ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="w-full bg-[#111118] border border-[#1e1e2e] text-[#e8e8f0] rounded-xl px-4 py-3 pr-11 text-sm focus:outline-none focus:border-[#6366f1] placeholder:text-[#555568] transition-colors"
                  placeholder="••••••••"
                />
                <button
                  type="button"
                  onClick={() => setShowPw(!showPw)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-[#555568] hover:text-[#8888a0] transition-colors"
                >
                  {showPw ? <EyeOff size={15} /> : <Eye size={15} />}
                </button>
              </div>
            </div>

            {error && (
              <div className="flex items-center gap-2 bg-red-500/10 border border-red-500/20 text-red-400 text-sm rounded-xl px-4 py-3">
                <AlertCircle size={14} />
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-[#6366f1] hover:bg-[#5558e8] text-white font-semibold rounded-xl py-3 text-sm transition-colors disabled:opacity-60 flex items-center justify-center gap-2 mt-2"
            >
              {loading && (
                <div className="w-4 h-4 rounded-full border-2 border-white/30 border-t-white animate-spin" />
              )}
              {loading ? "Entrando..." : "Entrar"}
            </button>
          </form>
        </div>

        {/* Demo accounts */}
        <div className="mt-5 bg-[#111118] border border-[#1e1e2e] rounded-xl p-4">
          <p className="text-[#555568] text-xs font-medium mb-3">Contas de demonstração:</p>
          <div className="space-y-2">
            {[
              { email: "admin@agencia.com", password: "admin123", role: "Admin" },
              { email: "analyst@agencia.com", password: "analyst123", role: "Analista" },
              { email: "cliente@fashionbr.com", password: "cliente123", role: "Cliente" },
            ].map((acc) => (
              <button
                key={acc.email}
                onClick={() => { setEmail(acc.email); setPassword(acc.password); }}
                className="w-full flex items-center justify-between px-3 py-2 bg-[#16161e] hover:bg-[#1e1e2e] rounded-lg transition-colors text-left"
              >
                <span className="text-[#8888a0] text-xs">{acc.email}</span>
                <span className="text-[#555568] text-[10px] bg-[#1e1e2e] px-2 py-0.5 rounded-full">
                  {acc.role}
                </span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
