"use client";

import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
} from "recharts";
import { platformBreakdown as mockPlatformBreakdown } from "@/lib/mock-data";
import { formatCurrency } from "@/lib/utils";

interface PlatformData {
  platform: string;
  spend: number;
  pct: number;
  color: string;
}

interface Props {
  data?: PlatformData[];
  loading?: boolean;
}

const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-[#16161e] border border-[#1e1e2e] rounded-xl p-3 shadow-xl text-sm">
      <p className="text-[#8888a0] mb-2 font-medium">{label}</p>
      {payload.map((p: any) => (
        <div key={p.name} className="flex items-center gap-2 mb-1">
          <span className="w-2 h-2 rounded-full" style={{ background: p.fill }} />
          <span className="text-[#e8e8f0] font-mono">{formatCurrency(p.value)}</span>
        </div>
      ))}
    </div>
  );
};

const RADIAN = Math.PI / 180;
const renderCustomLabel = ({ cx, cy, midAngle, innerRadius, outerRadius, percent }: any) => {
  const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
  const x = cx + radius * Math.cos(-midAngle * RADIAN);
  const y = cy + radius * Math.sin(-midAngle * RADIAN);
  if (percent < 0.05) return null; // Não renderiza fatias muito pequenas
  return (
    <text x={x} y={y} fill="white" textAnchor="middle" dominantBaseline="central" fontSize={12} fontWeight={600}>
      {`${(percent * 100).toFixed(0)}%`}
    </text>
  );
};

// Normaliza dados reais ou usa mock como fallback
function normalizeData(data?: PlatformData[]) {
  if (data && data.length > 0 && data.some((d) => d.spend > 0)) {
    return data.map((p) => ({
      name: p.platform,
      spend: p.spend,
      fill: p.color,
    }));
  }
  // Fallback para mock
  return mockPlatformBreakdown.map((p) => ({
    name: (p as any).name?.replace(" Ads", "") ?? p.platform,
    spend: p.spend,
    fill: p.color,
  }));
}

export function PlatformBarChart({ data, loading }: Props) {
  const chartData = normalizeData(data);

  return (
    <div className="bg-[#16161e] border border-[#1e1e2e] rounded-xl p-5">
      <h3 className="text-[#e8e8f0] font-semibold text-base mb-1">
        Investimento por Plataforma
      </h3>
      <p className="text-[#8888a0] text-xs mb-5">Comparativo de budget</p>

      {loading ? (
        <div className="h-[200px] flex items-center justify-center">
          <div className="w-6 h-6 rounded-full border-2 border-[#1e1e2e] border-t-[#6366f1] animate-spin" />
        </div>
      ) : (
        <ResponsiveContainer width="100%" height={200}>
          <BarChart data={chartData} margin={{ top: 4, right: 4, bottom: 0, left: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#1e1e2e" vertical={false} />
            <XAxis dataKey="name" tick={{ fill: "#555568", fontSize: 12 }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fill: "#555568", fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={(v) => `R$${(v / 1000).toFixed(0)}k`} />
            <Tooltip content={<CustomTooltip />} />
            <Bar dataKey="spend" radius={[6, 6, 0, 0]}>
              {chartData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.fill} fillOpacity={0.85} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      )}
    </div>
  );
}

export function BudgetPieChart({ data, loading }: Props) {
  const chartData = normalizeData(data).map((p) => ({
    name: p.name,
    value: p.spend,
    color: p.fill,
  }));

  return (
    <div className="bg-[#16161e] border border-[#1e1e2e] rounded-xl p-5">
      <h3 className="text-[#e8e8f0] font-semibold text-base mb-1">
        Distribuição de Budget
      </h3>
      <p className="text-[#8888a0] text-xs mb-2">Percentual por plataforma</p>

      {loading ? (
        <div className="h-[200px] flex items-center justify-center">
          <div className="w-6 h-6 rounded-full border-2 border-[#1e1e2e] border-t-[#6366f1] animate-spin" />
        </div>
      ) : (
        <ResponsiveContainer width="100%" height={200}>
          <PieChart>
            <Pie
              data={chartData}
              cx="50%"
              cy="50%"
              outerRadius={70}
              dataKey="value"
              labelLine={false}
              label={renderCustomLabel}
            >
              {chartData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.color} />
              ))}
            </Pie>
            <Tooltip
              formatter={(value) => formatCurrency(Number(value))}
              contentStyle={{ background: "#16161e", border: "1px solid #1e1e2e", borderRadius: 12 }}
              labelStyle={{ color: "#8888a0" }}
              itemStyle={{ color: "#e8e8f0" }}
            />
            <Legend
              iconType="circle"
              iconSize={8}
              formatter={(value) => (
                <span style={{ color: "#8888a0", fontSize: 12 }}>{value}</span>
              )}
            />
          </PieChart>
        </ResponsiveContainer>
      )}
    </div>
  );
}
