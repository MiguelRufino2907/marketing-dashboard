"use client";

import { useState, useMemo } from "react";
import { mockCampaigns, type Platform, type CampaignStatus } from "@/lib/mock-data";
import { formatCurrency, formatNumber, formatPercent, formatROAS, cn } from "@/lib/utils";
import PlatformBadge from "./PlatformBadge";
import StatusBadge from "@/components/shared/StatusBadge";
import { Search, ChevronUp, ChevronDown, Download } from "lucide-react";

type SortField = keyof typeof mockCampaigns[0];
type SortDir = "asc" | "desc";

const PAGE_SIZE = 8;

export default function CampaignTable({
  platform,
}: {
  platform?: Platform;
}) {
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<CampaignStatus | "all">("all");
  const [sortField, setSortField] = useState<SortField>("spend");
  const [sortDir, setSortDir] = useState<SortDir>("desc");
  const [page, setPage] = useState(1);

  const filtered = useMemo(() => {
    let data = platform
      ? mockCampaigns.filter((c) => c.platform === platform)
      : mockCampaigns;

    if (statusFilter !== "all") data = data.filter((c) => c.status === statusFilter);
    if (search)
      data = data.filter((c) =>
        c.campaignName.toLowerCase().includes(search.toLowerCase())
      );

    data = [...data].sort((a, b) => {
      const va = a[sortField] as number | string;
      const vb = b[sortField] as number | string;
      if (typeof va === "number" && typeof vb === "number")
        return sortDir === "asc" ? va - vb : vb - va;
      return sortDir === "asc"
        ? String(va).localeCompare(String(vb))
        : String(vb).localeCompare(String(va));
    });

    return data;
  }, [platform, search, statusFilter, sortField, sortDir]);

  const totalPages = Math.ceil(filtered.length / PAGE_SIZE);
  const paginated = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  const handleSort = (field: SortField) => {
    if (sortField === field) setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    else { setSortField(field); setSortDir("desc"); }
  };

  const SortIcon = ({ field }: { field: SortField }) => {
    if (sortField !== field) return <ChevronUp size={12} className="text-[#555568]" />;
    return sortDir === "asc" ? (
      <ChevronUp size={12} className="text-[#6366f1]" />
    ) : (
      <ChevronDown size={12} className="text-[#6366f1]" />
    );
  };

  const TH = ({
    label,
    field,
    right,
  }: {
    label: string;
    field?: SortField;
    right?: boolean;
  }) => (
    <th
      className={cn(
        "py-3 px-4 text-xs font-medium text-[#555568] whitespace-nowrap select-none",
        right ? "text-right" : "text-left",
        field && "cursor-pointer hover:text-[#8888a0] transition-colors"
      )}
      onClick={() => field && handleSort(field)}
    >
      <span className="inline-flex items-center gap-1">
        {label}
        {field && <SortIcon field={field} />}
      </span>
    </th>
  );

  const exportCSV = () => {
    const headers = ["Nome","Plataforma","Status","Investido","Impressões","Cliques","CTR","CPC","Conversões","CPA","ROAS"];
    const rows = filtered.map(c => [
      c.campaignName, c.platform, c.status,
      c.spend, c.impressions, c.clicks, c.ctr, c.cpc, c.conversions, c.cpa, c.roas,
    ]);
    const csv = [headers, ...rows].map(r => r.join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = "campanhas.csv"; a.click();
  };

  return (
    <div className="bg-[#16161e] border border-[#1e1e2e] rounded-xl overflow-hidden">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-4 border-b border-[#1e1e2e]">
        <div className="flex items-center gap-2">
          <h3 className="text-[#e8e8f0] font-semibold">Campanhas</h3>
          <span className="text-xs text-[#555568] bg-[#1e1e2e] px-2 py-0.5 rounded-full">
            {filtered.length}
          </span>
        </div>

        <div className="flex items-center gap-2">
          {/* Search */}
          <div className="relative">
            <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#555568]" />
            <input
              value={search}
              onChange={(e) => { setSearch(e.target.value); setPage(1); }}
              placeholder="Buscar campanha..."
              className="bg-[#111118] border border-[#1e1e2e] text-[#e8e8f0] text-sm rounded-lg pl-8 pr-3 py-2 w-48 focus:outline-none focus:border-[#6366f1] placeholder:text-[#555568]"
            />
          </div>

          {/* Status filter */}
          <select
            value={statusFilter}
            onChange={(e) => { setStatusFilter(e.target.value as any); setPage(1); }}
            className="bg-[#111118] border border-[#1e1e2e] text-[#e8e8f0] text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-[#6366f1]"
          >
            <option value="all">Todos os status</option>
            <option value="active">Ativo</option>
            <option value="paused">Pausado</option>
            <option value="ended">Encerrado</option>
          </select>

          <button
            onClick={exportCSV}
            className="flex items-center gap-1.5 px-3 py-2 bg-[#1e1e2e] hover:bg-[#2a2a3e] text-[#8888a0] hover:text-[#e8e8f0] text-sm rounded-lg transition-colors border border-[#1e1e2e]"
          >
            <Download size={13} />
            CSV
          </button>
        </div>
      </div>

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-[#111118]">
            <tr>
              <TH label="Campanha" field="campaignName" />
              {!platform && <TH label="Plataforma" field="platform" />}
              <TH label="Status" field="status" />
              <TH label="Investido" field="spend" right />
              <TH label="Impressões" field="impressions" right />
              <TH label="Cliques" field="clicks" right />
              <TH label="CTR" field="ctr" right />
              <TH label="CPC" field="cpc" right />
              <TH label="Conversões" field="conversions" right />
              <TH label="CPA" field="cpa" right />
              <TH label="ROAS" field="roas" right />
            </tr>
          </thead>
          <tbody className="divide-y divide-[#1e1e2e]">
            {paginated.map((c) => (
              <tr key={c.id} className="hover:bg-[#1e1e2e]/50 transition-colors">
                <td className="py-3 px-4 text-sm text-[#e8e8f0] font-medium max-w-[200px] truncate">
                  {c.campaignName}
                </td>
                {!platform && (
                  <td className="py-3 px-4">
                    <PlatformBadge platform={c.platform} />
                  </td>
                )}
                <td className="py-3 px-4">
                  <StatusBadge status={c.status} />
                </td>
                <td className="py-3 px-4 text-right metric-value text-sm text-[#e8e8f0]">
                  {formatCurrency(c.spend)}
                </td>
                <td className="py-3 px-4 text-right metric-value text-sm text-[#8888a0]">
                  {formatNumber(c.impressions)}
                </td>
                <td className="py-3 px-4 text-right metric-value text-sm text-[#8888a0]">
                  {formatNumber(c.clicks)}
                </td>
                <td className="py-3 px-4 text-right metric-value text-sm text-[#8888a0]">
                  {formatPercent(c.ctr)}
                </td>
                <td className="py-3 px-4 text-right metric-value text-sm text-[#8888a0]">
                  {formatCurrency(c.cpc)}
                </td>
                <td className="py-3 px-4 text-right metric-value text-sm text-[#e8e8f0] font-medium">
                  {c.conversions}
                </td>
                <td className="py-3 px-4 text-right metric-value text-sm text-[#8888a0]">
                  {formatCurrency(c.cpa)}
                </td>
                <td className="py-3 px-4 text-right">
                  <span
                    className={cn(
                      "metric-value text-sm font-semibold",
                      c.roas >= 4 ? "text-green-400" : c.roas >= 2 ? "text-yellow-400" : "text-red-400"
                    )}
                  >
                    {formatROAS(c.roas)}
                  </span>
                </td>
              </tr>
            ))}
            {paginated.length === 0 && (
              <tr>
                <td colSpan={12} className="py-12 text-center text-[#555568] text-sm">
                  Nenhuma campanha encontrada.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between px-4 py-3 border-t border-[#1e1e2e] text-sm text-[#8888a0]">
          <span>
            {(page - 1) * PAGE_SIZE + 1}–{Math.min(page * PAGE_SIZE, filtered.length)} de {filtered.length}
          </span>
          <div className="flex gap-1">
            {Array.from({ length: totalPages }).map((_, i) => (
              <button
                key={i}
                onClick={() => setPage(i + 1)}
                className={cn(
                  "w-8 h-8 rounded-lg text-xs font-medium transition-colors",
                  page === i + 1
                    ? "bg-[#6366f1] text-white"
                    : "hover:bg-[#1e1e2e] text-[#8888a0]"
                )}
              >
                {i + 1}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
