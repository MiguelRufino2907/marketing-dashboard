"use client";

import { cn } from "@/lib/utils";
import { TrendingUp, TrendingDown } from "lucide-react";
import { SparklineChart } from "./SparklineChart";

interface Props {
  title: string;
  value: string;
  delta?: number;
  icon: React.ReactNode;
  sparkData?: number[];
  className?: string;
  accentColor?: string;
}

export default function MetricCard({
  title,
  value,
  delta,
  icon,
  sparkData,
  className,
  accentColor = "#6366f1",
}: Props) {
  const isPositive = (delta ?? 0) >= 0;

  return (
    <div
      className={cn(
        "bg-[#16161e] border border-[#1e1e2e] rounded-xl p-5 card-hover cursor-default",
        className
      )}
    >
      <div className="flex items-start justify-between mb-3">
        <span className="text-[#8888a0] text-sm font-medium">{title}</span>
        <div
          className="w-9 h-9 rounded-lg flex items-center justify-center"
          style={{ background: `${accentColor}1a`, color: accentColor }}
        >
          {icon}
        </div>
      </div>

      <div className="flex items-end justify-between">
        <div>
          <p className="metric-value text-2xl font-bold text-[#e8e8f0] count-animate">
            {value}
          </p>
          {delta !== undefined && (
            <div
              className={cn(
                "flex items-center gap-1 text-xs mt-1.5 font-medium",
                isPositive ? "text-green-400" : "text-red-400"
              )}
            >
              {isPositive ? <TrendingUp size={12} /> : <TrendingDown size={12} />}
              {isPositive ? "+" : ""}
              {delta.toFixed(1)}% vs período anterior
            </div>
          )}
        </div>

        {sparkData && sparkData.length > 0 && (
          <div className="w-20 h-10">
            <SparklineChart data={sparkData} color={accentColor} positive={isPositive} />
          </div>
        )}
      </div>
    </div>
  );
}
