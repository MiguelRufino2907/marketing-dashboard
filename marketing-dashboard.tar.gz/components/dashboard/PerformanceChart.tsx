"use client";

import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import { mockDailyMetrics } from "@/lib/mock-data";
import { formatCurrency, formatNumber } from "@/lib/utils";
import type { DailyPoint } from "@/lib/data/metrics";

interface Props {
  data?: DailyPoint[];
  loading?: boolean;
}

const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-[#16161e] border border-[#1e1e2e] rounded-xl p-3 shadow-xl text-sm">
      <p className="text-[#8888a0] mb-2 font-medium">{label}</p>
      {payload.map((p: any) => (
        <div key={p.dataKey} className="flex items-center gap-2 mb-1">
          <span className="w-2 h-2 rounded-full" style={{ background: p.color }} />
          <span className="text-[#8888a0]">{p.name}:</span>
          <span className="text-[#e8e8f0] font-mono">
            {p.dataKey === "spend"
              ? formatCurrency(p.value)
              : formatNumber(p.value)}
          </span>
        </div>
      ))}
    </div>
  );
};

export default function PerformanceChart({ data, loading }: Props) {
  // Usa dados reais se disponíveis, senão fallback para mock
  const chartData =
    data && data.length > 0
      ? data
      : mockDailyMetrics.map((d) => ({
          date: d.date,
          spend: d.spend,
          clicks: d.clicks,
          conversions: d.conversions,
          impressions: d.impressions,
          roas: d.roas,
        }));

  return (
    <div className="bg-[#16161e] border border-[#1e1e2e] rounded-xl p-5">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-[#e8e8f0] font-semibold text-base">
            Evolução do Período
          </h3>
          <p className="text-[#8888a0] text-xs mt-0.5">Últimos 30 dias</p>
        </div>
        <div className="flex items-center gap-3 text-xs text-[#8888a0]">
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-0.5 bg-[#6366f1] rounded" />
            Investimento
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-0.5 bg-[#22c55e] rounded" />
            Conversões
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-0.5 bg-[#f59e0b] rounded" />
            Cliques
          </div>
        </div>
      </div>

      {loading ? (
        <div className="h-[260px] flex items-center justify-center">
          <div className="w-8 h-8 rounded-full border-2 border-[#1e1e2e] border-t-[#6366f1] animate-spin" />
        </div>
      ) : (
        <ResponsiveContainer width="100%" height={260}>
          <AreaChart data={chartData} margin={{ top: 4, right: 4, bottom: 0, left: 0 }}>
            <defs>
              <linearGradient id="gradSpend" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#6366f1" stopOpacity={0.25} />
                <stop offset="95%" stopColor="#6366f1" stopOpacity={0.0} />
              </linearGradient>
              <linearGradient id="gradConv" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#22c55e" stopOpacity={0.25} />
                <stop offset="95%" stopColor="#22c55e" stopOpacity={0.0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#1e1e2e" vertical={false} />
            <XAxis
              dataKey="date"
              tick={{ fill: "#555568", fontSize: 11 }}
              axisLine={false}
              tickLine={false}
              interval={6}
            />
            <YAxis
              yAxisId="spend"
              orientation="left"
              tick={{ fill: "#555568", fontSize: 11 }}
              axisLine={false}
              tickLine={false}
              tickFormatter={(v) => `R$${(v / 1000).toFixed(0)}k`}
            />
            <YAxis
              yAxisId="conv"
              orientation="right"
              tick={{ fill: "#555568", fontSize: 11 }}
              axisLine={false}
              tickLine={false}
            />
            <Tooltip content={<CustomTooltip />} />
            <Area
              yAxisId="spend"
              type="monotone"
              dataKey="spend"
              name="Investimento"
              stroke="#6366f1"
              strokeWidth={2}
              fill="url(#gradSpend)"
              dot={false}
            />
            <Area
              yAxisId="conv"
              type="monotone"
              dataKey="conversions"
              name="Conversões"
              stroke="#22c55e"
              strokeWidth={2}
              fill="url(#gradConv)"
              dot={false}
            />
            <Area
              yAxisId="conv"
              type="monotone"
              dataKey="clicks"
              name="Cliques"
              stroke="#f59e0b"
              strokeWidth={1.5}
              fill="none"
              dot={false}
              strokeDasharray="4 2"
            />
          </AreaChart>
        </ResponsiveContainer>
      )}
    </div>
  );
}
