"use client";

import { cn } from "@/lib/utils";
import type { Platform } from "@/lib/mock-data";

const config: Record<Platform, { label: string; color: string; bg: string; border: string }> = {
  meta:   { label: "Meta Ads",    color: "#1877F2", bg: "rgba(24,119,242,0.12)", border: "rgba(24,119,242,0.3)" },
  google: { label: "Google Ads",  color: "#4285F4", bg: "rgba(66,133,244,0.12)", border: "rgba(66,133,244,0.3)" },
  tiktok: { label: "TikTok Ads",  color: "#FF0050", bg: "rgba(255,0,80,0.12)",   border: "rgba(255,0,80,0.3)" },
};

export default function PlatformBadge({
  platform,
  className,
}: {
  platform: Platform;
  className?: string;
}) {
  const cfg = config[platform];
  return (
    <span
      className={cn("inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold border", className)}
      style={{ color: cfg.color, background: cfg.bg, borderColor: cfg.border }}
    >
      <span
        className="w-1.5 h-1.5 rounded-full"
        style={{ background: cfg.color }}
      />
      {cfg.label}
    </span>
  );
}
