"use client";

import { cn } from "@/lib/utils";

type Status =
  | "active"
  | "paused"
  | "ended"
  | "sent"
  | "failed"
  | "generated"
  | "draft"
  | "expired"
  | "error"
  | "disconnected"
  | "pending";

const config: Record<Status, { label: string; classes: string; dot?: boolean }> = {
  active:       { label: "Ativo",        classes: "bg-green-500/15 text-green-400 border-green-500/30",  dot: true },
  paused:       { label: "Pausado",      classes: "bg-yellow-500/15 text-yellow-400 border-yellow-500/30" },
  ended:        { label: "Encerrado",    classes: "bg-slate-500/15 text-slate-400 border-slate-500/30" },
  sent:         { label: "Enviado",      classes: "bg-green-500/15 text-green-400 border-green-500/30" },
  failed:       { label: "Falhou",       classes: "bg-red-500/15 text-red-400 border-red-500/30" },
  generated:    { label: "Gerado",       classes: "bg-blue-500/15 text-blue-400 border-blue-500/30" },
  draft:        { label: "Rascunho",     classes: "bg-slate-500/15 text-slate-400 border-slate-500/30" },
  expired:      { label: "Expirado",     classes: "bg-orange-500/15 text-orange-400 border-orange-500/30" },
  error:        { label: "Erro",         classes: "bg-red-500/15 text-red-400 border-red-500/30" },
  disconnected: { label: "Desconectado", classes: "bg-slate-500/15 text-slate-400 border-slate-500/30" },
  pending:      { label: "Pendente",     classes: "bg-purple-500/15 text-purple-400 border-purple-500/30" },
};

interface Props {
  status: Status;
  className?: string;
}

export default function StatusBadge({ status, className }: Props) {
  const cfg = config[status] ?? config.pending;
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium border",
        cfg.classes,
        className
      )}
    >
      {cfg.dot && (
        <span className="w-1.5 h-1.5 rounded-full bg-green-400 pulse-dot" />
      )}
      {cfg.label}
    </span>
  );
}
