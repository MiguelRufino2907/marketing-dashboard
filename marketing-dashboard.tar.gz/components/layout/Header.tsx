"use client";

import { useState } from "react";
import { Bell, Calendar, ChevronDown, RefreshCw } from "lucide-react";
import { useAuth } from "@/lib/auth-context";

const periods = [
  { label: "Hoje", value: "today" },
  { label: "Ontem", value: "yesterday" },
  { label: "Últimos 7 dias", value: "7d" },
  { label: "Últimos 30 dias", value: "30d" },
  { label: "Este mês", value: "this_month" },
  { label: "Mês anterior", value: "last_month" },
];

export default function Header({ title }: { title?: string }) {
  const { user } = useAuth();
  const [period, setPeriod] = useState("30d");
  const [open, setOpen] = useState(false);
  const [syncing, setSyncing] = useState(false);

  const selectedLabel = periods.find((p) => p.value === period)?.label ?? "Últimos 30 dias";

  const handleSync = () => {
    setSyncing(true);
    setTimeout(() => setSyncing(false), 1500);
  };

  return (
    <header className="h-14 border-b border-[#1e1e2e] bg-[#111118]/80 backdrop-blur-sm flex items-center justify-between px-6 sticky top-0 z-30">
      <div className="flex items-center gap-3">
        {title && (
          <h1 className="font-display font-semibold text-[#e8e8f0] text-base">{title}</h1>
        )}
      </div>

      <div className="flex items-center gap-3">
        {/* Period selector */}
        <div className="relative">
          <button
            onClick={() => setOpen(!open)}
            className="flex items-center gap-2 px-3 py-1.5 bg-[#16161e] border border-[#1e1e2e] rounded-lg text-sm text-[#e8e8f0] hover:border-[#6366f1]/40 transition-colors"
          >
            <Calendar size={13} className="text-[#6366f1]" />
            {selectedLabel}
            <ChevronDown size={12} className="text-[#555568]" />
          </button>
          {open && (
            <div className="absolute right-0 top-10 w-48 bg-[#16161e] border border-[#1e1e2e] rounded-xl shadow-2xl z-50 py-1">
              {periods.map((p) => (
                <button
                  key={p.value}
                  onClick={() => { setPeriod(p.value); setOpen(false); }}
                  className={`w-full text-left px-4 py-2 text-sm transition-colors ${
                    period === p.value
                      ? "text-[#a5b4fc] bg-[rgba(99,102,241,0.12)]"
                      : "text-[#8888a0] hover:text-[#e8e8f0] hover:bg-[#1e1e2e]"
                  }`}
                >
                  {p.label}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Sync */}
        <button
          onClick={handleSync}
          className="p-2 bg-[#16161e] border border-[#1e1e2e] rounded-lg text-[#555568] hover:text-[#e8e8f0] transition-colors hover:border-[#6366f1]/40"
        >
          <RefreshCw size={14} className={syncing ? "animate-spin text-[#6366f1]" : ""} />
        </button>

        {/* Notifications */}
        <button className="relative p-2 bg-[#16161e] border border-[#1e1e2e] rounded-lg text-[#555568] hover:text-[#e8e8f0] transition-colors hover:border-[#6366f1]/40">
          <Bell size={14} />
          <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-[#6366f1]" />
        </button>

        {/* Avatar */}
        {user && (
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#6366f1] to-[#8b5cf6] flex items-center justify-center text-white text-xs font-bold">
            {user.name.charAt(0)}
          </div>
        )}
      </div>
    </header>
  );
}
