"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";
import {
  LayoutDashboard,
  FileText,
  Settings,
  Users,
  Link2,
  Calendar,
  LogOut,
  ChevronRight,
  Zap,
} from "lucide-react";
import { useAuth } from "@/lib/auth-context";

const nav = [
  {
    label: "ANALYTICS",
    items: [
      { label: "Dashboard", href: "/dashboard", icon: LayoutDashboard },
      { label: "Meta Ads", href: "/dashboard/meta", icon: Zap, color: "#1877F2" },
      { label: "Google Ads", href: "/dashboard/google", icon: Zap, color: "#4285F4" },
      { label: "TikTok Ads", href: "/dashboard/tiktok", icon: Zap, color: "#FF0050" },
    ],
  },
  {
    label: "RELATÓRIOS",
    items: [
      { label: "Relatórios", href: "/reports", icon: FileText },
      { label: "Novo Relatório", href: "/reports/new", icon: FileText },
      { label: "Agendamentos", href: "/reports/schedule", icon: Calendar },
    ],
  },
  {
    label: "GESTÃO",
    items: [
      { label: "Contas", href: "/management/accounts", icon: Link2 },
      { label: "Clientes", href: "/management/clients", icon: Users },
      { label: "Usuários", href: "/management/users", icon: Users },
      { label: "Configurações", href: "/management/settings", icon: Settings },
    ],
  },
];

export default function Sidebar() {
  const pathname = usePathname();
  const { user, logout } = useAuth();

  return (
    <aside className="fixed left-0 top-0 h-full w-56 bg-[#111118] border-r border-[#1e1e2e] flex flex-col z-40">
      {/* Logo */}
      <div className="px-5 py-5 border-b border-[#1e1e2e]">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-[#6366f1] flex items-center justify-center">
            <Zap size={16} fill="white" className="text-white" />
          </div>
          <div>
            <p className="font-display font-bold text-[#e8e8f0] text-sm">AdsPulse</p>
            <p className="text-[#555568] text-[10px]">Marketing Analytics</p>
          </div>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-5">
        {nav.map((section) => (
          <div key={section.label}>
            <p className="text-[#555568] text-[10px] font-semibold tracking-widest px-2 mb-2">
              {section.label}
            </p>
            <ul className="space-y-0.5">
              {section.items.map((item) => {
                const active =
                  item.href === "/dashboard"
                    ? pathname === "/dashboard"
                    : pathname.startsWith(item.href);
                return (
                  <li key={item.href}>
                    <Link
                      href={item.href}
                      className={cn(
                        "flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-sm font-medium transition-all",
                        active
                          ? "bg-[rgba(99,102,241,0.15)] text-[#a5b4fc]"
                          : "text-[#8888a0] hover:text-[#e8e8f0] hover:bg-[#1e1e2e]"
                      )}
                    >
                      <item.icon
                        size={15}
                        style={{ color: active ? "#a5b4fc" : item.color }}
                      />
                      {item.label}
                      {active && (
                        <ChevronRight size={12} className="ml-auto text-[#6366f1]" />
                      )}
                    </Link>
                  </li>
                );
              })}
            </ul>
          </div>
        ))}
      </nav>

      {/* User */}
      {user && (
        <div className="border-t border-[#1e1e2e] px-3 py-3">
          <div className="flex items-center gap-2.5 px-2 py-2">
            <div className="w-8 h-8 rounded-full bg-[#6366f1] flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
              {user.name.charAt(0)}
            </div>
            <div className="min-w-0">
              <p className="text-[#e8e8f0] text-xs font-medium truncate">{user.name}</p>
              <p className="text-[#555568] text-[10px] capitalize">{user.role}</p>
            </div>
            <button
              onClick={logout}
              className="ml-auto p-1.5 rounded-lg hover:bg-[#1e1e2e] text-[#555568] hover:text-red-400 transition-colors"
              title="Sair"
            >
              <LogOut size={13} />
            </button>
          </div>
        </div>
      )}
    </aside>
  );
}
