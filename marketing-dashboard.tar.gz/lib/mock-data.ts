import { subDays, format } from "date-fns";

export type Platform = "meta" | "google" | "tiktok";
export type CampaignStatus = "active" | "paused" | "ended";
export type ReportStatus = "draft" | "generated" | "sent" | "failed";
export type UserRole = "admin" | "analyst" | "client";

export interface CampaignMetrics {
  id: string;
  accountId: string;
  platform: Platform;
  campaignId: string;
  campaignName: string;
  status: CampaignStatus;
  date: string;
  impressions: number;
  reach: number;
  clicks: number;
  ctr: number;
  cpc: number;
  cpm: number;
  spend: number;
  conversions: number;
  cpa: number;
  roas: number;
  revenue: number;
}

export interface DailyMetric {
  date: string;
  spend: number;
  impressions: number;
  clicks: number;
  conversions: number;
  roas: number;
  meta: number;
  google: number;
  tiktok: number;
}

export interface Client {
  id: string;
  name: string;
  logoUrl?: string;
  contactEmail: string;
  contactPhone?: string;
  isActive: boolean;
  createdAt: string;
  totalSpend: number;
  campaigns: number;
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatar?: string;
  isActive: boolean;
  lastLogin: string;
  clientId?: string;
}

export interface AdAccount {
  id: string;
  platform: Platform;
  accountId: string;
  accountName: string;
  status: "active" | "expired" | "error" | "disconnected";
  lastSync: string;
  clientId?: string;
  spend30d: number;
}

export interface Report {
  id: string;
  name: string;
  clientId?: string;
  clientName?: string;
  dateRange: { start: string; end: string };
  platforms: Platform[];
  generatedAt: string;
  sentAt?: string;
  deliveryChannel: "email" | "whatsapp" | "both" | "manual";
  recipients: string[];
  status: ReportStatus;
}

export interface Schedule {
  id: string;
  name: string;
  reportTemplateId: string;
  frequency: "daily" | "weekly" | "biweekly" | "monthly";
  dayOfWeek?: number;
  dayOfMonth?: number;
  time: string;
  timezone: string;
  recipients: string[];
  channel: "email" | "whatsapp" | "both";
  isActive: boolean;
  lastRun?: string;
  nextRun: string;
  clientName: string;
}

// ── Campaigns ──────────────────────────────────────────────────────────────

export const mockCampaigns: CampaignMetrics[] = [
  {
    id: "1",
    accountId: "acc-meta-1",
    platform: "meta",
    campaignId: "c-001",
    campaignName: "Black Friday 2024 - Conversão",
    status: "active",
    date: format(subDays(new Date(), 0), "yyyy-MM-dd"),
    spend: 15420.5,
    impressions: 892340,
    reach: 612000,
    clicks: 21456,
    ctr: 2.4,
    cpc: 0.72,
    cpm: 17.28,
    conversions: 342,
    cpa: 45.09,
    roas: 4.2,
    revenue: 64766.1,
  },
  {
    id: "2",
    accountId: "acc-meta-1",
    platform: "meta",
    campaignId: "c-002",
    campaignName: "Retargeting - Carrinho Abandonado",
    status: "active",
    date: format(subDays(new Date(), 0), "yyyy-MM-dd"),
    spend: 4230.0,
    impressions: 215600,
    reach: 98400,
    clicks: 7812,
    ctr: 3.6,
    cpc: 0.54,
    cpm: 19.62,
    conversions: 198,
    cpa: 21.36,
    roas: 7.8,
    revenue: 32994.0,
  },
  {
    id: "3",
    accountId: "acc-meta-1",
    platform: "meta",
    campaignId: "c-003",
    campaignName: "Lookalike - Compradores",
    status: "paused",
    date: format(subDays(new Date(), 0), "yyyy-MM-dd"),
    spend: 2100.0,
    impressions: 340000,
    reach: 290000,
    clicks: 5440,
    ctr: 1.6,
    cpc: 0.39,
    cpm: 6.18,
    conversions: 72,
    cpa: 29.17,
    roas: 3.1,
    revenue: 6510.0,
  },
  {
    id: "4",
    accountId: "acc-google-1",
    platform: "google",
    campaignId: "c-004",
    campaignName: "Search - Marca + Concorrentes",
    status: "active",
    date: format(subDays(new Date(), 0), "yyyy-MM-dd"),
    spend: 8930.0,
    impressions: 145600,
    reach: 145600,
    clicks: 12840,
    ctr: 8.8,
    cpc: 0.7,
    cpm: 61.33,
    conversions: 287,
    cpa: 31.11,
    roas: 6.8,
    revenue: 60724.0,
  },
  {
    id: "5",
    accountId: "acc-google-1",
    platform: "google",
    campaignId: "c-005",
    campaignName: "Performance Max - E-commerce",
    status: "active",
    date: format(subDays(new Date(), 0), "yyyy-MM-dd"),
    spend: 6750.0,
    impressions: 920000,
    reach: 890000,
    clicks: 18200,
    ctr: 1.98,
    cpc: 0.37,
    cpm: 7.34,
    conversions: 210,
    cpa: 32.14,
    roas: 5.2,
    revenue: 35100.0,
  },
  {
    id: "6",
    accountId: "acc-google-1",
    platform: "google",
    campaignId: "c-006",
    campaignName: "Display - Remarketing",
    status: "active",
    date: format(subDays(new Date(), 0), "yyyy-MM-dd"),
    spend: 1840.0,
    impressions: 1450000,
    reach: 980000,
    clicks: 4320,
    ctr: 0.3,
    cpc: 0.43,
    cpm: 1.27,
    conversions: 48,
    cpa: 38.33,
    roas: 2.9,
    revenue: 5336.0,
  },
  {
    id: "7",
    accountId: "acc-tiktok-1",
    platform: "tiktok",
    campaignId: "c-007",
    campaignName: "UGC Creators - Awareness",
    status: "active",
    date: format(subDays(new Date(), 0), "yyyy-MM-dd"),
    spend: 5200.0,
    impressions: 1250000,
    reach: 1100000,
    clicks: 8750,
    ctr: 0.7,
    cpc: 0.59,
    cpm: 4.16,
    conversions: 98,
    cpa: 53.06,
    roas: 2.1,
    revenue: 10920.0,
  },
  {
    id: "8",
    accountId: "acc-tiktok-1",
    platform: "tiktok",
    campaignId: "c-008",
    campaignName: "TopView - Lançamento Produto",
    status: "active",
    date: format(subDays(new Date(), 0), "yyyy-MM-dd"),
    spend: 8900.0,
    impressions: 3200000,
    reach: 2800000,
    clicks: 22400,
    ctr: 0.7,
    cpc: 0.4,
    cpm: 2.78,
    conversions: 156,
    cpa: 57.05,
    roas: 1.9,
    revenue: 16910.0,
  },
  {
    id: "9",
    accountId: "acc-tiktok-1",
    platform: "tiktok",
    campaignId: "c-009",
    campaignName: "Spark Ads - Conversão",
    status: "paused",
    date: format(subDays(new Date(), 0), "yyyy-MM-dd"),
    spend: 1200.0,
    impressions: 280000,
    reach: 240000,
    clicks: 3360,
    ctr: 1.2,
    cpc: 0.36,
    cpm: 4.29,
    conversions: 28,
    cpa: 42.86,
    roas: 2.8,
    revenue: 3360.0,
  },
  {
    id: "10",
    accountId: "acc-meta-1",
    platform: "meta",
    campaignId: "c-010",
    campaignName: "Prospecção - Interesse Moda",
    status: "ended",
    date: format(subDays(new Date(), 5), "yyyy-MM-dd"),
    spend: 3400.0,
    impressions: 560000,
    reach: 480000,
    clicks: 9800,
    ctr: 1.75,
    cpc: 0.35,
    cpm: 6.07,
    conversions: 88,
    cpa: 38.64,
    roas: 3.4,
    revenue: 11560.0,
  },
];

// ── Daily Metrics (last 30 days) ───────────────────────────────────────────

function generateDailyMetrics(): DailyMetric[] {
  const days: DailyMetric[] = [];
  for (let i = 29; i >= 0; i--) {
    const base = 1 - i / 60;
    const noise = () => 0.85 + Math.random() * 0.3;
    const metaSpend = 1800 * base * noise();
    const googleSpend = 1200 * base * noise();
    const tiktokSpend = 700 * base * noise();
    days.push({
      date: format(subDays(new Date(), i), "dd/MM"),
      spend: Math.round(metaSpend + googleSpend + tiktokSpend),
      impressions: Math.round(280000 * base * noise()),
      clicks: Math.round(7200 * base * noise()),
      conversions: Math.round(88 * base * noise()),
      roas: parseFloat((3.5 + Math.random() * 1.5).toFixed(2)),
      meta: Math.round(metaSpend),
      google: Math.round(googleSpend),
      tiktok: Math.round(tiktokSpend),
    });
  }
  return days;
}

export const mockDailyMetrics = generateDailyMetrics();

// ── Aggregate KPIs ──────────────────────────────────────────────────────────

export const mockKPIs = {
  totalSpend: mockCampaigns.reduce((s, c) => s + c.spend, 0),
  totalImpressions: mockCampaigns.reduce((s, c) => s + c.impressions, 0),
  totalClicks: mockCampaigns.reduce((s, c) => s + c.clicks, 0),
  avgCTR: parseFloat(
    (
      mockCampaigns.reduce((s, c) => s + c.ctr, 0) / mockCampaigns.length
    ).toFixed(2)
  ),
  avgCPM: parseFloat(
    (
      mockCampaigns.reduce((s, c) => s + c.cpm, 0) / mockCampaigns.length
    ).toFixed(2)
  ),
  avgCPC: parseFloat(
    (
      mockCampaigns.reduce((s, c) => s + c.cpc, 0) / mockCampaigns.length
    ).toFixed(2)
  ),
  totalConversions: mockCampaigns.reduce((s, c) => s + c.conversions, 0),
  avgCPA: parseFloat(
    (
      mockCampaigns.reduce((s, c) => s + c.cpa, 0) / mockCampaigns.length
    ).toFixed(2)
  ),
  avgROAS: parseFloat(
    (
      mockCampaigns.reduce((s, c) => s + c.roas, 0) / mockCampaigns.length
    ).toFixed(2)
  ),
  totalReach: mockCampaigns.reduce((s, c) => s + c.reach, 0),
  // previous period deltas (mock)
  spendDelta: 12.4,
  impressionsDelta: 8.2,
  clicksDelta: 15.7,
  ctrDelta: 3.1,
  cpmDelta: -4.2,
  cpcDelta: -6.8,
  conversionsDelta: 22.3,
  cpaDelta: -9.4,
  roasDelta: 11.6,
  reachDelta: 7.9,
};

// ── Platform breakdown ──────────────────────────────────────────────────────

export const platformBreakdown = [
  {
    name: "Meta Ads",
    platform: "meta" as Platform,
    spend: mockCampaigns
      .filter((c) => c.platform === "meta")
      .reduce((s, c) => s + c.spend, 0),
    impressions: mockCampaigns
      .filter((c) => c.platform === "meta")
      .reduce((s, c) => s + c.impressions, 0),
    clicks: mockCampaigns
      .filter((c) => c.platform === "meta")
      .reduce((s, c) => s + c.clicks, 0),
    conversions: mockCampaigns
      .filter((c) => c.platform === "meta")
      .reduce((s, c) => s + c.conversions, 0),
    roas: 5.1,
    color: "#1877F2",
  },
  {
    name: "Google Ads",
    platform: "google" as Platform,
    spend: mockCampaigns
      .filter((c) => c.platform === "google")
      .reduce((s, c) => s + c.spend, 0),
    impressions: mockCampaigns
      .filter((c) => c.platform === "google")
      .reduce((s, c) => s + c.impressions, 0),
    clicks: mockCampaigns
      .filter((c) => c.platform === "google")
      .reduce((s, c) => s + c.clicks, 0),
    conversions: mockCampaigns
      .filter((c) => c.platform === "google")
      .reduce((s, c) => s + c.conversions, 0),
    roas: 4.8,
    color: "#4285F4",
  },
  {
    name: "TikTok Ads",
    platform: "tiktok" as Platform,
    spend: mockCampaigns
      .filter((c) => c.platform === "tiktok")
      .reduce((s, c) => s + c.spend, 0),
    impressions: mockCampaigns
      .filter((c) => c.platform === "tiktok")
      .reduce((s, c) => s + c.impressions, 0),
    clicks: mockCampaigns
      .filter((c) => c.platform === "tiktok")
      .reduce((s, c) => s + c.clicks, 0),
    conversions: mockCampaigns
      .filter((c) => c.platform === "tiktok")
      .reduce((s, c) => s + c.conversions, 0),
    roas: 2.2,
    color: "#FF0050",
  },
];

// ── Meta Creatives ───────────────────────────────────────────────────────────

export interface MetaCreative {
  id: string;
  name: string;
  type: "image" | "video" | "carousel";
  campaignName: string;
  status: "active" | "paused" | "review";
  ctr: number;
  cpc: number;
  impressions: number;
  clicks: number;
  conversions: number;
  spend: number;
  thumbnailColor: string;
}

export const mockMetaCreatives: MetaCreative[] = [
  { id: "cr-1", name: "Banner Sale 50% Off - Vídeo 15s", type: "video", campaignName: "Black Friday 2024 - Conversão", status: "active", ctr: 3.8, cpc: 0.62, impressions: 312000, clicks: 11856, conversions: 142, spend: 7350.0, thumbnailColor: "#1877F2" },
  { id: "cr-2", name: "Carrossel Novidades Inverno", type: "carousel", campaignName: "Black Friday 2024 - Conversão", status: "active", ctr: 2.9, cpc: 0.81, impressions: 198000, clicks: 5742, conversions: 98, spend: 4649.0, thumbnailColor: "#0d6efd" },
  { id: "cr-3", name: "UGC Review - Influencer A", type: "video", campaignName: "Retargeting - Carrinho Abandonado", status: "active", ctr: 4.6, cpc: 0.48, impressions: 89400, clicks: 4112, conversions: 118, spend: 1975.0, thumbnailColor: "#6610f2" },
  { id: "cr-4", name: "Static Feed - Produto Destaque", type: "image", campaignName: "Retargeting - Carrinho Abandonado", status: "paused", ctr: 1.9, cpc: 1.12, impressions: 62400, clicks: 1186, conversions: 28, spend: 1328.0, thumbnailColor: "#198754" },
  { id: "cr-5", name: "Reels Ad - Prova Social", type: "video", campaignName: "Lookalike - Compradores", status: "active", ctr: 2.3, cpc: 0.74, impressions: 145000, clicks: 3335, conversions: 44, spend: 2468.0, thumbnailColor: "#fd7e14" },
  { id: "cr-6", name: "Story Full Screen - CTA", type: "image", campaignName: "Lookalike - Compradores", status: "review", ctr: 1.4, cpc: 0.92, impressions: 78600, clicks: 1100, conversions: 18, spend: 1012.0, thumbnailColor: "#dc3545" },
];

// ── Meta Ad Sets ──────────────────────────────────────────────────────────────

export interface MetaAdSet {
  id: string;
  name: string;
  campaignName: string;
  status: "active" | "paused" | "ended";
  audience: string;
  budget: number;
  spend: number;
  impressions: number;
  clicks: number;
  ctr: number;
  conversions: number;
  roas: number;
}

export const mockMetaAdSets: MetaAdSet[] = [
  { id: "as-1", name: "Mulheres 25-44 SP/RJ", campaignName: "Black Friday 2024 - Conversão", status: "active", audience: "Interesses: Moda, Beleza", budget: 600, spend: 580.5, impressions: 89200, clicks: 2140, ctr: 2.4, conversions: 48, roas: 4.8 },
  { id: "as-2", name: "Lookalike 1% Compradores", campaignName: "Black Friday 2024 - Conversão", status: "active", audience: "LAL 1% — Compradores 90d", budget: 800, spend: 762.0, impressions: 124000, clicks: 3100, ctr: 2.5, conversions: 67, roas: 5.2 },
  { id: "as-3", name: "Retargeting 7d Site", campaignName: "Retargeting - Carrinho Abandonado", status: "active", audience: "Visitantes — 7 dias", budget: 400, spend: 388.0, impressions: 41200, clicks: 1648, ctr: 4.0, conversions: 92, roas: 9.1 },
  { id: "as-4", name: "Retargeting 30d Carrinho", campaignName: "Retargeting - Carrinho Abandonado", status: "active", audience: "Add to cart — 30 dias", budget: 350, spend: 301.0, impressions: 29800, clicks: 894, ctr: 3.0, conversions: 56, roas: 7.2 },
  { id: "as-5", name: "LAL 2-5% Amplo", campaignName: "Lookalike - Compradores", status: "paused", audience: "LAL 2-5% — Compradores", budget: 200, spend: 198.0, impressions: 68000, clicks: 952, ctr: 1.4, conversions: 21, roas: 2.8 },
];

// ── Google Keywords ──────────────────────────────────────────────────────────

export interface GoogleKeyword {
  id: string;
  keyword: string;
  matchType: "exact" | "phrase" | "broad";
  campaignName: string;
  impressions: number;
  clicks: number;
  ctr: number;
  cpc: number;
  conversions: number;
  cpa: number;
  qualityScore: number;
  spend: number;
}

export const mockGoogleKeywords: GoogleKeyword[] = [
  { id: "kw-1", keyword: "loja de roupas online", matchType: "exact", campaignName: "Search - Marca + Concorrentes", impressions: 18400, clicks: 2208, ctr: 12.0, cpc: 0.85, conversions: 64, cpa: 29.25, qualityScore: 9, spend: 1877.0 },
  { id: "kw-2", keyword: "comprar vestido festa", matchType: "phrase", campaignName: "Search - Marca + Concorrentes", impressions: 22100, clicks: 2210, ctr: 10.0, cpc: 0.72, conversions: 48, cpa: 33.15, qualityScore: 8, spend: 1591.0 },
  { id: "kw-3", keyword: "moda feminina barata", matchType: "broad", campaignName: "Search - Marca + Concorrentes", impressions: 34200, clicks: 1710, ctr: 5.0, cpc: 0.56, conversions: 31, cpa: 30.97, qualityScore: 6, spend: 960.0 },
  { id: "kw-4", keyword: "[fashion brasil]", matchType: "exact", campaignName: "Search - Marca + Concorrentes", impressions: 8900, clicks: 1602, ctr: 18.0, cpc: 0.31, conversions: 62, cpa: 8.02, qualityScore: 10, spend: 497.0 },
  { id: "kw-5", keyword: "roupas femininas promoção", matchType: "phrase", campaignName: "Search - Marca + Concorrentes", impressions: 15600, clicks: 1404, ctr: 9.0, cpc: 0.63, conversions: 29, cpa: 30.62, qualityScore: 7, spend: 885.0 },
  { id: "kw-6", keyword: "e-commerce moda brasil", matchType: "broad", campaignName: "Performance Max - E-commerce", impressions: 28400, clicks: 1278, ctr: 4.5, cpc: 0.48, conversions: 22, cpa: 27.85, qualityScore: 7, spend: 613.0 },
  { id: "kw-7", keyword: "blusa social feminina", matchType: "phrase", campaignName: "Performance Max - E-commerce", impressions: 11200, clicks: 1232, ctr: 11.0, cpc: 0.77, conversions: 38, cpa: 24.97, qualityScore: 8, spend: 949.0 },
  { id: "kw-8", keyword: "calça jeans feminina", matchType: "exact", campaignName: "Performance Max - E-commerce", impressions: 19800, clicks: 2178, ctr: 11.0, cpc: 0.69, conversions: 55, cpa: 27.31, qualityScore: 9, spend: 1503.0 },
];

// ── Google Device Performance ─────────────────────────────────────────────────

export const mockDevicePerformance = [
  { device: "Mobile", impressions: 1280000, clicks: 21420, conversions: 312, spend: 9840, ctr: 1.67, cpa: 31.54 },
  { device: "Desktop", impressions: 680000, clicks: 12580, conversions: 218, spend: 6120, ctr: 1.85, cpa: 28.07 },
  { device: "Tablet", impressions: 142000, clicks: 1840, conversions: 22, spend: 780, ctr: 1.30, cpa: 35.45 },
];

// ── TikTok Video Creatives ────────────────────────────────────────────────────

export interface TikTokCreative {
  id: string;
  name: string;
  campaignName: string;
  status: "active" | "paused" | "review";
  views: number;
  views3s: number;
  views6s: number;
  completionRate: number;
  ctr: number;
  cpc: number;
  spend: number;
  conversions: number;
  isTrending: boolean;
  thumbnailColor: string;
  duration: number;
}

export const mockTikTokCreatives: TikTokCreative[] = [
  { id: "tt-1", name: "UGC Unboxing - Influencer @modabr", campaignName: "UGC Creators - Awareness", status: "active", views: 892000, views3s: 714000, views6s: 589000, completionRate: 42.3, ctr: 1.8, cpc: 0.44, spend: 2180.0, conversions: 38, isTrending: true, thumbnailColor: "#FF0050", duration: 28 },
  { id: "tt-2", name: "Trend Sound - Outfit GRWM", campaignName: "UGC Creators - Awareness", status: "active", views: 1240000, views3s: 992000, views6s: 793000, completionRate: 38.9, ctr: 1.2, cpc: 0.52, spend: 1890.0, conversions: 24, isTrending: true, thumbnailColor: "#00F2EA", duration: 22 },
  { id: "tt-3", name: "Duet Challenge - #MinhaModa", campaignName: "UGC Creators - Awareness", status: "paused", views: 340000, views3s: 238000, views6s: 170000, completionRate: 28.4, ctr: 0.8, cpc: 0.71, spend: 860.0, conversions: 11, isTrending: false, thumbnailColor: "#6366f1", duration: 35 },
  { id: "tt-4", name: "Product Showcase 9:16 - Coleção", campaignName: "TopView - Lançamento Produto", status: "active", views: 2100000, views3s: 1890000, views6s: 1680000, completionRate: 62.1, ctr: 0.9, cpc: 0.38, spend: 4200.0, conversions: 82, isTrending: true, thumbnailColor: "#FF0050", duration: 15 },
  { id: "tt-5", name: "Testimonial - Cliente Real", campaignName: "Spark Ads - Conversão", status: "active", views: 280000, views3s: 196000, views6s: 140000, completionRate: 33.7, ctr: 1.4, cpc: 0.36, spend: 980.0, conversions: 28, isTrending: false, thumbnailColor: "#f59e0b", duration: 42 },
  { id: "tt-6", name: "Before & After - Styling Tip", campaignName: "Spark Ads - Conversão", status: "review", views: 188000, views3s: 131600, views6s: 94000, completionRate: 29.8, ctr: 1.1, cpc: 0.48, spend: 690.0, conversions: 14, isTrending: false, thumbnailColor: "#10b981", duration: 31 },
];

// ── Clients ──────────────────────────────────────────────────────────────────

export const mockClients: Client[] = [
  {
    id: "client-1",
    name: "Loja Fashion Brasil",
    contactEmail: "marketing@fashionbr.com",
    contactPhone: "+55 11 99999-0001",
    isActive: true,
    createdAt: "2023-08-15",
    totalSpend: 87450.0,
    campaigns: 12,
  },
  {
    id: "client-2",
    name: "TechGadgets Store",
    contactEmail: "ads@techgadgets.com.br",
    contactPhone: "+55 11 99999-0002",
    isActive: true,
    createdAt: "2023-11-02",
    totalSpend: 54320.0,
    campaigns: 8,
  },
  {
    id: "client-3",
    name: "Clínica Estética Premium",
    contactEmail: "digital@clinicapremium.com",
    contactPhone: "+55 21 99999-0003",
    isActive: true,
    createdAt: "2024-01-20",
    totalSpend: 31200.0,
    campaigns: 5,
  },
  {
    id: "client-4",
    name: "Imobiliária Horizonte",
    contactEmail: "mkt@imobhorizonte.com.br",
    isActive: false,
    createdAt: "2023-06-10",
    totalSpend: 18900.0,
    campaigns: 3,
  },
];

// ── Users ─────────────────────────────────────────────────────────────────────

export const mockUsers: User[] = [
  {
    id: "user-1",
    name: "Ana Ribeiro",
    email: "ana@agencia.com",
    role: "admin",
    isActive: true,
    lastLogin: format(subDays(new Date(), 0), "yyyy-MM-dd HH:mm"),
  },
  {
    id: "user-2",
    name: "Carlos Mendes",
    email: "carlos@agencia.com",
    role: "analyst",
    isActive: true,
    lastLogin: format(subDays(new Date(), 1), "yyyy-MM-dd HH:mm"),
  },
  {
    id: "user-3",
    name: "Juliana Costa",
    email: "juliana@agencia.com",
    role: "analyst",
    isActive: true,
    lastLogin: format(subDays(new Date(), 3), "yyyy-MM-dd HH:mm"),
  },
  {
    id: "user-4",
    name: "Felipe Santos",
    email: "felipe@fashionbr.com",
    role: "client",
    isActive: true,
    lastLogin: format(subDays(new Date(), 5), "yyyy-MM-dd HH:mm"),
    clientId: "client-1",
  },
  {
    id: "user-5",
    name: "Mariana Lima",
    email: "mariana@techgadgets.com.br",
    role: "client",
    isActive: false,
    lastLogin: format(subDays(new Date(), 15), "yyyy-MM-dd HH:mm"),
    clientId: "client-2",
  },
];

// ── Ad Accounts ───────────────────────────────────────────────────────────────

export const mockAccounts: AdAccount[] = [
  {
    id: "acc-meta-1",
    platform: "meta",
    accountId: "act_1234567890",
    accountName: "Loja Fashion Brasil — Meta",
    status: "active",
    lastSync: format(subDays(new Date(), 0), "yyyy-MM-dd HH:mm"),
    clientId: "client-1",
    spend30d: 25180.5,
  },
  {
    id: "acc-google-1",
    platform: "google",
    accountId: "987-654-3210",
    accountName: "Loja Fashion Brasil — Google",
    status: "active",
    lastSync: format(subDays(new Date(), 0), "yyyy-MM-dd HH:mm"),
    clientId: "client-1",
    spend30d: 17520.0,
  },
  {
    id: "acc-tiktok-1",
    platform: "tiktok",
    accountId: "7123456789012345678",
    accountName: "Loja Fashion Brasil — TikTok",
    status: "active",
    lastSync: format(subDays(new Date(), 1), "yyyy-MM-dd HH:mm"),
    clientId: "client-1",
    spend30d: 15300.0,
  },
  {
    id: "acc-meta-2",
    platform: "meta",
    accountId: "act_9876543210",
    accountName: "TechGadgets — Meta",
    status: "expired",
    lastSync: format(subDays(new Date(), 7), "yyyy-MM-dd HH:mm"),
    clientId: "client-2",
    spend30d: 12400.0,
  },
  {
    id: "acc-google-2",
    platform: "google",
    accountId: "123-456-7890",
    accountName: "Clínica Estética — Google",
    status: "error",
    lastSync: format(subDays(new Date(), 3), "yyyy-MM-dd HH:mm"),
    clientId: "client-3",
    spend30d: 8900.0,
  },
];

// ── Reports ───────────────────────────────────────────────────────────────────

export const mockReports: Report[] = [
  {
    id: "rep-1",
    name: "Relatório Semanal — Fashion Brasil",
    clientId: "client-1",
    clientName: "Loja Fashion Brasil",
    dateRange: {
      start: format(subDays(new Date(), 7), "yyyy-MM-dd"),
      end: format(subDays(new Date(), 1), "yyyy-MM-dd"),
    },
    platforms: ["meta", "google", "tiktok"],
    generatedAt: format(subDays(new Date(), 1), "yyyy-MM-dd HH:mm"),
    sentAt: format(subDays(new Date(), 1), "yyyy-MM-dd HH:mm"),
    deliveryChannel: "email",
    recipients: ["felipe@fashionbr.com"],
    status: "sent",
  },
  {
    id: "rep-2",
    name: "Relatório Mensal — TechGadgets",
    clientId: "client-2",
    clientName: "TechGadgets Store",
    dateRange: {
      start: format(subDays(new Date(), 30), "yyyy-MM-dd"),
      end: format(subDays(new Date(), 1), "yyyy-MM-dd"),
    },
    platforms: ["meta", "google"],
    generatedAt: format(subDays(new Date(), 2), "yyyy-MM-dd HH:mm"),
    deliveryChannel: "email",
    recipients: ["mariana@techgadgets.com.br"],
    status: "generated",
  },
  {
    id: "rep-3",
    name: "Performance Review — Clínica Premium",
    clientId: "client-3",
    clientName: "Clínica Estética Premium",
    dateRange: {
      start: format(subDays(new Date(), 14), "yyyy-MM-dd"),
      end: format(subDays(new Date(), 1), "yyyy-MM-dd"),
    },
    platforms: ["meta", "google"],
    generatedAt: format(subDays(new Date(), 3), "yyyy-MM-dd HH:mm"),
    sentAt: format(subDays(new Date(), 3), "yyyy-MM-dd HH:mm"),
    deliveryChannel: "whatsapp",
    recipients: ["+55 21 99999-0003"],
    status: "failed",
  },
  {
    id: "rep-4",
    name: "Relatório Semanal — Fashion Brasil",
    clientId: "client-1",
    clientName: "Loja Fashion Brasil",
    dateRange: {
      start: format(subDays(new Date(), 14), "yyyy-MM-dd"),
      end: format(subDays(new Date(), 8), "yyyy-MM-dd"),
    },
    platforms: ["meta", "google", "tiktok"],
    generatedAt: format(subDays(new Date(), 8), "yyyy-MM-dd HH:mm"),
    sentAt: format(subDays(new Date(), 8), "yyyy-MM-dd HH:mm"),
    deliveryChannel: "email",
    recipients: ["felipe@fashionbr.com"],
    status: "sent",
  },
];

// ── Schedules ─────────────────────────────────────────────────────────────────

export const mockSchedules: Schedule[] = [
  {
    id: "sch-1",
    name: "Semanal Fashion Brasil",
    reportTemplateId: "rep-1",
    frequency: "weekly",
    dayOfWeek: 1,
    time: "09:00",
    timezone: "America/Sao_Paulo",
    recipients: ["felipe@fashionbr.com"],
    channel: "email",
    isActive: true,
    lastRun: format(subDays(new Date(), 7), "yyyy-MM-dd HH:mm"),
    nextRun: format(subDays(new Date(), -7), "yyyy-MM-dd 09:00"),
    clientName: "Loja Fashion Brasil",
  },
  {
    id: "sch-2",
    name: "Mensal TechGadgets",
    reportTemplateId: "rep-2",
    frequency: "monthly",
    dayOfMonth: 1,
    time: "08:00",
    timezone: "America/Sao_Paulo",
    recipients: ["mariana@techgadgets.com.br"],
    channel: "both",
    isActive: true,
    lastRun: format(subDays(new Date(), 30), "yyyy-MM-dd HH:mm"),
    nextRun: format(subDays(new Date(), -30), "yyyy-MM-dd 08:00"),
    clientName: "TechGadgets Store",
  },
  {
    id: "sch-3",
    name: "Quinzenal Clínica Premium",
    reportTemplateId: "rep-3",
    frequency: "biweekly",
    time: "10:00",
    timezone: "America/Sao_Paulo",
    recipients: ["+55 21 99999-0003"],
    channel: "whatsapp",
    isActive: false,
    lastRun: format(subDays(new Date(), 14), "yyyy-MM-dd HH:mm"),
    nextRun: format(subDays(new Date(), -14), "yyyy-MM-dd 10:00"),
    clientName: "Clínica Estética Premium",
  },
];
