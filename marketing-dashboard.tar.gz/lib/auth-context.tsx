"use client";

import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  useCallback,
} from "react";

// ────────────────────────────────────────────────────────────────
// Detecta se o Supabase está configurado com valores reais
// ────────────────────────────────────────────────────────────────
const checkSupabaseConfigured = () =>
  typeof window !== "undefined" &&
  !!process.env.NEXT_PUBLIC_SUPABASE_URL &&
  !process.env.NEXT_PUBLIC_SUPABASE_URL.includes("SEU_PROJECT_ID") &&
  !!process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY &&
  !process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY.includes("sua_anon_key");

// ────────────────────────────────────────────────────────────────
// Tipos
// ────────────────────────────────────────────────────────────────
export interface AuthUser {
  id: string;
  name: string;
  email: string;
  role: "admin" | "analyst" | "client" | "viewer";
  avatar?: string;
  clientId?: string;
}

interface AuthContextType {
  user: AuthUser | null;
  login: (email: string, password: string) => Promise<boolean>;
  logout: () => void;
  isLoading: boolean;
  isSupabase: boolean; // true = usando auth real; false = usando mock
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  login: async () => false,
  logout: () => {},
  isLoading: true,
  isSupabase: false,
});

// ────────────────────────────────────────────────────────────────
// Credenciais demo (usadas apenas quando Supabase NÃO está conf.)
// ────────────────────────────────────────────────────────────────
const MOCK_CREDENTIALS = [
  {
    email: "admin@agencia.com",
    password: "admin123",
    user: {
      id: "user-1",
      name: "Ana Ribeiro",
      email: "admin@agencia.com",
      role: "admin" as const,
    },
  },
  {
    email: "analyst@agencia.com",
    password: "analyst123",
    user: {
      id: "user-2",
      name: "Carlos Mendes",
      email: "analyst@agencia.com",
      role: "analyst" as const,
    },
  },
  {
    email: "cliente@fashionbr.com",
    password: "cliente123",
    user: {
      id: "user-4",
      name: "Felipe Santos",
      email: "cliente@fashionbr.com",
      role: "client" as const,
    },
  },
];

// ────────────────────────────────────────────────────────────────
// Provider
// ────────────────────────────────────────────────────────────────
export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSupabase, setIsSupabase] = useState(false);

  // ── Supabase path ──────────────────────────────────────────────
  const initSupabase = useCallback(async () => {
    const { createClient } = await import("@/lib/supabase/client");
    const supabase = createClient();

    const {
      data: { session },
    } = await supabase.auth.getSession();

    const buildUser = async (supabaseUser: import("@supabase/supabase-js").User): Promise<AuthUser> => {
      // Tenta buscar profile com role
      const { data } = await supabase
        .from("profiles")
        .select("full_name, role, client_id, avatar_url")
        .eq("id", supabaseUser.id)
        .single();

      const profile = data as {
        full_name: string | null;
        role: string | null;
        client_id: string | null;
        avatar_url: string | null;
      } | null;

      return {
        id: supabaseUser.id,
        name:
          profile?.full_name ??
          (supabaseUser.user_metadata as Record<string, string> | undefined)?.full_name ??
          supabaseUser.email ??
          "Usuário",
        email: supabaseUser.email ?? "",
        role: (profile?.role as AuthUser["role"]) ?? "analyst",
        avatar: profile?.avatar_url ?? undefined,
        clientId: profile?.client_id ?? undefined,
      };
    };

    if (session?.user) {
      const authUser = await buildUser(session.user);
      setUser(authUser);
    }
    setIsLoading(false);
    setIsSupabase(true);

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange(async (_event, session) => {
      if (session?.user) {
        const authUser = await buildUser(session.user);
        setUser(authUser);
      } else {
        setUser(null);
      }
      setIsLoading(false);
    });

    return () => subscription.unsubscribe();
  }, []);

  // ── Mock path ──────────────────────────────────────────────────
  const initMock = useCallback(() => {
    try {
      const stored = localStorage.getItem("auth_user");
      if (stored) setUser(JSON.parse(stored));
    } catch {
      // ignore
    }
    setIsLoading(false);
    setIsSupabase(false);
  }, []);

  useEffect(() => {
    let cleanup: (() => void) | undefined;

    if (checkSupabaseConfigured()) {
      initSupabase().then((fn) => {
        cleanup = fn;
      });
    } else {
      initMock();
    }

    return () => cleanup?.();
  }, [initSupabase, initMock]);

  // ── Login ──────────────────────────────────────────────────────
  const login = async (email: string, password: string): Promise<boolean> => {
    if (checkSupabaseConfigured()) {
      try {
        const { createClient } = await import("@/lib/supabase/client");
        const supabase = createClient();
        const { error } = await supabase.auth.signInWithPassword({
          email,
          password,
        });
        return !error;
      } catch {
        return false;
      }
    }

    // Fallback mock
    const match = MOCK_CREDENTIALS.find(
      (c) => c.email === email && c.password === password
    );
    if (match) {
      setUser(match.user);
      localStorage.setItem("auth_user", JSON.stringify(match.user));
      return true;
    }
    return false;
  };

  // ── Logout ─────────────────────────────────────────────────────
  const logout = async () => {
    if (checkSupabaseConfigured()) {
      const { createClient } = await import("@/lib/supabase/client");
      const supabase = createClient();
      await supabase.auth.signOut();
      setUser(null);
    } else {
      setUser(null);
      localStorage.removeItem("auth_user");
    }
  };

  return (
    <AuthContext.Provider value={{ user, login, logout, isLoading, isSupabase }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
