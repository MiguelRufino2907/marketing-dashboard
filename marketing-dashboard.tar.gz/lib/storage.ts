/**
 * lib/storage.ts
 * Helpers para upload/download via Supabase Storage.
 * Requer que o Supabase esteja configurado com os buckets:
 *   - client-logos  (público)
 *   - reports       (privado)
 */

async function getSupabase() {
  const { createClient } = await import('@/lib/supabase/client')
  return createClient()
}

// ────────────────────────────────────────────────────────────────
// Logos de Clientes (bucket público)
// ────────────────────────────────────────────────────────────────

/**
 * Faz upload do logo do cliente e retorna a URL pública.
 * O arquivo anterior (se existir) é sobrescrito.
 */
export async function uploadClientLogo(
  clientId: string,
  file: File
): Promise<string> {
  const supabase = await getSupabase()
  const ext = file.name.split('.').pop() ?? 'png'
  const path = `${clientId}/logo.${ext}`

  const { error: uploadError } = await supabase.storage
    .from('client-logos')
    .upload(path, file, {
      upsert: true,
      contentType: file.type,
      cacheControl: '3600',
    })

  if (uploadError) throw new Error(uploadError.message)

  const {
    data: { publicUrl },
  } = supabase.storage.from('client-logos').getPublicUrl(path)

  return publicUrl
}

/**
 * Remove o logo de um cliente.
 */
export async function deleteClientLogo(clientId: string): Promise<void> {
  const supabase = await getSupabase()
  const { error } = await supabase.storage
    .from('client-logos')
    .remove([`${clientId}/logo.png`, `${clientId}/logo.jpg`, `${clientId}/logo.webp`])

  if (error) console.warn('deleteClientLogo:', error.message)
}

// ────────────────────────────────────────────────────────────────
// PDFs de Relatórios (bucket privado)
// ────────────────────────────────────────────────────────────────

/**
 * Faz upload do PDF gerado e retorna uma URL assinada válida por 1 hora.
 */
export async function uploadReportPDF(
  reportId: string,
  pdfBlob: Blob
): Promise<string> {
  const supabase = await getSupabase()
  const path = `${reportId}/report.pdf`

  const { error: uploadError } = await supabase.storage
    .from('reports')
    .upload(path, pdfBlob, {
      upsert: true,
      contentType: 'application/pdf',
    })

  if (uploadError) throw new Error(uploadError.message)

  const { data, error: urlError } = await supabase.storage
    .from('reports')
    .createSignedUrl(path, 3600) // válida por 1 hora

  if (urlError) throw new Error(urlError.message)
  return data.signedUrl
}

/**
 * Gera uma nova URL assinada para download de um relatório existente.
 */
export async function getReportDownloadUrl(reportId: string): Promise<string> {
  const supabase = await getSupabase()
  const { data, error } = await supabase.storage
    .from('reports')
    .createSignedUrl(`${reportId}/report.pdf`, 3600)

  if (error) throw new Error(error.message)
  return data.signedUrl
}

/**
 * Salva a URL pública do PDF no registro do relatório.
 */
export async function saveReportPDFUrl(
  reportId: string,
  pdfUrl: string
): Promise<void> {
  const { createClient } = await import('@/lib/supabase/client')
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const supabase = createClient() as any

  const { error } = await supabase
    .from('reports')
    .update({ pdf_url: pdfUrl, status: 'generated' })
    .eq('id', reportId)

  if (error) throw new Error(error.message)
}
