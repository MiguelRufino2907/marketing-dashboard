import type { Database } from '@/types/supabase'

type ClientRow = Database['public']['Tables']['clients']['Row']
type ClientInsert = Database['public']['Tables']['clients']['Insert']
type ClientUpdate = Database['public']['Tables']['clients']['Update']

// ────────────────────────────────────────────────────────────────
// Helpers
// ────────────────────────────────────────────────────────────────
const isConfigured = () =>
  !!process.env.NEXT_PUBLIC_SUPABASE_URL &&
  !process.env.NEXT_PUBLIC_SUPABASE_URL.includes('SEU_PROJECT_ID')

// eslint-disable-next-line @typescript-eslint/no-explicit-any
async function getSupabase(): Promise<any> {
  const { createClient } = await import('@/lib/supabase/client')
  return createClient()
}

// ────────────────────────────────────────────────────────────────
// CRUD
// ────────────────────────────────────────────────────────────────

/** Lista todos os clientes ativos com suas contas vinculadas */
export async function getClients() {
  if (!isConfigured()) {
    const { mockClients } = await import('@/lib/mock-data')
    return mockClients.map((c) => ({
      id: c.id,
      name: c.name,
      trading_name: null,
      logo_url: c.logoUrl ?? null,
      primary_color: '#6366F1',
      contact_name: null,
      contact_email: c.contactEmail,
      contact_phone: c.contactPhone ?? null,
      monthly_budget: null,
      is_active: c.isActive,
      created_by: null,
      created_at: c.createdAt,
      updated_at: c.createdAt,
      ad_accounts: [] as { id: string; platform: string; status: string; last_sync_at: string | null }[],
    }))
  }

  const supabase = await getSupabase()
  const { data, error } = await supabase
    .from('clients')
    .select(`
      *,
      ad_accounts (id, platform, status, last_sync_at)
    `)
    .eq('is_active', true)
    .order('name')

  if (error) throw new Error(error.message)
  return data
}

/** Busca um cliente pelo ID com todas as relações */
export async function getClientById(id: string) {
  if (!isConfigured()) {
    const { mockClients } = await import('@/lib/mock-data')
    const c = mockClients.find((c) => c.id === id)
    if (!c) return null
    return {
      ...c,
      trading_name: null,
      logo_url: c.logoUrl ?? null,
      primary_color: '#6366F1',
      contact_name: null,
      contact_email: c.contactEmail,
      contact_phone: c.contactPhone ?? null,
      monthly_budget: null,
      is_active: c.isActive,
      created_by: null,
      created_at: c.createdAt,
      updated_at: c.createdAt,
      ad_accounts: [],
      reports: [],
    }
  }

  const supabase = await getSupabase()
  const { data, error } = await supabase
    .from('clients')
    .select(`
      *,
      ad_accounts (*),
      reports (id, name, status, created_at, period_start, period_end)
    `)
    .eq('id', id)
    .single()

  if (error) throw new Error(error.message)
  return data
}

/** Cria um novo cliente */
export async function createClientRecord(client: ClientInsert): Promise<ClientRow> {
  const supabase = await getSupabase()
  const { data, error } = await supabase
    .from('clients')
    .insert(client)
    .select()
    .single()

  if (error) throw new Error(error.message)
  return data as ClientRow
}

/** Atualiza dados de um cliente */
export async function updateClientRecord(
  id: string,
  updates: ClientUpdate
): Promise<ClientRow> {
  const supabase = await getSupabase()
  const { data, error } = await supabase
    .from('clients')
    .update(updates)
    .eq('id', id)
    .select()
    .single()

  if (error) throw new Error(error.message)
  return data as ClientRow
}

/** Desativa (soft delete) um cliente */
export async function deactivateClient(id: string): Promise<void> {
  const supabase = await getSupabase()
  const { error } = await supabase
    .from('clients')
    .update({ is_active: false })
    .eq('id', id)

  if (error) throw new Error(error.message)
}
