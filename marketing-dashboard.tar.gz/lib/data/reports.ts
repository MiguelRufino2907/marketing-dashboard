import type { Database } from '@/types/supabase'

type ReportRow = Database['public']['Tables']['reports']['Row']
type ReportInsert = Database['public']['Tables']['reports']['Insert']
type ReportUpdate = Database['public']['Tables']['reports']['Update']

const isConfigured = () =>
  !!process.env.NEXT_PUBLIC_SUPABASE_URL &&
  !process.env.NEXT_PUBLIC_SUPABASE_URL.includes('SEU_PROJECT_ID')

// eslint-disable-next-line @typescript-eslint/no-explicit-any
async function getSupabase(): Promise<any> {
  const { createClient } = await import('@/lib/supabase/client')
  return createClient()
}

// ────────────────────────────────────────────────────────────────
// Listagem
// ────────────────────────────────────────────────────────────────
export async function getReports(clientId?: string) {
  if (!isConfigured()) {
    const { mockReports } = await import('@/lib/mock-data')
    return clientId ? mockReports.filter((r) => r.clientId === clientId) : mockReports
  }

  const supabase = await getSupabase()
  let query = supabase
    .from('reports')
    .select(`
      *,
      clients (name, logo_url)
    `)
    .order('created_at', { ascending: false })

  if (clientId) query = query.eq('client_id', clientId)

  const { data, error } = await query
  if (error) throw new Error(error.message)
  return data
}

/** Busca um relatório pelo ID */
export async function getReportById(id: string) {
  if (!isConfigured()) {
    const { mockReports } = await import('@/lib/mock-data')
    return mockReports.find((r) => r.id === id) ?? null
  }

  const supabase = await getSupabase()
  const { data, error } = await supabase
    .from('reports')
    .select(`*, clients (name, logo_url, primary_color)`)
    .eq('id', id)
    .single()

  if (error) throw new Error(error.message)
  return data
}

/** Cria um novo relatório */
export async function createReport(report: ReportInsert): Promise<ReportRow> {
  const supabase = await getSupabase()
  const { data, error } = await supabase
    .from('reports')
    .insert(report)
    .select()
    .single()

  if (error) throw new Error(error.message)
  return data
}

/** Atualiza status e PDF URL após geração */
export async function updateReport(id: string, updates: ReportUpdate): Promise<ReportRow> {
  const supabase = await getSupabase()
  const { data, error } = await supabase
    .from('reports')
    .update(updates)
    .eq('id', id)
    .select()
    .single()

  if (error) throw new Error(error.message)
  return data
}

/** Marca relatório como enviado */
export async function markReportSent(
  id: string,
  channels: string[]
): Promise<void> {
  const supabase = await getSupabase()
  const { error } = await supabase
    .from('reports')
    .update({
      status: 'sent',
      sent_at: new Date().toISOString(),
      sent_via: channels,
    })
    .eq('id', id)

  if (error) throw new Error(error.message)
}

/** Deleta um relatório */
export async function deleteReport(id: string): Promise<void> {
  const supabase = await getSupabase()
  const { error } = await supabase.from('reports').delete().eq('id', id)
  if (error) throw new Error(error.message)
}
