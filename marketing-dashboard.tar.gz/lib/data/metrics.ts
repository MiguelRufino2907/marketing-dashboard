import { format, subDays } from 'date-fns'

// ────────────────────────────────────────────────────────────────
// Tipos
// ────────────────────────────────────────────────────────────────
export interface MetricsFilter {
  clientId?: string
  dateFrom: string   // 'YYYY-MM-DD'
  dateTo: string
  platform?: 'meta' | 'google' | 'tiktok'
}

export interface KPISummary {
  spend: number
  impressions: number
  reach: number
  clicks: number
  conversions: number
  revenue: number
  ctr: number
  cpc: number
  cpm: number
  cpa: number
  roas: number
}

export interface DailyPoint {
  date: string
  spend: number
  impressions: number
  clicks: number
  conversions: number
  roas: number
  meta?: number
  google?: number
  tiktok?: number
}

export interface CampaignSummary {
  campaign_id: string
  campaign_name: string | null
  platform: string
  status: string
  spend: number
  impressions: number
  clicks: number
  ctr: number
  cpc: number
  cpm: number
  conversions: number
  cpa: number
  roas: number
}

// ────────────────────────────────────────────────────────────────
// Helpers
// ────────────────────────────────────────────────────────────────
const isConfigured = () =>
  typeof window !== 'undefined' &&
  !!process.env.NEXT_PUBLIC_SUPABASE_URL &&
  !process.env.NEXT_PUBLIC_SUPABASE_URL.includes('SEU_PROJECT_ID')

// eslint-disable-next-line @typescript-eslint/no-explicit-any
async function getSupabase(): Promise<any> {
  const { createClient } = await import('@/lib/supabase/client')
  return createClient()
}

// ────────────────────────────────────────────────────────────────
// KPIs Consolidados
// ────────────────────────────────────────────────────────────────
export async function getClientKPIs(filter: MetricsFilter): Promise<KPISummary> {
  if (!isConfigured()) {
    const { mockDailyMetrics, mockCampaigns } = await import('@/lib/mock-data')
    // Usa dados mock agregados
    const campaigns = filter.platform
      ? mockCampaigns.filter((c) => c.platform === filter.platform)
      : mockCampaigns

    const spend = campaigns.reduce((s, c) => s + c.spend, 0)
    const impressions = campaigns.reduce((s, c) => s + c.impressions, 0)
    const clicks = campaigns.reduce((s, c) => s + c.clicks, 0)
    const conversions = campaigns.reduce((s, c) => s + c.conversions, 0)
    const revenue = campaigns.reduce((s, c) => s + c.spend * c.roas, 0)

    return {
      spend,
      impressions,
      reach: Math.round(impressions * 0.82),
      clicks,
      conversions,
      revenue,
      ctr: clicks / impressions * 100,
      cpc: spend / clicks,
      cpm: (spend / impressions) * 1000,
      cpa: spend / conversions,
      roas: revenue / spend,
    }
  }

  const supabase = await getSupabase()

  let query = supabase
    .from('campaign_metrics')
    .select('spend, impressions, reach, clicks, conversions, revenue, roas, ctr, cpc, cpm, cpa, platform')
    .gte('date', filter.dateFrom)
    .lte('date', filter.dateTo)

  if (filter.clientId) query = query.eq('client_id', filter.clientId)
  if (filter.platform) query = query.eq('platform', filter.platform)

  const { data, error } = await query
  if (error) throw new Error(error.message)
  if (!data || data.length === 0) {
    return { spend: 0, impressions: 0, reach: 0, clicks: 0, conversions: 0, revenue: 0, ctr: 0, cpc: 0, cpm: 0, cpa: 0, roas: 0 }
  }

  type Totals = { spend: number; impressions: number; reach: number; clicks: number; conversions: number; revenue: number }
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const totals = (data as any[]).reduce(
    (acc: Totals, row: any): Totals => ({
      spend: acc.spend + (row.spend || 0),
      impressions: acc.impressions + (row.impressions || 0),
      reach: acc.reach + (row.reach || 0),
      clicks: acc.clicks + (row.clicks || 0),
      conversions: acc.conversions + (row.conversions || 0),
      revenue: acc.revenue + (row.revenue || 0),
    }),
    { spend: 0, impressions: 0, reach: 0, clicks: 0, conversions: 0, revenue: 0 }
  ) as Totals

  return {
    ...totals,
    ctr: totals.impressions > 0 ? (totals.clicks / totals.impressions) * 100 : 0,
    cpc: totals.clicks > 0 ? totals.spend / totals.clicks : 0,
    cpm: totals.impressions > 0 ? (totals.spend / totals.impressions) * 1000 : 0,
    cpa: totals.conversions > 0 ? totals.spend / totals.conversions : 0,
    roas: totals.spend > 0 ? totals.revenue / totals.spend : 0,
  }
}

// ────────────────────────────────────────────────────────────────
// Dados Diários para Gráficos
// ────────────────────────────────────────────────────────────────
export async function getDailyMetrics(filter: MetricsFilter): Promise<DailyPoint[]> {
  if (!isConfigured()) {
    const { mockDailyMetrics } = await import('@/lib/mock-data')
    return mockDailyMetrics.map((d) => ({
      date: d.date,
      spend: d.spend,
      impressions: d.impressions,
      clicks: d.clicks,
      conversions: d.conversions,
      roas: d.roas,
      meta: d.meta,
      google: d.google,
      tiktok: d.tiktok,
    }))
  }

  const supabase = await getSupabase()

  let query = supabase
    .from('campaign_metrics')
    .select('date, spend, clicks, conversions, impressions, platform, roas')
    .gte('date', filter.dateFrom)
    .lte('date', filter.dateTo)
    .order('date')

  if (filter.clientId) query = query.eq('client_id', filter.clientId)
  if (filter.platform) query = query.eq('platform', filter.platform)

  const { data, error } = await query
  if (error) throw new Error(error.message)

  // Agrupa por data
  const byDate = new Map<string, DailyPoint>()
  for (const row of data ?? []) {
    const existing = byDate.get(row.date) ?? {
      date: row.date,
      spend: 0,
      impressions: 0,
      clicks: 0,
      conversions: 0,
      roas: 0,
      meta: 0,
      google: 0,
      tiktok: 0,
    }
    existing.spend += row.spend || 0
    existing.impressions += row.impressions || 0
    existing.clicks += row.clicks || 0
    existing.conversions += row.conversions || 0

    if (row.platform === 'meta') existing.meta = (existing.meta ?? 0) + (row.spend || 0)
    if (row.platform === 'google') existing.google = (existing.google ?? 0) + (row.spend || 0)
    if (row.platform === 'tiktok') existing.tiktok = (existing.tiktok ?? 0) + (row.spend || 0)

    byDate.set(row.date, existing)
  }

  return Array.from(byDate.values()).sort((a, b) => a.date.localeCompare(b.date))
}

// ────────────────────────────────────────────────────────────────
// Lista de Campanhas
// ────────────────────────────────────────────────────────────────
export async function getCampaigns(filter: MetricsFilter): Promise<CampaignSummary[]> {
  if (!isConfigured()) {
    const { mockCampaigns } = await import('@/lib/mock-data')
    const campaigns = filter.platform
      ? mockCampaigns.filter((c) => c.platform === filter.platform)
      : mockCampaigns
    return campaigns.map((c) => ({
      campaign_id: c.campaignId,
      campaign_name: c.campaignName,
      platform: c.platform,
      status: c.status,
      spend: c.spend,
      impressions: c.impressions,
      clicks: c.clicks,
      ctr: c.ctr,
      cpc: c.cpc,
      cpm: c.cpm,
      conversions: c.conversions,
      cpa: c.cpa,
      roas: c.roas,
    }))
  }

  const supabase = await getSupabase()

  let query = supabase
    .from('campaign_metrics')
    .select(
      'campaign_id, campaign_name, platform, status, spend, impressions, clicks, ctr, cpc, cpm, conversions, cpa, roas'
    )
    .gte('date', filter.dateFrom)
    .lte('date', filter.dateTo)

  if (filter.clientId) query = query.eq('client_id', filter.clientId)
  if (filter.platform) query = query.eq('platform', filter.platform)

  const { data, error } = await query
  if (error) throw new Error(error.message)

  // Agrupa por campaign_id
  const grouped = new Map<string, CampaignSummary>()
  for (const row of data ?? []) {
    const existing = grouped.get(row.campaign_id)
    if (!existing) {
      grouped.set(row.campaign_id, {
        campaign_id: row.campaign_id,
        campaign_name: row.campaign_name,
        platform: row.platform,
        status: row.status,
        spend: row.spend || 0,
        impressions: row.impressions || 0,
        clicks: row.clicks || 0,
        ctr: row.ctr || 0,
        cpc: row.cpc || 0,
        cpm: row.cpm || 0,
        conversions: row.conversions || 0,
        cpa: row.cpa || 0,
        roas: row.roas || 0,
      })
    } else {
      existing.spend += row.spend || 0
      existing.impressions += row.impressions || 0
      existing.clicks += row.clicks || 0
      existing.conversions += row.conversions || 0
    }
  }

  // Recalcula métricas derivadas
  const result = Array.from(grouped.values()).map((c) => ({
    ...c,
    ctr: c.impressions > 0 ? (c.clicks / c.impressions) * 100 : 0,
    cpc: c.clicks > 0 ? c.spend / c.clicks : 0,
    cpm: c.impressions > 0 ? (c.spend / c.impressions) * 1000 : 0,
    cpa: c.conversions > 0 ? c.spend / c.conversions : 0,
  }))

  return result.sort((a, b) => b.spend - a.spend)
}

// ────────────────────────────────────────────────────────────────
// Breakdown por Plataforma
// ────────────────────────────────────────────────────────────────
export interface PlatformBreakdownItem {
  platform: string
  spend: number
  pct: number
  color: string
}

export async function getPlatformBreakdown(filter: Omit<MetricsFilter, 'platform'>): Promise<PlatformBreakdownItem[]> {
  if (!isConfigured()) {
    const { platformBreakdown } = await import('@/lib/mock-data')
    const total = platformBreakdown.reduce((s, p) => s + p.spend, 0)
    return platformBreakdown.map((p) => ({
      platform: (p as any).name?.replace(' Ads', '') ?? p.platform,
      spend: p.spend,
      pct: total > 0 ? (p.spend / total) * 100 : 0,
      color: p.color,
    }))
  }

  const supabase = await getSupabase()

  let query = supabase
    .from('campaign_metrics')
    .select('platform, spend')
    .gte('date', filter.dateFrom)
    .lte('date', filter.dateTo)

  if (filter.clientId) query = query.eq('client_id', filter.clientId)

  const { data, error } = await query
  if (error) throw new Error(error.message)

  const totals: Record<string, number> = { meta: 0, google: 0, tiktok: 0 }
  for (const row of data ?? []) {
    totals[row.platform] = (totals[row.platform] || 0) + (row.spend || 0)
  }

  const total = Object.values(totals).reduce((a, b) => a + b, 0)

  return [
    { platform: 'Meta', spend: totals.meta, pct: total > 0 ? (totals.meta / total) * 100 : 0, color: '#1877F2' },
    { platform: 'Google', spend: totals.google, pct: total > 0 ? (totals.google / total) * 100 : 0, color: '#4285F4' },
    { platform: 'TikTok', spend: totals.tiktok, pct: total > 0 ? (totals.tiktok / total) * 100 : 0, color: '#FF0050' },
  ]
}
