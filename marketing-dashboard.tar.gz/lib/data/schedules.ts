import type { Database } from '@/types/supabase'

type ScheduleRow = Database['public']['Tables']['schedules']['Row']
type ScheduleInsert = Database['public']['Tables']['schedules']['Insert']
type ScheduleUpdate = Database['public']['Tables']['schedules']['Update']

const isConfigured = () =>
  !!process.env.NEXT_PUBLIC_SUPABASE_URL &&
  !process.env.NEXT_PUBLIC_SUPABASE_URL.includes('SEU_PROJECT_ID')

// eslint-disable-next-line @typescript-eslint/no-explicit-any
async function getSupabase(): Promise<any> {
  const { createClient } = await import('@/lib/supabase/client')
  return createClient()
}

// ────────────────────────────────────────────────────────────────
// Listagem
// ────────────────────────────────────────────────────────────────
export async function getSchedules(clientId?: string) {
  if (!isConfigured()) {
    const { mockSchedules } = await import('@/lib/mock-data')
    // Mock schedules don't have clientId — return all
    return mockSchedules
  }

  const supabase = await getSupabase()
  let query = supabase
    .from('schedules')
    .select(`*, clients (name)`)
    .order('created_at', { ascending: false })

  if (clientId) query = query.eq('client_id', clientId)

  const { data, error } = await query
  if (error) throw new Error(error.message)
  return data
}

/** Cria um agendamento */
export async function createSchedule(schedule: ScheduleInsert): Promise<ScheduleRow> {
  const supabase = await getSupabase()
  const { data, error } = await supabase
    .from('schedules')
    .insert(schedule)
    .select()
    .single()

  if (error) throw new Error(error.message)
  return data
}

/** Atualiza um agendamento */
export async function updateSchedule(
  id: string,
  updates: ScheduleUpdate
): Promise<ScheduleRow> {
  const supabase = await getSupabase()
  const { data, error } = await supabase
    .from('schedules')
    .update(updates)
    .eq('id', id)
    .select()
    .single()

  if (error) throw new Error(error.message)
  return data
}

/** Liga/desliga um agendamento */
export async function toggleSchedule(id: string, isActive: boolean): Promise<void> {
  const supabase = await getSupabase()
  const { error } = await supabase
    .from('schedules')
    .update({ is_active: isActive })
    .eq('id', id)

  if (error) throw new Error(error.message)
}

/** Deleta um agendamento */
export async function deleteSchedule(id: string): Promise<void> {
  const supabase = await getSupabase()
  const { error } = await supabase.from('schedules').delete().eq('id', id)
  if (error) throw new Error(error.message)
}
