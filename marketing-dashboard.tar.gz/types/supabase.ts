export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      clients: {
        Row: {
          id: string
          name: string
          trading_name: string | null
          logo_url: string | null
          primary_color: string
          contact_name: string | null
          contact_email: string | null
          contact_phone: string | null
          monthly_budget: number | null
          is_active: boolean
          created_by: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          name: string
          trading_name?: string | null
          logo_url?: string | null
          primary_color?: string
          contact_name?: string | null
          contact_email?: string | null
          contact_phone?: string | null
          monthly_budget?: number | null
          is_active?: boolean
          created_by?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          name?: string
          trading_name?: string | null
          logo_url?: string | null
          primary_color?: string
          contact_name?: string | null
          contact_email?: string | null
          contact_phone?: string | null
          monthly_budget?: number | null
          is_active?: boolean
          created_by?: string | null
          updated_at?: string
        }
      }
      ad_accounts: {
        Row: {
          id: string
          client_id: string
          platform: 'meta' | 'google' | 'tiktok'
          external_account_id: string
          account_name: string | null
          currency: string
          timezone: string
          access_token: string | null
          refresh_token: string | null
          token_expires_at: string | null
          status: 'connected' | 'expired' | 'error' | 'disconnected'
          last_sync_at: string | null
          created_at: string
        }
        Insert: {
          id?: string
          client_id: string
          platform: 'meta' | 'google' | 'tiktok'
          external_account_id: string
          account_name?: string | null
          currency?: string
          timezone?: string
          access_token?: string | null
          refresh_token?: string | null
          token_expires_at?: string | null
          status?: 'connected' | 'expired' | 'error' | 'disconnected'
          last_sync_at?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          client_id?: string
          platform?: 'meta' | 'google' | 'tiktok'
          external_account_id?: string
          account_name?: string | null
          currency?: string
          timezone?: string
          access_token?: string | null
          refresh_token?: string | null
          token_expires_at?: string | null
          status?: 'connected' | 'expired' | 'error' | 'disconnected'
          last_sync_at?: string | null
        }
      }
      campaign_metrics: {
        Row: {
          id: string
          ad_account_id: string
          campaign_id: string
          campaign_name: string | null
          platform: string
          client_id: string
          status: string
          date: string
          impressions: number
          reach: number
          clicks: number
          spend: number
          ctr: number
          cpc: number
          cpm: number
          conversions: number
          cpa: number
          revenue: number
          roas: number
          synced_at: string
        }
        Insert: {
          id?: string
          ad_account_id: string
          campaign_id: string
          campaign_name?: string | null
          platform: string
          client_id: string
          status?: string
          date: string
          impressions?: number
          reach?: number
          clicks?: number
          spend?: number
          ctr?: number
          cpc?: number
          cpm?: number
          conversions?: number
          cpa?: number
          revenue?: number
          roas?: number
          synced_at?: string
        }
        Update: {
          id?: string
          ad_account_id?: string
          campaign_id?: string
          campaign_name?: string | null
          platform?: string
          client_id?: string
          status?: string
          date?: string
          impressions?: number
          reach?: number
          clicks?: number
          spend?: number
          ctr?: number
          cpc?: number
          cpm?: number
          conversions?: number
          cpa?: number
          revenue?: number
          roas?: number
          synced_at?: string
        }
      }
      reports: {
        Row: {
          id: string
          client_id: string
          name: string
          period_start: string
          period_end: string
          platforms: string[]
          sections: string[]
          pdf_url: string | null
          status: 'draft' | 'generating' | 'generated' | 'sent' | 'failed'
          sent_via: string[]
          sent_at: string | null
          recipients: Json
          custom_notes: string | null
          created_by: string | null
          created_at: string
        }
        Insert: {
          id?: string
          client_id: string
          name: string
          period_start: string
          period_end: string
          platforms?: string[]
          sections?: string[]
          pdf_url?: string | null
          status?: 'draft' | 'generating' | 'generated' | 'sent' | 'failed'
          sent_via?: string[]
          sent_at?: string | null
          recipients?: Json
          custom_notes?: string | null
          created_by?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          client_id?: string
          name?: string
          period_start?: string
          period_end?: string
          platforms?: string[]
          sections?: string[]
          pdf_url?: string | null
          status?: 'draft' | 'generating' | 'generated' | 'sent' | 'failed'
          sent_via?: string[]
          sent_at?: string | null
          recipients?: Json
          custom_notes?: string | null
        }
      }
      schedules: {
        Row: {
          id: string
          client_id: string
          name: string
          frequency: 'daily' | 'weekly' | 'biweekly' | 'monthly'
          day_of_week: number | null
          day_of_month: number | null
          send_time: string
          timezone: string
          platforms: string[]
          channels: string[]
          email_recipients: string[]
          whatsapp_numbers: string[]
          email_subject: string | null
          email_message: string | null
          whatsapp_message: string | null
          is_active: boolean
          last_sent_at: string | null
          next_scheduled_at: string | null
          created_by: string | null
          created_at: string
        }
        Insert: {
          id?: string
          client_id: string
          name: string
          frequency: 'daily' | 'weekly' | 'biweekly' | 'monthly'
          day_of_week?: number | null
          day_of_month?: number | null
          send_time?: string
          timezone?: string
          platforms?: string[]
          channels?: string[]
          email_recipients?: string[]
          whatsapp_numbers?: string[]
          email_subject?: string | null
          email_message?: string | null
          whatsapp_message?: string | null
          is_active?: boolean
          last_sent_at?: string | null
          next_scheduled_at?: string | null
          created_by?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          client_id?: string
          name?: string
          frequency?: 'daily' | 'weekly' | 'biweekly' | 'monthly'
          day_of_week?: number | null
          day_of_month?: number | null
          send_time?: string
          timezone?: string
          platforms?: string[]
          channels?: string[]
          email_recipients?: string[]
          whatsapp_numbers?: string[]
          email_subject?: string | null
          email_message?: string | null
          whatsapp_message?: string | null
          is_active?: boolean
          last_sent_at?: string | null
          next_scheduled_at?: string | null
        }
      }
      campaign_alerts: {
        Row: {
          id: string
          ad_account_id: string
          client_id: string
          campaign_id: string | null
          metric: 'cpa' | 'roas' | 'ctr' | 'spend' | 'budget_pct'
          operator: 'greater_than' | 'less_than'
          threshold: number
          action: 'notify_only' | 'notify_and_pause'
          notify_email: boolean
          notify_whatsapp: boolean
          recipients: string[]
          is_active: boolean
          last_triggered_at: string | null
          created_at: string
        }
        Insert: {
          id?: string
          ad_account_id: string
          client_id: string
          campaign_id?: string | null
          metric: 'cpa' | 'roas' | 'ctr' | 'spend' | 'budget_pct'
          operator: 'greater_than' | 'less_than'
          threshold: number
          action: 'notify_only' | 'notify_and_pause'
          notify_email?: boolean
          notify_whatsapp?: boolean
          recipients?: string[]
          is_active?: boolean
          last_triggered_at?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          metric?: 'cpa' | 'roas' | 'ctr' | 'spend' | 'budget_pct'
          operator?: 'greater_than' | 'less_than'
          threshold?: number
          action?: 'notify_only' | 'notify_and_pause'
          notify_email?: boolean
          notify_whatsapp?: boolean
          recipients?: string[]
          is_active?: boolean
          last_triggered_at?: string | null
        }
      }
      profiles: {
        Row: {
          id: string
          full_name: string | null
          avatar_url: string | null
          role: 'admin' | 'analyst' | 'viewer' | 'client'
          client_id: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id: string
          full_name?: string | null
          avatar_url?: string | null
          role?: 'admin' | 'analyst' | 'viewer' | 'client'
          client_id?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          full_name?: string | null
          avatar_url?: string | null
          role?: 'admin' | 'analyst' | 'viewer' | 'client'
          client_id?: string | null
          updated_at?: string
        }
      }
    }
    Views: Record<string, never>
    Functions: Record<string, never>
    Enums: Record<string, never>
  }
}
