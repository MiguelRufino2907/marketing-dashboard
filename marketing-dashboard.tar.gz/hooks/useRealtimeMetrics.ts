'use client'

import { useEffect } from 'react'

interface Options {
  clientId: string
  /** Callback disparado quando novos dados chegam — use para re-fetchear */
  onNewData: () => void
}

const isConfigured = () =>
  typeof window !== 'undefined' &&
  !!process.env.NEXT_PUBLIC_SUPABASE_URL &&
  !process.env.NEXT_PUBLIC_SUPABASE_URL.includes('SEU_PROJECT_ID')

/**
 * Hook que assina mudanças em tempo real nas tabelas
 * `campaign_metrics` e `ad_accounts` para o clientId informado.
 *
 * Requer que o Realtime esteja habilitado no Supabase:
 *   Database → Replication → Selecione campaign_metrics e ad_accounts
 */
export function useRealtimeMetrics({ clientId, onNewData }: Options) {
  useEffect(() => {
    if (!isConfigured() || !clientId) return

    let mounted = true

    const init = async () => {
      const { createClient } = await import('@/lib/supabase/client')
      const supabase = createClient()

      const channel = supabase
        .channel(`metrics:${clientId}`)
        // Novas métricas sincronizadas
        .on(
          'postgres_changes',
          {
            event: 'INSERT',
            schema: 'public',
            table: 'campaign_metrics',
            filter: `client_id=eq.${clientId}`,
          },
          () => {
            if (mounted) onNewData()
          }
        )
        // Atualização de métricas existentes
        .on(
          'postgres_changes',
          {
            event: 'UPDATE',
            schema: 'public',
            table: 'campaign_metrics',
            filter: `client_id=eq.${clientId}`,
          },
          () => {
            if (mounted) onNewData()
          }
        )
        // Status das contas de anúncios
        .on(
          'postgres_changes',
          {
            event: 'UPDATE',
            schema: 'public',
            table: 'ad_accounts',
            filter: `client_id=eq.${clientId}`,
          },
          () => {
            if (mounted) onNewData()
          }
        )
        .subscribe()

      return () => {
        supabase.removeChannel(channel)
      }
    }

    const cleanup = init()
    return () => {
      mounted = false
      cleanup.then((fn) => fn?.())
    }
  }, [clientId, onNewData])
}
