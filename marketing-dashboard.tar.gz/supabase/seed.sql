-- ============================================================
-- ADSPULSE — Seed de Dados para Teste
-- Execute APÓS schema.sql e rls.sql
-- ============================================================

-- ── Passo 1: crie o usuário admin no Supabase Dashboard ────
-- Authentication → Users → Add user
--   E-mail: admin@agencia.com
--   Senha: Admin@123456
--
-- Após criar, copie o UUID gerado e substitua abaixo:
-- UPDATE public.profiles SET role = 'admin' WHERE id = 'SEU_UUID_AQUI';
-- ────────────────────────────────────────────────────────────

-- ── Clientes ────────────────────────────────────────────────
INSERT INTO public.clients
  (name, trading_name, contact_email, contact_phone, monthly_budget, primary_color)
VALUES
  ('Elegance Moda Feminina',  'Elegance',   'mkt@elegance.com.br',   '5541999990001', 15000, '#EC4899'),
  ('TechHome Eletrônicos',    'TechHome',   'ads@techhome.com.br',   '5541999990002', 28000, '#3B82F6'),
  ('Clínica Derma Bella',     'DermaBella', 'mkt@dermabella.com.br', '5541999990003',  8000, '#10B981')
ON CONFLICT DO NOTHING;

-- ── Contas de Anúncios ──────────────────────────────────────
INSERT INTO public.ad_accounts (client_id, platform, external_account_id, account_name, status)
SELECT id, 'meta',    'act_111111111', 'Elegance - Meta Ads',    'connected' FROM public.clients WHERE name = 'Elegance Moda Feminina'
ON CONFLICT DO NOTHING;

INSERT INTO public.ad_accounts (client_id, platform, external_account_id, account_name, status)
SELECT id, 'google',  '111-222-3333',  'Elegance - Google Ads',  'connected' FROM public.clients WHERE name = 'Elegance Moda Feminina'
ON CONFLICT DO NOTHING;

INSERT INTO public.ad_accounts (client_id, platform, external_account_id, account_name, status)
SELECT id, 'tiktok',  'tt_111111111',  'Elegance - TikTok Ads',  'connected' FROM public.clients WHERE name = 'Elegance Moda Feminina'
ON CONFLICT DO NOTHING;

INSERT INTO public.ad_accounts (client_id, platform, external_account_id, account_name, status)
SELECT id, 'meta',    'act_222222222', 'TechHome - Meta Ads',    'connected' FROM public.clients WHERE name = 'TechHome Eletrônicos'
ON CONFLICT DO NOTHING;

INSERT INTO public.ad_accounts (client_id, platform, external_account_id, account_name, status)
SELECT id, 'google',  '444-555-6666',  'TechHome - Google Ads',  'connected' FROM public.clients WHERE name = 'TechHome Eletrônicos'
ON CONFLICT DO NOTHING;

INSERT INTO public.ad_accounts (client_id, platform, external_account_id, account_name, status)
SELECT id, 'meta',    'act_333333333', 'DermaBella - Meta Ads',  'expired'   FROM public.clients WHERE name = 'Clínica Derma Bella'
ON CONFLICT DO NOTHING;

-- ── Métricas (últimos 30 dias) para Elegance Moda ──────────
DO $$
DECLARE
  v_client_id  UUID;
  v_account_meta UUID;
  v_account_google UUID;
  v_account_tiktok UUID;
  v_date DATE;
  i INT;
BEGIN
  SELECT id INTO v_client_id   FROM public.clients     WHERE name = 'Elegance Moda Feminina';
  SELECT id INTO v_account_meta   FROM public.ad_accounts WHERE client_id = v_client_id AND platform = 'meta';
  SELECT id INTO v_account_google FROM public.ad_accounts WHERE client_id = v_client_id AND platform = 'google';
  SELECT id INTO v_account_tiktok FROM public.ad_accounts WHERE client_id = v_client_id AND platform = 'tiktok';

  FOR i IN 0..29 LOOP
    v_date := CURRENT_DATE - i;

    -- Meta: campanha de conversão
    INSERT INTO public.campaign_metrics
      (ad_account_id, campaign_id, campaign_name, platform, client_id, status, date,
       impressions, reach, clicks, spend, ctr, cpc, cpm, conversions, cpa, revenue, roas)
    VALUES (
      v_account_meta, 'meta_camp_001', 'Coleção Verão - Conversão', 'meta', v_client_id, 'active', v_date,
      (18000 + (random()*9000)::int),
      (14000 + (random()*7000)::int),
      (430   + (random()*220)::int),
      round((300  + random()*150)::numeric, 2),
      round((2.2  + random()*1.8)::numeric, 4),
      round((0.55 + random()*0.35)::numeric, 4),
      round((16   + random()*8)::numeric, 4),
      (14    + (random()*18)::int),
      round((22   + random()*14)::numeric, 2),
      round(((300 + random()*150) * (3.5 + random()*2))::numeric, 2),
      round((3.5  + random()*2.5)::numeric, 4)
    ) ON CONFLICT (ad_account_id, campaign_id, date) DO NOTHING;

    -- Meta: campanha de awareness
    INSERT INTO public.campaign_metrics
      (ad_account_id, campaign_id, campaign_name, platform, client_id, status, date,
       impressions, reach, clicks, spend, ctr, cpc, cpm, conversions, cpa, revenue, roas)
    VALUES (
      v_account_meta, 'meta_camp_002', 'Brand Awareness Q1', 'meta', v_client_id, 'active', v_date,
      (45000 + (random()*20000)::int),
      (38000 + (random()*16000)::int),
      (320   + (random()*150)::int),
      round((150  + random()*80)::numeric, 2),
      round((0.7  + random()*0.5)::numeric, 4),
      round((0.45 + random()*0.25)::numeric, 4),
      round((3.3  + random()*2)::numeric, 4),
      (4     + (random()*8)::int),
      round((35   + random()*20)::numeric, 2),
      round(((150 + random()*80) * (1.8 + random()))::numeric, 2),
      round((1.8  + random())::numeric, 4)
    ) ON CONFLICT (ad_account_id, campaign_id, date) DO NOTHING;

    -- Google: search
    INSERT INTO public.campaign_metrics
      (ad_account_id, campaign_id, campaign_name, platform, client_id, status, date,
       impressions, reach, clicks, spend, ctr, cpc, cpm, conversions, cpa, revenue, roas)
    VALUES (
      v_account_google, 'google_camp_001', 'Search - Marca + Concorrentes', 'google', v_client_id, 'active', v_date,
      (5000  + (random()*3000)::int),
      (5000  + (random()*3000)::int),
      (480   + (random()*200)::int),
      round((280  + random()*130)::numeric, 2),
      round((8.5  + random()*3)::numeric, 4),
      round((0.58 + random()*0.3)::numeric, 4),
      round((54   + random()*20)::numeric, 4),
      (22    + (random()*18)::int),
      round((13   + random()*8)::numeric, 2),
      round(((280 + random()*130) * (6 + random()*3))::numeric, 2),
      round((6    + random()*3)::numeric, 4)
    ) ON CONFLICT (ad_account_id, campaign_id, date) DO NOTHING;

    -- TikTok: UGC
    INSERT INTO public.campaign_metrics
      (ad_account_id, campaign_id, campaign_name, platform, client_id, status, date,
       impressions, reach, clicks, spend, ctr, cpc, cpm, conversions, cpa, revenue, roas)
    VALUES (
      v_account_tiktok, 'tiktok_camp_001', 'UGC Creators - Awareness', 'tiktok', v_client_id, 'active', v_date,
      (42000 + (random()*20000)::int),
      (35000 + (random()*16000)::int),
      (295   + (random()*150)::int),
      round((170  + random()*90)::numeric, 2),
      round((0.65 + random()*0.45)::numeric, 4),
      round((0.55 + random()*0.3)::numeric, 4),
      round((3.9  + random()*2)::numeric, 4),
      (3     + (random()*8)::int),
      round((55   + random()*30)::numeric, 2),
      round(((170 + random()*90) * (2 + random()))::numeric, 2),
      round((2    + random())::numeric, 4)
    ) ON CONFLICT (ad_account_id, campaign_id, date) DO NOTHING;

  END LOOP;
END $$;

-- ── Métricas para TechHome (últimos 15 dias) ───────────────
DO $$
DECLARE
  v_client_id  UUID;
  v_account_meta UUID;
  v_account_google UUID;
  v_date DATE;
  i INT;
BEGIN
  SELECT id INTO v_client_id FROM public.clients WHERE name = 'TechHome Eletrônicos';
  SELECT id INTO v_account_meta   FROM public.ad_accounts WHERE client_id = v_client_id AND platform = 'meta';
  SELECT id INTO v_account_google FROM public.ad_accounts WHERE client_id = v_client_id AND platform = 'google';

  FOR i IN 0..14 LOOP
    v_date := CURRENT_DATE - i;

    INSERT INTO public.campaign_metrics
      (ad_account_id, campaign_id, campaign_name, platform, client_id, status, date,
       impressions, reach, clicks, spend, ctr, cpc, cpm, conversions, cpa, revenue, roas)
    VALUES (
      v_account_meta, 'tech_meta_001', 'Smart TVs - Black Friday', 'meta', v_client_id, 'active', v_date,
      (32000 + (random()*15000)::int),
      (26000 + (random()*12000)::int),
      (650   + (random()*300)::int),
      round((520  + random()*250)::numeric, 2),
      round((1.9  + random()*1.2)::numeric, 4),
      round((0.78 + random()*0.4)::numeric, 4),
      round((16   + random()*7)::numeric, 4),
      (28    + (random()*22)::int),
      round((18   + random()*12)::numeric, 2),
      round(((520 + random()*250) * (5 + random()*3))::numeric, 2),
      round((5    + random()*3)::numeric, 4)
    ) ON CONFLICT (ad_account_id, campaign_id, date) DO NOTHING;

    INSERT INTO public.campaign_metrics
      (ad_account_id, campaign_id, campaign_name, platform, client_id, status, date,
       impressions, reach, clicks, spend, ctr, cpc, cpm, conversions, cpa, revenue, roas)
    VALUES (
      v_account_google, 'tech_google_001', 'Shopping - Celulares', 'google', v_client_id, 'active', v_date,
      (8000  + (random()*4000)::int),
      (8000  + (random()*4000)::int),
      (820   + (random()*350)::int),
      round((680  + random()*320)::numeric, 2),
      round((9.2  + random()*3.5)::numeric, 4),
      round((0.82 + random()*0.4)::numeric, 4),
      round((80   + random()*30)::numeric, 4),
      (45    + (random()*30)::int),
      round((15   + random()*10)::numeric, 2),
      round(((680 + random()*320) * (7 + random()*4))::numeric, 2),
      round((7    + random()*4)::numeric, 4)
    ) ON CONFLICT (ad_account_id, campaign_id, date) DO NOTHING;

  END LOOP;
END $$;
