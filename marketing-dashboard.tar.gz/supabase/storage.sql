-- ============================================================
-- ADSPULSE — Storage Buckets & Policies
-- Execute APÓS o schema.sql
-- ============================================================

-- Bucket público para logos de clientes
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'client-logos',
  'client-logos',
  true,
  5242880, -- 5 MB
  ARRAY['image/jpeg','image/jpg','image/png','image/webp','image/svg+xml']
)
ON CONFLICT (id) DO NOTHING;

-- Bucket privado para PDFs de relatórios
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'reports',
  'reports',
  false,
  52428800, -- 50 MB
  ARRAY['application/pdf']
)
ON CONFLICT (id) DO NOTHING;

-- ────────────────────────────────────────────────────────────
-- Policies: client-logos (público)
-- ────────────────────────────────────────────────────────────
DROP POLICY IF EXISTS "logos_read_public" ON storage.objects;
CREATE POLICY "logos_read_public" ON storage.objects FOR SELECT
  TO public
  USING (bucket_id = 'client-logos');

DROP POLICY IF EXISTS "logos_upload_auth" ON storage.objects;
CREATE POLICY "logos_upload_auth" ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (bucket_id = 'client-logos');

DROP POLICY IF EXISTS "logos_update_auth" ON storage.objects;
CREATE POLICY "logos_update_auth" ON storage.objects FOR UPDATE
  TO authenticated
  USING (bucket_id = 'client-logos');

DROP POLICY IF EXISTS "logos_delete_auth" ON storage.objects;
CREATE POLICY "logos_delete_auth" ON storage.objects FOR DELETE
  TO authenticated
  USING (bucket_id = 'client-logos');

-- ────────────────────────────────────────────────────────────
-- Policies: reports (privado — só autenticados)
-- ────────────────────────────────────────────────────────────
DROP POLICY IF EXISTS "reports_read_auth" ON storage.objects;
CREATE POLICY "reports_read_auth" ON storage.objects FOR SELECT
  TO authenticated
  USING (bucket_id = 'reports');

DROP POLICY IF EXISTS "reports_upload_auth" ON storage.objects;
CREATE POLICY "reports_upload_auth" ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (bucket_id = 'reports');

DROP POLICY IF EXISTS "reports_update_auth" ON storage.objects;
CREATE POLICY "reports_update_auth" ON storage.objects FOR UPDATE
  TO authenticated
  USING (bucket_id = 'reports');

DROP POLICY IF EXISTS "reports_delete_auth" ON storage.objects;
CREATE POLICY "reports_delete_auth" ON storage.objects FOR DELETE
  TO authenticated
  USING (bucket_id = 'reports');
