-- ============================================================
-- ADSPULSE — Schema Completo do Supabase
-- Execute este arquivo inteiro no SQL Editor do Supabase
-- Dashboard → SQL Editor → New query → Cole e execute
-- ============================================================

-- ============================================================
-- EXTENSIONS
-- ============================================================
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================================
-- TABELA: clients
-- ============================================================
CREATE TABLE IF NOT EXISTS public.clients (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name          TEXT NOT NULL,
  trading_name  TEXT,
  logo_url      TEXT,
  primary_color TEXT DEFAULT '#6366F1',
  contact_name  TEXT,
  contact_email TEXT,
  contact_phone TEXT,
  monthly_budget DECIMAL(12,2),
  is_active     BOOLEAN DEFAULT true,
  created_by    UUID REFERENCES auth.users(id),
  created_at    TIMESTAMPTZ DEFAULT NOW(),
  updated_at    TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- TABELA: ad_accounts
-- ============================================================
CREATE TABLE IF NOT EXISTS public.ad_accounts (
  id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id             UUID NOT NULL REFERENCES public.clients(id) ON DELETE CASCADE,
  platform              TEXT NOT NULL CHECK (platform IN ('meta', 'google', 'tiktok')),
  external_account_id   TEXT NOT NULL,
  account_name          TEXT,
  currency              TEXT DEFAULT 'BRL',
  timezone              TEXT DEFAULT 'America/Sao_Paulo',
  access_token          TEXT,
  refresh_token         TEXT,
  token_expires_at      TIMESTAMPTZ,
  status                TEXT DEFAULT 'connected'
                          CHECK (status IN ('connected','expired','error','disconnected')),
  last_sync_at          TIMESTAMPTZ,
  created_at            TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(client_id, platform, external_account_id)
);

-- ============================================================
-- TABELA: campaign_metrics
-- ============================================================
CREATE TABLE IF NOT EXISTS public.campaign_metrics (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  ad_account_id   UUID NOT NULL REFERENCES public.ad_accounts(id) ON DELETE CASCADE,
  campaign_id     TEXT NOT NULL,
  campaign_name   TEXT,
  platform        TEXT NOT NULL,
  client_id       UUID NOT NULL REFERENCES public.clients(id),
  status          TEXT DEFAULT 'active',
  date            DATE NOT NULL,
  impressions     BIGINT DEFAULT 0,
  reach           BIGINT DEFAULT 0,
  clicks          BIGINT DEFAULT 0,
  spend           DECIMAL(12,2) DEFAULT 0,
  ctr             DECIMAL(8,4) DEFAULT 0,
  cpc             DECIMAL(8,4) DEFAULT 0,
  cpm             DECIMAL(8,4) DEFAULT 0,
  conversions     INTEGER DEFAULT 0,
  cpa             DECIMAL(10,2) DEFAULT 0,
  revenue         DECIMAL(12,2) DEFAULT 0,
  roas            DECIMAL(8,4) DEFAULT 0,
  synced_at       TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(ad_account_id, campaign_id, date)
);

CREATE INDEX IF NOT EXISTS idx_campaign_metrics_client_date
  ON public.campaign_metrics(client_id, date DESC);
CREATE INDEX IF NOT EXISTS idx_campaign_metrics_platform
  ON public.campaign_metrics(platform, date DESC);

-- ============================================================
-- TABELA: reports
-- ============================================================
CREATE TABLE IF NOT EXISTS public.reports (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id     UUID NOT NULL REFERENCES public.clients(id) ON DELETE CASCADE,
  name          TEXT NOT NULL,
  period_start  DATE NOT NULL,
  period_end    DATE NOT NULL,
  platforms     TEXT[] DEFAULT '{}',
  sections      TEXT[] DEFAULT '{}',
  pdf_url       TEXT,
  status        TEXT DEFAULT 'draft'
                  CHECK (status IN ('draft','generating','generated','sent','failed')),
  sent_via      TEXT[] DEFAULT '{}',
  sent_at       TIMESTAMPTZ,
  recipients    JSONB DEFAULT '{}',
  custom_notes  TEXT,
  created_by    UUID REFERENCES auth.users(id),
  created_at    TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- TABELA: schedules
-- ============================================================
CREATE TABLE IF NOT EXISTS public.schedules (
  id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id           UUID NOT NULL REFERENCES public.clients(id) ON DELETE CASCADE,
  name                TEXT NOT NULL,
  frequency           TEXT NOT NULL
                        CHECK (frequency IN ('daily','weekly','biweekly','monthly')),
  day_of_week         INTEGER CHECK (day_of_week BETWEEN 1 AND 7),
  day_of_month        INTEGER CHECK (day_of_month BETWEEN 1 AND 28),
  send_time           TEXT NOT NULL DEFAULT '09:00',
  timezone            TEXT NOT NULL DEFAULT 'America/Sao_Paulo',
  platforms           TEXT[] DEFAULT '{}',
  channels            TEXT[] DEFAULT '{}',
  email_recipients    TEXT[] DEFAULT '{}',
  whatsapp_numbers    TEXT[] DEFAULT '{}',
  email_subject       TEXT,
  email_message       TEXT,
  whatsapp_message    TEXT,
  is_active           BOOLEAN DEFAULT true,
  last_sent_at        TIMESTAMPTZ,
  next_scheduled_at   TIMESTAMPTZ,
  created_by          UUID REFERENCES auth.users(id),
  created_at          TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- TABELA: campaign_alerts
-- ============================================================
CREATE TABLE IF NOT EXISTS public.campaign_alerts (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  ad_account_id     UUID NOT NULL REFERENCES public.ad_accounts(id) ON DELETE CASCADE,
  client_id         UUID NOT NULL REFERENCES public.clients(id),
  campaign_id       TEXT,
  metric            TEXT NOT NULL CHECK (metric IN ('cpa','roas','ctr','spend','budget_pct')),
  operator          TEXT NOT NULL CHECK (operator IN ('greater_than','less_than')),
  threshold         DECIMAL(12,4) NOT NULL,
  action            TEXT NOT NULL CHECK (action IN ('notify_only','notify_and_pause')),
  notify_email      BOOLEAN DEFAULT true,
  notify_whatsapp   BOOLEAN DEFAULT false,
  recipients        TEXT[] DEFAULT '{}',
  is_active         BOOLEAN DEFAULT true,
  last_triggered_at TIMESTAMPTZ,
  created_at        TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- TABELA: profiles
-- ============================================================
CREATE TABLE IF NOT EXISTS public.profiles (
  id          UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name   TEXT,
  avatar_url  TEXT,
  role        TEXT DEFAULT 'analyst'
                CHECK (role IN ('admin','analyst','viewer','client')),
  client_id   UUID REFERENCES public.clients(id),
  created_at  TIMESTAMPTZ DEFAULT NOW(),
  updated_at  TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- TRIGGER: atualiza updated_at automaticamente
-- ============================================================
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_clients_updated_at ON public.clients;
CREATE TRIGGER trg_clients_updated_at
  BEFORE UPDATE ON public.clients
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

DROP TRIGGER IF EXISTS trg_profiles_updated_at ON public.profiles;
CREATE TRIGGER trg_profiles_updated_at
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- ============================================================
-- TRIGGER: cria profile ao registrar usuário
-- ============================================================
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, role)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.email),
    COALESCE(NEW.raw_user_meta_data->>'role', 'analyst')
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();
