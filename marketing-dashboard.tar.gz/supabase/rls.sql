-- ============================================================
-- ADSPULSE — Row Level Security (RLS)
-- Execute APÓS o schema.sql
-- ============================================================

-- Habilitar RLS em todas as tabelas
ALTER TABLE public.clients         ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ad_accounts     ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.campaign_metrics ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.reports         ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.schedules       ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.campaign_alerts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.profiles        ENABLE ROW LEVEL SECURITY;

-- ────────────────────────────────────────────────────────────
-- Helpers
-- ────────────────────────────────────────────────────────────
CREATE OR REPLACE FUNCTION get_user_role()
RETURNS TEXT AS $$
  SELECT role FROM public.profiles WHERE id = auth.uid();
$$ LANGUAGE sql SECURITY DEFINER STABLE;

CREATE OR REPLACE FUNCTION get_user_client_id()
RETURNS UUID AS $$
  SELECT client_id FROM public.profiles WHERE id = auth.uid();
$$ LANGUAGE sql SECURITY DEFINER STABLE;

-- ────────────────────────────────────────────────────────────
-- PROFILES
-- ────────────────────────────────────────────────────────────
DROP POLICY IF EXISTS "profiles_select" ON public.profiles;
CREATE POLICY "profiles_select" ON public.profiles FOR SELECT
  USING (id = auth.uid() OR get_user_role() = 'admin');

DROP POLICY IF EXISTS "profiles_update" ON public.profiles;
CREATE POLICY "profiles_update" ON public.profiles FOR UPDATE
  USING (id = auth.uid());

-- ────────────────────────────────────────────────────────────
-- CLIENTS
-- ────────────────────────────────────────────────────────────
DROP POLICY IF EXISTS "clients_select" ON public.clients;
CREATE POLICY "clients_select" ON public.clients FOR SELECT
  USING (
    get_user_role() IN ('admin', 'analyst', 'viewer')
    OR id = get_user_client_id()
  );

DROP POLICY IF EXISTS "clients_insert" ON public.clients;
CREATE POLICY "clients_insert" ON public.clients FOR INSERT
  WITH CHECK (get_user_role() = 'admin');

DROP POLICY IF EXISTS "clients_update" ON public.clients;
CREATE POLICY "clients_update" ON public.clients FOR UPDATE
  USING (get_user_role() = 'admin');

DROP POLICY IF EXISTS "clients_delete" ON public.clients;
CREATE POLICY "clients_delete" ON public.clients FOR DELETE
  USING (get_user_role() = 'admin');

-- ────────────────────────────────────────────────────────────
-- AD_ACCOUNTS
-- ────────────────────────────────────────────────────────────
DROP POLICY IF EXISTS "ad_accounts_select" ON public.ad_accounts;
CREATE POLICY "ad_accounts_select" ON public.ad_accounts FOR SELECT
  USING (
    get_user_role() IN ('admin', 'analyst', 'viewer')
    OR client_id = get_user_client_id()
  );

DROP POLICY IF EXISTS "ad_accounts_write" ON public.ad_accounts;
CREATE POLICY "ad_accounts_write" ON public.ad_accounts
  FOR ALL USING (get_user_role() = 'admin');

-- ────────────────────────────────────────────────────────────
-- CAMPAIGN_METRICS
-- ────────────────────────────────────────────────────────────
DROP POLICY IF EXISTS "metrics_select" ON public.campaign_metrics;
CREATE POLICY "metrics_select" ON public.campaign_metrics FOR SELECT
  USING (
    get_user_role() IN ('admin', 'analyst', 'viewer')
    OR client_id = get_user_client_id()
  );

DROP POLICY IF EXISTS "metrics_insert" ON public.campaign_metrics;
CREATE POLICY "metrics_insert" ON public.campaign_metrics FOR INSERT
  WITH CHECK (get_user_role() = 'admin');

-- ────────────────────────────────────────────────────────────
-- REPORTS
-- ────────────────────────────────────────────────────────────
DROP POLICY IF EXISTS "reports_select" ON public.reports;
CREATE POLICY "reports_select" ON public.reports FOR SELECT
  USING (
    get_user_role() IN ('admin', 'analyst', 'viewer')
    OR client_id = get_user_client_id()
  );

DROP POLICY IF EXISTS "reports_insert" ON public.reports;
CREATE POLICY "reports_insert" ON public.reports FOR INSERT
  WITH CHECK (get_user_role() IN ('admin', 'analyst'));

DROP POLICY IF EXISTS "reports_update" ON public.reports;
CREATE POLICY "reports_update" ON public.reports FOR UPDATE
  USING (get_user_role() IN ('admin', 'analyst'));

DROP POLICY IF EXISTS "reports_delete" ON public.reports;
CREATE POLICY "reports_delete" ON public.reports FOR DELETE
  USING (get_user_role() = 'admin');

-- ────────────────────────────────────────────────────────────
-- SCHEDULES
-- ────────────────────────────────────────────────────────────
DROP POLICY IF EXISTS "schedules_select" ON public.schedules;
CREATE POLICY "schedules_select" ON public.schedules FOR SELECT
  USING (get_user_role() IN ('admin', 'analyst'));

DROP POLICY IF EXISTS "schedules_write" ON public.schedules;
CREATE POLICY "schedules_write" ON public.schedules
  FOR ALL USING (get_user_role() IN ('admin', 'analyst'));

-- ────────────────────────────────────────────────────────────
-- CAMPAIGN_ALERTS
-- ────────────────────────────────────────────────────────────
DROP POLICY IF EXISTS "alerts_select" ON public.campaign_alerts;
CREATE POLICY "alerts_select" ON public.campaign_alerts FOR SELECT
  USING (get_user_role() IN ('admin', 'analyst'));

DROP POLICY IF EXISTS "alerts_write" ON public.campaign_alerts;
CREATE POLICY "alerts_write" ON public.campaign_alerts
  FOR ALL USING (get_user_role() IN ('admin', 'analyst'));
